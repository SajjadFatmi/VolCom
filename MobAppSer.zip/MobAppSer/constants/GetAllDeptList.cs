﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace constants
{
    public class GetAllDeptList
    {
        public static class Columns
        {
            public const string DEPARTMENT_CODE = "DEPARTMENT_CODE";
            public const string DESCRIPTION = "DESCRIPTION";
          
           
        }

    }
}
