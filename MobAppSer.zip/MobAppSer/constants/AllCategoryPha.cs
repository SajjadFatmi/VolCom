﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace constants
{
    public class AllCategoryPha
    {
        public static class Columns
        {
            public const string CategoryID = "CategoryID";
            public const string Desc = "Desc";


        }

    }
}
   
