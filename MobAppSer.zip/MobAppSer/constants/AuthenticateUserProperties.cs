﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace constants
{
    public class AuthenticateUserProperties
    {
        private string _displayName;


        public string displayName
        {
            get { return _displayName; }
            set { _displayName = value; }
        }

        private string _employeeID;


        public string employeeID
        {
            get { return _employeeID; }
            set { _employeeID = value; }
        }

        private string _mail;


        public string mail
        {
            get { return _mail; }
            set { _mail = value; }
        }
        private string _adspath;


        public string adspath
        {
            get { return _adspath; }
            set { _adspath = value; }
        }

        public string department
        {
            get;
            set;
        }
        public string designation
        {
            get;
            set;
        }
        public string telephoneNumber
        {
            get;
            set;
        }
        public string mobile
        {
            get;
            set;
        }
        //newtest.EmployeeID = json["employeeID"].ToString();
        //newtest.Name = json["displayName"].ToString();
        //newtest.Email = json["mail"].ToString();
        //newtest.Department = json["department"].ToString();
        //newtest.Designation = json["title"].ToString();
        //newtest.Extension = json["telephoneNumber"].ToString();
        //newtest.Mobile = json["mobile"].ToString();

    }
}
