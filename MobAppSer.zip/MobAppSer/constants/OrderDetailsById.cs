﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace constants
{
    public class OrderDetailsById
    {
        public static class Columns
        {
            public const string USER_CODE = "USER_CODE";
            public const string ITEM_TOTAL = "ITEM_TOTAL";
            public const string PRODUCT_CODE = "ProductCode";
            public const string QUANTITY = "QUANTITY";
            public const string ProductName = "ProductName";
             public const string UNIT_PRICE="UNIT_PRICE";
             public const string PRICE = "PRICE";
             public const string ProductImage = "ProductImage";
            
            
        }
    }
}
