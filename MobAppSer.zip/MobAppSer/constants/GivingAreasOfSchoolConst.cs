﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace constants
{
    public class GivingAreasOfSchoolConst
    {
        public static class Columns
        {
            public const string ID = "ID";
            public const string GivingArea = "GivingArea";
            public const string FK_SchoolOrUnitID = "FK_SchoolOrUnitID";

        }
    }
}
