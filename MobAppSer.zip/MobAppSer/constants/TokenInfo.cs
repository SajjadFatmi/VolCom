﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace constants
{
    public class TokenInfo
    {
        public static class Columns
        {
            public const string TokenID = "TokenID";
            public const string ApiToken = "ApiToken";
            public const string UserID = "UserID";
            public const string SessionTimeIn = "SessionTimeIn";
            public const string SessionTimeOut = "SessionTimeOut";
            public const string SessionTimeOutInMinutes = "SessionTimeOutInMinutes";
           
        }
    }
}
