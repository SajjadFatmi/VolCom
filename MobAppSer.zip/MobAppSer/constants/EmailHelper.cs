﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text;
using System.Threading.Tasks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Mail;
using Microsoft.SharePoint;
//using Microsoft.SharePoint.Administration;
using System.IO;
namespace constants
{
    public class EmailHelper
    {
        public string EmailBody { get; set; }
        public string EmailSubject { get; set; }
        public string EmailTo { get; set; }
        public string EmailCC { get; set; }
        public List<string> EmailBCC { get; set; }
        public string EmailFrom { get; set; }


        public static bool SendEmail(EmailHelper EmailHelper)
        {
            bool IsEmailSent = false;
            try
            {
                
                MailMessage message = new MailMessage();
                message.To.Add(new MailAddress(EmailHelper.EmailTo));
                message.From = new MailAddress(EmailHelper.EmailFrom);
                if (EmailHelper.EmailCC.Trim() != string.Empty)
                {
                    message.CC.Add(new MailAddress(EmailHelper.EmailCC));
                }
                if (EmailHelper.EmailBCC != null && EmailHelper.EmailBCC.Count>0)
                {
                    foreach(string strBCCEmail in EmailHelper.EmailBCC)
                    {
                        message.Bcc.Add(new MailAddress(strBCCEmail));
                    }
                }
                message.Subject = EmailHelper.EmailSubject;
                message.Body = EmailHelper.EmailBody;
                message.IsBodyHtml = true;
       
                //Send the message.
                SmtpClient client = new SmtpClient();
                
                // Add credentials if the SMTP server requires them.
                client.Credentials = CredentialCache.DefaultNetworkCredentials;
              
                client.Send(message);
                IsEmailSent = true;
                return IsEmailSent;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
    }
}
