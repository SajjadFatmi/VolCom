﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace constants.HRCredentialingConstant
{
  public  class LoggingErrors
    {

        public static class Columns
        {
            public const string LogID = "LogID";
            public const string ProcedureName = "ProcedureName";
            public const string ErrorDescription = "ErrorDescription";
            public const string InformationForUser = "InformationForUser";
            public const string LogDate = "LogDate";
            public const string LogSessionID = "LogSessionID";


        }
    }
}
