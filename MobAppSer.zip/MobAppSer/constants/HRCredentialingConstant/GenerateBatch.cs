﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace constants.HRCredentialingConstant
{
    public class GenerateBatch
    {
        public static class Columns
        {

            public const string BatchNumber = "BatchNumber";
            public const string Title = "Title";
            public const string Message = "Message";



        }
        } 
}
