﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace constants.HRCredentialingConstant
{
    public class CandidateQualification
    {

        public static class Columns
        {
            public const string CandidateQualificationID = "CandidateQualificationID";
            public const string EmployeeID = "EmployeeID";
            public const string InstituteName = "InstituteName";
            public const string Qualification = "Qualification";
            public const string VerificationStatus = "VerificationStatus";
            public const string LicenseNumber = "LicenseNumber";
            public const string BatchNumber = "BatchNumber";
            


        }
    }
}
