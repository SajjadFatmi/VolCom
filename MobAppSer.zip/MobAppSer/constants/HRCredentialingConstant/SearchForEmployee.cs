﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace constants.HRCredentialingConstant
{
     public class SearchForEmployee
    {
         public static class Columns
         {
             public const string EmployeeID = "EmployeeID";
             public const string EmployeeNo = "EmployeeNo";
             public const string FullName = "FullName";
             public const string CandidateQualification = "CandidateQualification";
             public const string PositionTitle = "PositionTitle";
             public const string Department = "Department";
             public const string CNIC = "CNIC";
             public const string DateOfJoining = "DateOfJoining";
             public const string HiredBy = "HiredBy";
             public const string VerificationStatus = "VerificationStatus";
             public const string ColorCode = "ColorCode";
             public const string Created = "Created";
             public const string CreatedBy = "CreatedBy";
             public const string Updated = "Updated";
             public const string UpdatedBy = "UpdatedBy";
             
             
         }
    }
}
