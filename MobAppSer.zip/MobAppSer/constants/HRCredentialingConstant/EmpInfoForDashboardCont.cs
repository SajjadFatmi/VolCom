﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace constants.HRCredentialingConstant
{
    public class EmpInfoForDashboardCont
    {

        public static class Columns
        {
            public const string EmployeeNo = "EmployeeNo";
            public const string Name = "Name";
            public const string PositionTitle = "PositionTitle";
            public const string Department = "Department";
            public const string VerificationStatus = "VerificationStatus";
            public const string VerificationStatusID = "VerificationStatusID";
            public const string LastModifiedSince = "LastModifiedSince(days)";
            public const string rn = "rn";
            public const string ColorCode = "ColorCode";






        }
    }
}
