﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace constants.HRCredentialingConstant
{
   public class BatchSearch
    {
       public static class Columns
       {
          
           public const string CountOfEmployee = "CountOfEmployee";
           public const string BatchID = "BatchID";
           public const string BatchNumber = "BatchNumber";
           public const string BatchStatusID = "BatchStatusID";
           public const string BatchStatusDescription = "BatchStatusDescription";
           public const string Created = "Created";
           public const string CreatedBy = "CreatedBy";
           public const string Updated = "Updated";
           public const string UpdatedBy = "UpdatedBy";
           public const string PayOrderNumber = "PayOrderNumber";
           public const string TotalAmount = "TotalAmount";
           public const string Institute = "Institute";
           public const string ColorCode = "ColorCode";
          



       }
    }
}
