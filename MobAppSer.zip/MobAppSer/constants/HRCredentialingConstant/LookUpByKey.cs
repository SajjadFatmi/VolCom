﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace constants.HRCredentialingConstant
{
    public class LookUpByKey
    {
        public static class Columns
        {
            public const string ID = "ID";
            public const string Description = "Description";
            
        }
    }
}
