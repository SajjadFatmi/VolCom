﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace constants.HRCredentialingConstant
{
   public class DownloadLetterConstants
    {
        public static class Columns
        {
            public const string BatchNumber = "BatchNumber";
            public const string SendTo = "SendTo";
            public const string Address = "Address";
            public const string PayOrderNumber = "PayOrderNumber";
            public const string TotalAmount = "TotalAmount";
            public const string InstituteName = "InstituteName";
            public const string LicenseNumber = "LicenseNumber";
           
        }
    }
}
