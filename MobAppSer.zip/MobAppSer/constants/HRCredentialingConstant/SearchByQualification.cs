﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace constants.HRCredentialingConstant
{
   public class SearchByQualification

    {
       public static class Columns
       {
           public const string QualificationID = "QualificationID";
           public const string Title = "Title";
           public const string Created = "Created";
           public const string CreatedBy = "CreatedBy";
           public const string Updated = "Updated";
           public const string UpdatedBy = "UpdatedBy";
           public const string Category = "Category";


       }
    }
}
