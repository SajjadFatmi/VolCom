﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace constants.HRCredentialingConstant
{
    public class EmployeeDataByBatchNumber
    {
        public static class Columns
        {
            public const string BatchNumber = "BatchNumber";
            public const string EmployeeNo = "EmployeeNo";
            public const string EmployeeName = "EmployeeName";
            public const string InstituteTitle = "InstituteTitle";
            public const string QualificationTitle = "QualificationTitle";
            public const string DegreeVerificationStatusID = "DegreeVerificationStatusID";
            public const string VerificationStatus = "VerificationStatus";
            public const string LicenseNumber = "LicenseNumber";
            public const string CandidateQualificationID = "CandidateQualificationID";




        }
    }
}
