﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace constants.HRCredentialingConstant
{
    public static class RPT_EmployeeCompleteDetail
    {
        public static class Columns
        {
            public const string EmployeeID = "EmployeeID";
            public const string EmployeeNo = "EmployeeNo";
            public const string NAME = "NAME";
            public const string PositionTitle = "PositionTitle";
            public const string Department = "Department";
            public const string Qualification = "Qualification";
            public const string Institute = "Institute";
            public const string VerificationStatus = "VerificationStatus";
            public const string BatchNumber = "BatchNumber";
            public const string DateOfJoining = "DateOfJoining";
            public const string BatchUpdateDate = "BatchUpdateDate";


        }
    }
}
