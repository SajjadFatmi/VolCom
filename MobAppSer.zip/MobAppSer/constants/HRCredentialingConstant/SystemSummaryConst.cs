﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace constants.HRCredentialingConstant
{
    public class SystemSummaryConst
    {
        public static class Columns
        {


            public const string NewBatchGeneratedCount = "NewBatchGeneratedCount";
            public const string ItemsInQueue = "ItemsInQueue";
            public const string DegreesInVerification = "DegreesInVerification";
            public const string DegreesNotVerified = "DegreesNotVerified";
            


        }
    }
}
