﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace constants.HRCredentialingConstant
{
    public class SearchByInstitution
    {
        public static class Columns
        {
            public const string InstitutionID = "InstitutionID";
            public const string Title = "Title";
            public const string Created = "Created";
            public const string CreatedBy = "CreatedBy";
            public const string Updated = "Updated";
            public const string UpdatedBy = "UpdatedBy";
            public const string SentTo = "SentTo";
            public const string Address = "Address";
            public const string VerificationFee = "VerificationFee";
           

        }
    }
}
