﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace constants.HRCredentialingConstant
{
   
    public class ViewQueueDetailsConst
    {
          public static class Columns
        {
           

            public const string QueueID = "QueueID";
            public const string EmployeeID = "EmployeeID";
            public const string EmployeeNo = "EmployeeNo";
            public const string CandidateQualificationID = "CandidateQualificationID";
            public const string Name = "Name";
            public const string InstituteTitle = "InstituteTitle";
            public const string QualificationTitle = "QualificationTitle";
            public const string LicenseNumber = "LicenseNumber";
              
           

        }
    }
}
