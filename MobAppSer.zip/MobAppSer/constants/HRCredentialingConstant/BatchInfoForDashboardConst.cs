﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace constants.HRCredentialingConstant
{
    public class BatchInfoForDashboardConst
    {
        public static class Columns
        {
           

            public const string BatchStatusID = "BatchStatusID";
            public const string BatchNumber = "BatchNumber";
            public const string BatchStatus = "BatchStatus";
            public const string LastModifiedSince = "LastModifiedSince(days)";
            public const string LastModifiedBy = "LastModifiedBy";
            public const string rn = "rn";
            public const string ColorCode = "ColorCode";
           

        }
    
    }
}
