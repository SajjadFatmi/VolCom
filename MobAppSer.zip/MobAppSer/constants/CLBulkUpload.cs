﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Collections;
using System.Data.Sql;
using System.Data.SqlClient;
/// <summary>
/// Summary description for CLBulkUpload
/// </summary>
public class CLBulkUpload
{
  
	public CLBulkUpload()
	{
  
	}
    public void PostFileToDB(string postXML,out string returnMessage)
    {

         string ConString =System.Configuration.ConfigurationManager.ConnectionStrings["sqlCon1"].ToString();
         SqlConnection connection = new SqlConnection(ConString);
         SqlCommand comm = new SqlCommand();
         comm.CommandText = "UploadDepartmentData";
         comm.CommandType = CommandType.StoredProcedure;
         comm.Connection = connection;
         SqlParameter param = new SqlParameter("@PostXML", postXML);
         comm.Parameters.Add(param);
         try
         {
             connection.Open();
             comm.ExecuteScalar();
         }
        catch(Exception ex)
         {
             throw ex;
         }
        finally
         {
             connection.Close();
         }
        returnMessage = "";
        //DBParameterCollection dbparacol = new DBParameterCollection();
        //DBParameter dbtransactioncode = new DBParameter("@transactioncode", postXML);
     
        //DBParameter dbbreturn = new DBParameter("@ReturnMsg", DBNull.Value, DbType.String, ParameterDirection.Output, 30);
        //dbparacol.Add(dbtransactioncode);
        //dbparacol.Add(dbbreturn);
     
        //IDbTransaction transaction = objdl.BeginTransaction();
        //IDbCommand command = null;
        //try
        //{
        //    command = objdl.GetCommand("ChckOut_Proc", dbparacol, transaction, CommandType.StoredProcedure);
        //    command.Transaction = transaction;
        //    command.ExecuteNonQuery();

        //    ReturnMsg = objdl.GetParameterValue(4, command).ToString();
        //    objdl.CommitTransaction(transaction);
        //}
        //catch (Exception ex)
        //{
        //    objdl.RollbackTransaction(transaction);
        //    throw ex;
        //}
        //finally
        //{
        //    objdl.DisposeCommand(command);
        //}
    }
}