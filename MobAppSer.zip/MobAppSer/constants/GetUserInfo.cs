﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace constants
{
    public class GetUserInfo
    {
        public static class Columns
        {
            public const string Active = "ACTIVE";
            public const string CustomerCode = "CUSTOMER_CODE";
            public const string Name = "NAME";
            public const string CustomerSince = "CUSTOMER_SINCE";
            public const string AreaCode = "AREA_CODE";
            public const string EmployeeID = "CUSTOMER_REF_CODE";
            public const string Department = "FAX_1";
            public const string Grade = "FAX_2";
            public const string Designation = "WEBSITE";
            public const string AccessLevel = "ACCESS_LEVEL";
            public const string Email = "EMAIL1";
            public const string AvailCashless = "AVAIL_CASHLESS";
            public const string CurrentCredit = "CURRENT_CREDIT";
            public const string CreditLimit = "CREDIT_LIMIT";
            public const string SavedOrderCode = "SAVED_ORDER_CODE";
          
        }
    }
}
