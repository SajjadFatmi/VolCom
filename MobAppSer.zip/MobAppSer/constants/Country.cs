﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace constants
{
    public class Country
    {
        public static class Columns
        {
            public const string CountryID = "CountryID";
            public const string CountryName = "CountryName";
            public const string CountryCode = "CountryCode";
            public const string Active = "Active";
            public const string Country = "Country";
        }
    }
}
