﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace constants
{
    public class DrugsByCategory
    {

        public static class Columns
        {
            public const string ProductID = "ProductID";
            public const string Strength = "Strength";
            public const string DispensingForm = "DispensingForm";
            public const string DispensingSize = "DispensingSize";
            public const string OrderingForm = "OrderingForm";
            public const string UnitPrice = "UnitPrice";
            public const string OrderingSize = "OrderingSize";
            public const string FormularyComment = "FormularyComment";
            public const string HospitalItemNo = "HospitalItemNo";
            public const string TradeName = "TradeName";
            public const string Description = "Description";
            public const string CategoryID = "CategoryID";
            public const string ProductImage = "ProductImage";
        }
    }
    
}
