﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace constants
{
  public  class AuthenticatedCustClass
    {
        public static class Columns
        {
            public const string ACTIVE = "ACTIVE";
            public const string NAME = "NAME";
            public const string CUSTOMER_REF_CODE = "CUSTOMER_REF_CODE";
            public const string CREDIT_LIMIT = "CREDIT_LIMIT";
            public const string REMAINING_BALANCE = "CURRENT_CREDIT";
            public const string AVAIL_CASHLESS = "AVAIL_CASHLESS";
            public const string SAVED_ORDER_CODE = "SAVED_ORDER_CODE";
            public const string CUSTOMER_CODE = "CUSTOMER_CODE";
            public const string EMAIL1 = "EMAIL1";
            public const string ACCESS_LEVEL = "ACCESS_LEVEL";
        }
    }
}
