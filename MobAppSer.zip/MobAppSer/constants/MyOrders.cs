﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace constants
{
    public class MyOrders
    {
        public static class Columns
        {
            public const string Orderid = "Orderid";
            public const string Requestername = "Requestername";
            public const string Mrnumber = "Mrnumber";
            public const string Patientname = "Patientname";
            public const string Orderdttm = "Orderdttm";
           
        }
    }
}
