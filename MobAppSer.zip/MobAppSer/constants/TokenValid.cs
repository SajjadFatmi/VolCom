﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace constants
{
    public class TokenValid
    {
        public static class Columns
        {
            public const string SessionExsist = "SessionExsist";
        }
    }
}
