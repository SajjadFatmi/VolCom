﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace constants
{
  public  class AllProductByDept
    {

      public static class Columns
      {
          public const string LONG_DESCRIPTION = "LONG_DESCRIPTION";
          public const string DEPARTMENT_CODE = "DEPARTMENT_CODE";
          public const string RETAIL_PRICE = "RETAIL_PRICE";
          public const string PICTURE = "PICTURE";
          public const string PRODUCT_CODE = "PRODUCT_CODE";
          public const string name = "name";
      }
    }
}
