﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace constants
{
   public class AddToCartCol
    {
        public static class Columns
        {
            public const string userID = "userID";
            public const string drugID = "drugID";
            public const string qty = "qty";
            

            public const string sMessage = "sMessage";
            public const string bReturn = "bReturn";

        }


    }
}
