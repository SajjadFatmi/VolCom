﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace constants
{
    public class SchoolOrUnit
    {
        public static class Columns
        {
            public const string ID = "ID";
            public const string SchoolOrUnitName = "SchoolOrUnitName";
            public const string BasedOn = "BasedOn";
          
        }
    }
}
