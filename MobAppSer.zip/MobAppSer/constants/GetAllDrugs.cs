﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace constants
{
  public class GetAllDrugs
    {
      public static class Columns
      {
          public const string DrugID = "DrugID";
          public const string TradeName = "TradeName";
          public const string Description = "Description";
          public const string Strength = "Strength";
          public const string DispensingForm = "DispensingForm";
          public const string DispensingFormDescription = "DispensingFormDescription";
          public const string UnitPrice = "UnitPrice";
          public const string Active = "Active";
         
      }

    }
}
