﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace constants
{
   public class GetDrugsDetails
    {
        public static class Columns
        {
            public const string TradeName = "TradeName";
            public const string Description = "Description";
            public const string Strength = "Strength";
            public const string DispensingForm = "DispensingForm";
            public const string Price = "Price";
        }
    }
}
