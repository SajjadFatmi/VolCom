﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.DirectoryServices;
using System.Security.Principal;
using System.Configuration;
using System.Runtime.InteropServices;
using constants;
using System.Data;
using System.Web;
using System.Net.Mail;
using System.IO;
using System.Net;
using System.Collections;
namespace constants
{
   public class ADHelper
    {
        private string _path = "LDAP://aku.edu/DC=aku,DC=edu";
        private string _filterAttribute;
        public ADHelper()
        {
            //_path = path;
        }
        object Properties = null;
        public bool IsAuthenticated(string domain, string username, string pwd, out Object obj1)
        {
            string domainAndUsername = domain + @"\" + username;
            DirectoryEntry entry = new DirectoryEntry(_path, domainAndUsername, pwd);
            // string str=  entry.Properties["employeeID"][0].ToString();
            try
            {
                //Bind to the native AdsObject to force authentication.
                object obj = entry.NativeObject;

                DirectorySearcher search = new DirectorySearcher(entry);

                
                search.Filter = "(SAMAccountName=" + username + ")";
                string[] requiredProperties = new string[] { "displayName", "employeeID", "mail", "department", "title", "telephoneNumber","mobile" };
                foreach (String property in requiredProperties)
                    search.PropertiesToLoad.Add(property);
                //SearchResultCollection allResults = search.FindAll();
                //DataTable resultsTable = new DataTable("Results");

                SearchResult result = search.FindOne();
                AuthenticateUserProperties ojbAuth = new AuthenticateUserProperties();

                //ojbAuth.employeeID = (string)result.Properties["employeeID"][0];
               // ojbAuth.displayName = (string)result.Properties["displayName"][0];
               // ojbAuth.mail = (string)result.Properties["mail"][0];
                if (((System.Collections.ReadOnlyCollectionBase)(result.Properties["employeeID"])).Count > 0)
                {
                    ojbAuth.employeeID = (string)result.Properties["employeeID"][0];
                }
                else
                {
                    ojbAuth.employeeID = "";
                }
                if (((System.Collections.ReadOnlyCollectionBase)(result.Properties["displayName"])).Count > 0)
                {
                    ojbAuth.displayName = (string)result.Properties["displayName"][0];
                }
                else
                {
                    ojbAuth.displayName = "";
                }
                if (((System.Collections.ReadOnlyCollectionBase)(result.Properties["mail"])).Count > 0)
                {
                    ojbAuth.mail = (string)result.Properties["mail"][0];
                }
                else
                {
                    ojbAuth.mail = "";
                }
                if (((System.Collections.ReadOnlyCollectionBase)(result.Properties["department"])).Count > 0)
                {
                    ojbAuth.department = (string)result.Properties["department"][0];
                }
                if (((System.Collections.ReadOnlyCollectionBase)(result.Properties["title"])).Count > 0)
                {
                    ojbAuth.designation = (string)result.Properties["title"][0];
                }
                else
                {
                    ojbAuth.designation = "";
                }
                if (((System.Collections.ReadOnlyCollectionBase)(result.Properties["telephoneNumber"])).Count > 0)
                {
                     ojbAuth.telephoneNumber = (string)result.Properties["telephoneNumber"][0];
                }
                else
                {
                    ojbAuth.telephoneNumber = "";
                }
                if (((System.Collections.ReadOnlyCollectionBase)(result.Properties["mobile"])).Count > 0)
                {
                    ojbAuth.mobile = (string)result.Properties["mobile"][0];
                }
                else
                {
                    ojbAuth.mobile = "";
                }

                //string str = (string)result.Properties["employeeID"][0];
                obj1 = ojbAuth;
                if (null == result)
                {
                    return false;
                }

                _path = result.Path;
                if (result != null)
                {

                    ResultPropertyCollection fields = result.Properties;

                    foreach (String ldapField in fields.PropertyNames)
                    {

                        foreach (Object myCollection in fields[ldapField])
                        {
                            //try
                            //{
                            //    //AuthenticateUserProperties ojbAuth = new AuthenticateUserProperties();

                            //    //ojbAuth.displayName = myCollection.ToString();
                            //  //  ojbAuth.adspath
                            //    //Console.Write(ldapField);
                            //    //Console.Write(" : ");
                            //    //Console.Write(myCollection.ToString());
                            //    //Console.WriteLine("");
                            //    //Console.WriteLine("-----------------");

                            //}

                            //catch (Exception ex)
                            //{
                            //    Console.WriteLine(ex.Message);

                            //}

                        }
                    }
                    // Console.ReadLine();
                }

            }
            catch (Exception ex)
            {
                ParameterHelperCommon oParameterHelperCommonDestination = new ParameterHelperCommon();
                oParameterHelperCommonDestination.Dmain = "AKU";
                string LoggingSiteUrl = System.Configuration.ConfigurationSettings.AppSettings["LoggingSiteURL"].ToString();
                oParameterHelperCommonDestination.URL = LoggingSiteUrl;
                string LoggingListName = System.Configuration.ConfigurationSettings.AppSettings["LoggingListName"].ToString();
                oParameterHelperCommonDestination.ListName = LoggingListName;



                Hashtable tblitem = new Hashtable();
                tblitem.Add("Title", "ADHelper(IsAuthenticated)");
                tblitem.Add("Exception", ex.Message);
                if (ex.StackTrace != null)
                {
                    tblitem.Add("StackTrace", ex.StackTrace);
                }
                if (ex.InnerException != null)
                {
                    tblitem.Add("InnerException", ex.InnerException);
                }
                bool IsSaved = SPClientHelper.AddItem(oParameterHelperCommonDestination, tblitem);
                throw new Exception("Error authenticating user. " + ex.Message);
            }

            return true;
        }
       
    }
}
