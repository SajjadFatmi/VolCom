﻿
namespace constants
{
    public class ParameterHelperSourceDestination
    {
        public string SourceURL { get; set; }
        public string SourceUserID { get; set; }
        public string SourcePassword { get; set; }
        public string SourceDmain { get; set; }
        public string DestinationURL { get; set; }
        public string DestinationUserID { get; set; }
        public string DestinationPassword { get; set; }
        public string DestinationDmain { get; set; }
    }
}
