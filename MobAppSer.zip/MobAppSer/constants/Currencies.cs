﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace constants
{
    public class Currencies
    {
        public static class Columns
        {
            public const string CurrencyID = "CurrencyID";
            public const string CurrencyRate = "CurrencyRate";
            public const string CurrencySymbol = "CurrencySymbol";
            public const string Description = "Description";
            public const string Currency = "Currency";
            public const string SortOrder = "SortOrder";
            public const string Active = "Active";

        }
    }
}
