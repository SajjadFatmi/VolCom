﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace constants
{
    public class Packages
    {
       // public Packages();
        private const string PackageName = "PKG_EPharmacy.";
        public class pkg_webservices
        {
            //public pkg_webservices();

            public class Proc_usp_Categories_Wrapper
            {
                public const string Name = PackageName + "sp_getdrugcategory";

                

                public class Parameters
                {
                    public const string rsdrugcategory = "rsdrugcategory";

                   // public Parameters();
                }
            }

            public class Proc_usp_Drugs_Wrapper
            {
                public const string Name = PackageName + "sp_GetDrugs";



                public class Parameters
                {
                    public const string rsDrugs = "rsDrugs";
                    public const string p_categoryID = "p_categoryID";
                    public const string p_SearchPhrase = "p_SearchPhrase";
                    // public Parameters();
                }
            }
            public class Proc_sp_GetOrder_Wrapper
            {
                public const string Name = PackageName + "sp_GetOrder";



                public class Parameters
                {
                    public const string rsOrder = "rsOrder";
                    public const string p_EmployeNumber = "p_EmployeNumber";
                    public const string p_strtDate = "p_strtDate";
                    public const string p_endDate = "p_endDate";
                    public const string p_Status = "p_Status";
                    
                    
                }
            }
            public class Proc_usp_Ceckout_Wrapper
            {
                public const string Name = PackageName + "sp_CheckOut";



                public class Parameters
                {
                    public const string p_xmlString = "p_xmlString";
                    public const string p_StatusCode = "p_StatusCode";
                    public const string p_Message = "p_Message";
                    
                }
            }
            public class sp_GetOrderDetailByID
            {
                public const string Name = PackageName + "sp_GetOrderDetailByID";



                public class Parameters
                {
                    public const string p_OrderID = "p_OrderID";
                    public const string rsOrderDetail = "rsOrderDetail";
                    // public Parameters();
                }
            }
        }


    }
   
}
