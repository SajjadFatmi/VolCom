﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
using System.Collections.Generic;
using Microsoft.SharePoint.Client;
using SP = Microsoft.SharePoint.Client;
using Newtonsoft.Json;
namespace BAL.MobAppBAL
{
   public class MobAppBAL
    {


                public ListItemCollection GetAllUserBAL()
                    {
                        ClientContext clientContext = new ClientContext("http://v2013dev3:41124/");
                        SP.List oList = clientContext.Web.Lists.GetByTitle("UserExtendedProperties");

                        clientContext.AuthenticationMode = ClientAuthenticationMode.FormsAuthentication;
                        clientContext.FormsAuthenticationLoginInfo = new
                                            FormsAuthenticationLoginInfo("farah", "@kutest");

                        Web w = clientContext.Web;
                        var lists = clientContext.LoadQuery(w.Lists);

                        clientContext.Load(w);
                        List list = w.Lists.GetByTitle("UserExtendedProperties");
                        clientContext.Load(list);

                        CamlQuery camlQuery = new CamlQuery();
                        camlQuery.ViewXml = "<View><Query><FieldRef Name='Title'/></Query></View>";

                        //-----------------------
                        ListItemCollection ListColletion = list.GetItems(camlQuery);
                        clientContext.Load(list);
                        clientContext.Load(ListColletion);

                        clientContext.ExecuteQuery();
                        return ListColletion;
                    } 


        
    }
}
