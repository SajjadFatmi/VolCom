﻿using System;
using System.Collections.Generic;
using Microsoft.SharePoint.Client;
using SP = Microsoft.SharePoint.Client;
using Newtonsoft.Json;
using System.Data;
using System.Web.Security;
using System.Linq;
using constants;
using System.Diagnostics;
using System.Web;
using System.IO;
using System.ServiceModel.Web;
using com.pakhee.common;

namespace MobAppSer
{
    public class BioEthicMobApp : IVolComMobApp
    {
        BAL.MobAppBAL.MobAppBAL balMobObj = new BAL.MobAppBAL.MobAppBAL();
        public static string settingsReader { get { return System.Configuration.ConfigurationSettings.AppSettings["SecurityKey"].ToString(); } }
           
        #region "Users"
        public Authentication Authentication(string EmailID, string Password)
        
        {

            try
            {
                LogEvent("Service Access" + EmailID);
                Authentication Info = new Authentication();
                if(EmailID.ToLower().Contains("@aku.edu"))
                {
                    Object obj;

                    
                    ADHelper oADHelper = new ADHelper();
                    /* new code for encryption dycrytion of password */
                   // string cipherText = HttpUtility.HtmlDecode(Password);//Password.Trim().Replace(" ", "+");;
                     

                    CryptLib _crypt = new CryptLib();
                    String iv = "BioEthicsMobApp1";// CryptLib.GenerateRandomIV(16); //16 bytes = 128 bits
                    string key = CryptLib.getHashSha256(settingsReader, 32); //32 bytes = 256 bits

                    String dycyptedPass = _crypt.decrypt(Password, key, iv);
                   

                    //string dycyptedPass = CryptorEngine.Decrypt(cipherText, false);
                 
                    /* end of new code for encryption dycrytion of password */
                    bool Test = oADHelper.IsAuthenticated("aku", EmailID, dycyptedPass, out obj);
                    if (Test == true)
                    {
                        AuthenticateUserProperties objaauth = new AuthenticateUserProperties();
                        objaauth = (AuthenticateUserProperties)obj;
                        string empid = objaauth.employeeID;
                        DataSet dsData = new DataSet();

                        DataTable dtbal = new DataTable();
                        dtbal = balMobObj.GetUserByUserNameBAL(EmailID);
                        List<UserByUserName> data = new List<UserByUserName>();
                        if (dtbal != null && dtbal.Rows.Count > 0)
                        {
                            if (dtbal.Rows[0]["isApproved"].ToString() == "True")
                            {
                                foreach (DataRow druser in dtbal.Rows)
                                {
                                    UserByUserName us = new UserByUserName();
                                    us.UserID = druser["UserID"].ToString();
                                    us.EmailID = druser["EmailID"].ToString();
                                    us.MobileNumber = druser["MobileNumber"].ToString();
                                    us.UserType = druser["UserType_x003a_Title"].ToString();
                                    us.Designation = druser["Designation"].ToString();
                                    us.ExtensionNumber = druser["ExtensionNumber"].ToString();
                                    us.FullName = druser["FullName"].ToString();
                                    us.AboutMe = druser["AboutMe"].ToString();
                                    us.AnnonymusName = druser["AnnonymusName"].ToString();
                                    us.hasGivenPreQuiz = druser["hasGivenPreQuiz"].ToString();
                                    us.hasGivenPostQuiz = druser["hasGivenPostQuiz"].ToString();
                                    us.postQuizEstimatedDate = druser["postQuizEstimatedDate"].ToString();
                                    us.GroupName = druser["GroupName"].ToString();


                                    data.Add(us);
                                }
                                Info.status = "1";
                                Info.message = "Thank you. A confirmation email will be sent to you after review.";
                                Info.UserObject = data;
                                Info.timestamp = Convert.ToString(DateTime.Now);
                                Info.isRegistered = "true";
                                Info.isWindowsUser = "true";
                                
                            }
                            else
                            {
                                Info.status = "0";
                                Info.message = "Not approved";
                                Info.UserObject = null;
                                Info.timestamp = null;
                                Info.isRegistered = "true";
                                Info.isWindowsUser = "true";
                                
                            }
                        }
                        else
                        {
                            Info.status = "0";
                            Info.message = "You need to register first";
                            Info.UserObject = null;
                            Info.timestamp = null;
                            Info.isRegistered = "false";
                            Info.isWindowsUser = "true";
                           
                        }

                    }
                    else
                    {
                        Info.status = "0";
                        Info.message = "Invalid";
                        Info.UserObject = null;
                        Info.timestamp = null;
                        Info.isRegistered = null;
                        Info.isWindowsUser = "true";
                        
                    }
                }
                else
                {
                    DataSet dsData = new DataSet();

                    dsData = balMobObj.ValidateFBAUser("ValidateFBAUsers", EmailID, Password.Trim().Replace(" ", "+"));
                    LogEvent("Service Access" + EmailID);
                    DataTable dtData = dsData.Tables[0];
                    foreach (DataRow dr in dtData.Rows)
                    {

                        if (dr["UserExists"].ToString() == "true")
                        {
                            Info.status = "1";
                            Info.message = "Valid User";
                            DataTable dtbal = new DataTable();

                            dtbal = balMobObj.GetUserByUserNameBAL(EmailID);
                            List<UserByUserName> data = new List<UserByUserName>();
                            if (dtbal.Rows.Count > 0)
                            {
                                if (dtbal.Rows[0]["isApproved"].ToString() == "True")
                                {
                                    foreach (DataRow druser in dtbal.Rows)
                                    {
                                        UserByUserName us = new UserByUserName();
                                        us.UserID = druser["UserID"].ToString();
                                        us.EmailID = druser["EmailID"].ToString();
                                        us.MobileNumber = druser["MobileNumber"].ToString();
                                        us.UserType = druser["UserType_x003a_Title"].ToString();
                                        us.Designation = druser["Designation"].ToString();
                                        us.ExtensionNumber = druser["ExtensionNumber"].ToString();
                                        us.FullName = druser["FullName"].ToString();
                                        us.AboutMe = druser["AboutMe"].ToString();
                                        us.AnnonymusName = druser["AnnonymusName"].ToString();
                                        us.hasGivenPreQuiz = druser["hasGivenPreQuiz"].ToString();
                                        us.hasGivenPostQuiz = druser["hasGivenPostQuiz"].ToString();
                                        us.postQuizEstimatedDate = druser["postQuizEstimatedDate"].ToString();
                                        us.GroupName = druser["GroupName"].ToString();
                                        data.Add(us);
                                    }
                                    Info.UserObject = data;
                                    // DateTime DateTime=new DateTime.Now();
                                    Info.timestamp = Convert.ToString(DateTime.Now);
                                    
                                }
                                else
                                {
                                    Info.status = "0";
                                    Info.message = "Not approved";
                                    Info.UserObject = null;
                                    Info.timestamp = null;
                                    Info.isRegistered = "true";
                                    Info.isWindowsUser = "false";
                                    
                                }
                            }
                            else
                            {
                                Info.status = "0";
                                Info.message = "You need to register first";
                                DataTable dtbaldt = new DataTable();

                                dtbaldt = balMobObj.GetUserByUserNameBAL(EmailID);
                                List<UserByUserName> dataUser = new List<UserByUserName>();
                                if (dtbal.Rows.Count > 0)
                                {
                                    foreach (DataRow druser in dtbaldt.Rows)
                                    {
                                        UserByUserName us = new UserByUserName();
                                        us.UserID = druser["UserID"].ToString();
                                        us.EmailID = druser["EmailID"].ToString();
                                        us.MobileNumber = druser["MobileNumber"].ToString();
                                        us.UserType = druser["UserType_x003a_Title"].ToString();
                                        us.Designation = druser["Designation"].ToString();
                                        us.ExtensionNumber = druser["ExtensionNumber"].ToString();
                                        us.FullName = druser["FullName"].ToString();
                                        us.AboutMe = druser["AboutMe"].ToString();
                                        us.AnnonymusName = druser["AnnonymusName"].ToString();
                                        us.hasGivenPreQuiz = druser["hasGivenPreQuiz"].ToString();
                                        us.hasGivenPostQuiz = druser["hasGivenPostQuiz"].ToString();
                                        us.postQuizEstimatedDate = druser["postQuizEstimatedDate"].ToString();


                                        data.Add(us);
                                    }
                                    Info.UserObject = data;
                                    // DateTime DateTime=new DateTime.Now();
                                    Info.isRegistered = "true";
                                    Info.isWindowsUser = "false";
                                    Info.timestamp = Convert.ToString(DateTime.Now);
                                    
                                }

                                else
                                {
                                    Info.status = "0";
                                    Info.message = "You need to register first";
                                    Info.isRegistered = "false";
                                    Info.isWindowsUser = "false";
                                   
                                }


                            }

                        }
                        else
                        {
                            Info.status = "0";
                            Info.message = dr["UserMessage"].ToString();
                            Info.isRegistered = null;
                            Info.isWindowsUser = "false";
                            
                        }

                    }
                    
                }
                return Info;
              
            }
            catch (Exception ex)
            {
                Authentication Info = new Authentication();
                Info.status = "0";
                Info.message = "Error During Authetication of :" + EmailID+ "-"+ ex.Message;
                Info.isRegistered = "Due to error this property is not applicable";
                Info.isWindowsUser = (EmailID.ToLower().Contains("@aku.edu")==true?"TRUE":"FALSE");
                return Info;
                
            }
        }
        //public Authentication Registration(string EmailID, string Password, string FullName, string MobileNumber,
        //    string Extension, string UserType, string AnnonymusName, string AboutMe, string Designation)
        //{
        //    Authentication Info = new Authentication();
        //    #region "Within AKU"
        //    if (EmailID.Contains("@aku"))
        //   {
        //       try
        //       {
        //           Object obj;

        //           ADHelper oADHelper = new ADHelper();
        //           bool added = false;
        //           bool Test = oADHelper.IsAuthenticated("aku", EmailID, Password, out obj);
        //           if (Test == true)
        //           {
        //               DataTable dtbal = new DataTable();
        //               dtbal = balMobObj.GetUserByUserNameBAL(EmailID);
        //               if (dtbal == null)
        //               {
        //                   //if (dtbal.Rows.Count == 0 || dtbal.Rows.Count < 0)
        //                   //{
        //                       added = balMobObj.AddListItem(EmailID, Password, FullName, MobileNumber, Extension, UserType, AnnonymusName,
        //                           AboutMe, Designation, "AKU");
        //                       if (added == true)
        //                       {
        //                           Info.status = "1";
        //                           Info.message = "User successfully registered";
        //                           Info.UserObject = null;
        //                           Info.timestamp = Convert.ToString(DateTime.Now);
        //                           return Info;
        //                       }
        //                       else
        //                       {
        //                           Info.status = "0";
        //                           Info.message = "Unsuccessfull";
        //                           Info.UserObject = null;
        //                           Info.timestamp = null;
        //                           return Info;
        //                       }
        //                  // }
        //                   //else
        //                   //{
        //                   //    Info.status = "0";
        //                   //    Info.message = "User ID already exist in system";
        //                   //    Info.UserObject = null;
        //                   //    Info.timestamp = null;
        //                   //    return Info;
        //                   //}
        //               }
        //               else
        //               {
        //                   Info.status = "0";
        //                   Info.message = "User ID already exist in system";
        //                   Info.UserObject = null;
        //                   Info.timestamp = null;
        //                   return Info;
        //               }
        //           }
        //           else
        //           {
        //               Info.status = "0";
        //               Info.message = "Unsuccessfull";
        //               Info.UserObject = null;
        //               Info.timestamp = null;
        //               return Info;
        //           }
        //       }
        //        catch(Exception ex)
        //       {
        //           Info.status = "0";
        //           Info.message = "Invalid user id or password";
        //           Info.UserObject = null;
        //           Info.timestamp = null;
        //           return Info;
        //       }
        //   }
        //    #endregion
        //    #region "Non-AKU"

        //    else
        //    {
        //        DataSet ds = new DataSet();
        //        ds=balMobObj.CheckUserNameExistBAL("CheckUserNameExist", EmailID);
        //        DataTable dt = new DataTable();
        //        dt = ds.Tables[0];
        //        foreach (DataRow dr in dt.Rows)
        //        {

        //            if (dr["UserExists"].ToString() == "true")
        //            {
        //                Info.status = "0";
        //                Info.message = "User ID already exist in system";
        //                Info.UserObject = null;
        //                Info.timestamp = Convert.ToString(DateTime.Now);
        //                return Info;
        //            }
        //            else
        //            {
        //                int RowsEffcted = 0;
        //                bool added = false;
        //                RowsEffcted = balMobObj.CreateUserBAL("aspnet_Membership_CreateUser", "/", EmailID, Password, "", EmailID,
        //                    "", "", "1", "", "", "", "", null);
        //                if (RowsEffcted > 0 && RowsEffcted < 3)
        //                {
        //                    added = balMobObj.AddListItem(EmailID, Password, FullName, MobileNumber, Extension, UserType, AnnonymusName,
        //                          AboutMe, Designation, "NONAKU");
        //                    if (added == true)
        //                    {
        //                        Info.status = "1";
        //                        Info.message = "User successfully registered";
        //                        Info.UserObject = null;
        //                        Info.timestamp = Convert.ToString(DateTime.Now);
        //                        return Info;
        //                    }
        //                    else
        //                    {
        //                        Info.status = "0";
        //                        Info.message = "Not added in list";
        //                        Info.UserObject = null;
        //                        Info.timestamp = null;
        //                        return Info;

        //                    }

        //                }
        //                else
        //                {
        //                    Info.status = "0";
        //                    Info.message = "Not added in db";
        //                    Info.UserObject = null;
        //                    Info.timestamp = null;
        //                    return Info;
        //                }
              
        //            }
                   
        //        }
        //        return Info;

        //    }
        //    #endregion
        //}
        public Authentication Registration(UserToAdd User)
        {
           // Object te = "";
            Authentication Info = new Authentication();
            #region "Within AKU"
            if (User.EmailID.Contains("@aku"))
            {
                try
                {
                    Object obj;
                    
                    ADHelper oADHelper = new ADHelper();
                    bool added = false;
                    /* new code for encryption dycrytion of password */
                    string cipherText = HttpUtility.HtmlDecode(User.Password);//.Trim().Replace(" ", "+"); ;
                    CryptLib _crypt = new CryptLib();
                    String iv = "BioEthicsMobApp1";// CryptLib.GenerateRandomIV(16); //16 bytes = 128 bits
                    string key = CryptLib.getHashSha256(settingsReader, 32); //32 bytes = 256 bits

                    String dycyptedPass = _crypt.decrypt(cipherText, key, iv);
                //    string dycyptedPass = CryptorEngine.Decrypt(cipherText, false);
                    /* end of new code for encryption dycrytion of password */
                    bool Test = oADHelper.IsAuthenticated("aku", User.EmailID, dycyptedPass, out obj);
                    if (Test == true)
                    {
                        DataTable dtbal = new DataTable();
                        dtbal = balMobObj.GetUserByUserNameBAL(User.EmailID);
                        if (dtbal == null || dtbal.Rows.Count == 0 || dtbal.Rows.Count < 0)
                        {
                            bool chckAnn = balMobObj.CheckAnnonymousName(User.AnnonymusName);
                            if (chckAnn != true)
                            {

                                added = balMobObj.AddListItem(User.EmailID, User.Password, User.FullName, User.MobileNumber,
                                    User.Extension, User.UserType, User.AnnonymusName, User.AboutMe, User.Designation, "AKU");
                                if (added == true)
                                {

                                    Info.status = "1";
                                    Info.message = "Thank you. A confirmation email will be sent to you after review.";
                                    Info.UserObject = null;
                                    Info.timestamp = Convert.ToString(DateTime.Now);
                                    return Info;
                                }
                                else
                                {
                                    Info.status = "0";
                                    Info.message = "Unsuccessfull";
                                    Info.UserObject = null;
                                    Info.timestamp = "";
                                    return Info;
                                }
                            }
                            else
                            {
                                Info.status = "0";
                                Info.message = "Annonymous name already exist";
                                Info.UserObject = null;
                                Info.timestamp = "";
                                return Info;
                            }
                          
                        }
                        else
                        {
                            Info.status = "0";
                            Info.message = "User ID already exist in system";
                            Info.UserObject = null;
                            Info.timestamp = "";
                            return Info;
                        }
                    }
                    else
                    {
                        Info.status = "0";
                        Info.message = "Unsuccessfull";
                        Info.UserObject = null;
                        Info.timestamp = "";
                        return Info;
                    }
                }
                catch (Exception ex)
                {
                    Info.status = "0";
                    Info.message = "Invalid user id or password";
                    Info.UserObject = null;
                    Info.timestamp = "";
                    return Info;
                }
            }
            #endregion
            #region "Non-AKU"

            else
            {
                DataSet ds = new DataSet();
                ds = balMobObj.CheckUserNameExistBAL("CheckUserNameExist", User.EmailID);
                DataTable dt = new DataTable();
                dt = ds.Tables[0];
                foreach (DataRow dr in dt.Rows)
                {

                    if (dr["UserExists"].ToString() == "true")
                    {
                        Info.status = "0";
                        Info.message = "User ID already exist in system";
                        Info.UserObject = null;
                        Info.timestamp = Convert.ToString(DateTime.Now);
                        return Info;
                    }
                    else
                    {
                        int RowsEffcted = 0;
                        bool added = false;
                        bool chckAnn = balMobObj.CheckAnnonymousName(User.AnnonymusName);
                        
                        if (chckAnn != true)
                        {
                            DataTable dtForPassPol = new DataTable();
                           // string decryptedPassword = null;
                            //string cipherText = User.Password.ToString().Trim();
                            //decryptedPassword = CryptorEngine.Decrypt(cipherText, false);

                            string cipherText = HttpUtility.HtmlDecode(User.Password);//.Trim().Replace(" ", "+"); ;
                            CryptLib _crypt = new CryptLib();
                            String iv = "BioEthicsMobApp1";// CryptLib.GenerateRandomIV(16); //16 bytes = 128 bits
                            string key = CryptLib.getHashSha256(settingsReader, 32); //32 bytes = 256 bits

                            String dycyptedPass = _crypt.decrypt(cipherText, key, iv);



                            dtForPassPol = balMobObj.IsValidBAL(dycyptedPass);
                            if(dtForPassPol.Rows[0]["Status"].ToString()=="true")
                            {

                            RowsEffcted = balMobObj.CreateUserBAL("aspnet_Membership_CreateUser", "/", User.EmailID, User.Password,
                                "", User.EmailID,
                                "", "", "1", "", "", "", "", null);
                            if (RowsEffcted > 0 && RowsEffcted < 3)
                            {

                                added = balMobObj.AddListItem(User.EmailID, User.Password, User.FullName, User.MobileNumber,
                                    User.Extension, User.UserType, User.AnnonymusName, User.AboutMe, User.Designation, "NONAKU");
                                if (added == true)
                                {
                                    Info.status = "1";
                                    Info.message = "Thank you. A confirmation email will be sent to you after review.";
                                    Info.UserObject = null;
                                    Info.timestamp = Convert.ToString(DateTime.Now);
                                    return Info;
                                }
                                else
                                {
                                    Info.status = "0";
                                    Info.message = "Not added in list";
                                    Info.UserObject = null;
                                    Info.timestamp = "";
                                    return Info;

                                }



                            }
                            else
                            {
                                Info.status = "0";
                                Info.message = "Not added in db";
                                Info.UserObject = null;
                                Info.timestamp = "";
                                return Info;
                            }
                        }
                            else
                            {
                                Info.status = "0";
                                Info.message = dtForPassPol.Rows[0]["Message"].ToString();
                                Info.UserObject = null;
                                Info.timestamp = "";
                                return Info;
                            }
                        }
                        else
                        {
                            Info.status = "0";
                            Info.message = "Annonymous name already exist";
                            Info.UserObject = null;
                            Info.timestamp = "";
                            return Info;
                        }

                    }

                }
                return Info;

            }
            #endregion
        }
        public UpdateProfileStatus UpdateProfile(UpdateUserInputInfo updInfo)
        {
            UpdateProfileStatus updPro = new UpdateProfileStatus();
             DataTable dtbal = new DataTable();
             dtbal = balMobObj.GetUserByUserNameBAL(updInfo.EmailID);
             if (dtbal == null)
                 {
                     updPro.status = "0";
                     updPro.message = "User does not exists";
                     return updPro;
                 }
             else if(dtbal.Rows.Count>0)
             {
                 bool updated = balMobObj.UpdateProfileBAL(updInfo.EmailID, updInfo.FullName, updInfo.MobileNumber,
                     updInfo.Extension, updInfo.UserType, updInfo.AnnonymusName, updInfo.AboutMe, updInfo.Designation);
                 if(updated==true)
                 {
                     updPro.status = "1";
                     updPro.message = "User information updated successfully";
                     return updPro;
                 }
                 else
                 {
                     updPro.status = "0";
                     updPro.message = "User not updated";
                     return updPro;
                 }
                 
                 
             }
             else
             {
                 updPro.status = "0";
                 updPro.message = "Exception occurs";
                 return updPro;
             }
        }
        public List<UserByUserName> GetUserByUserName(string UserName)
        {
            try
            {

                DataTable dtbal = new DataTable();
                dtbal = balMobObj.GetUserByUserNameBAL(UserName);
                List<UserByUserName> data = new List<UserByUserName>();

                foreach (DataRow dr in dtbal.Rows)
                {
                    UserByUserName us = new UserByUserName();
                    us.UserID = dr["UserID"].ToString();
                    us.EmailID = dr["EmailID"].ToString();
                    us.MobileNumber = dr["MobileNumber"].ToString();
                    us.UserType = dr["UserType"].ToString();
                    us.Designation = dr["Designation"].ToString();
                    us.ExtensionNumber = dr["ExtensionNumber"].ToString();
                    us.FullName = dr["FullName"].ToString();
                    


                    data.Add(us);
                }

                string sJSONResponse = JsonConvert.SerializeObject(data);
                return data;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        public ChangePasswordStatus ChangePassword(ChangePasswordInputs obj)
        {
            ChangePasswordStatus Info = new ChangePasswordStatus();
            DataSet dsbal = new DataSet();
            if (obj.EmailID.Contains("@aku"))
            {
                Info.status = "0";
                Info.message = "AKU person cannot change password from here";
                return Info;
            }
            else
            {
                DataTable dtForPassPol = new DataTable();
               // string decryptedPassword = null;
                string cipherText = obj.NewPassword.ToString().Trim();
               // decryptedPassword = CryptorEngine.Decrypt(cipherText, false);
                CryptLib _crypt = new CryptLib();
                String iv = "BioEthicsMobApp1";// CryptLib.GenerateRandomIV(16); //16 bytes = 128 bits
                string key = CryptLib.getHashSha256(settingsReader, 32); //32 bytes = 256 bits

                String decryptedPassword = _crypt.decrypt(cipherText, key, iv);
                dtForPassPol = balMobObj.IsValidBAL(decryptedPassword);
                if (dtForPassPol.Rows[0]["Status"].ToString() == "true")
                {
                    dsbal = balMobObj.ChangePasswordBAL("ChangePassword", obj.EmailID, obj.CurrentPassword, obj.NewPassword);
                    if (dsbal.Tables.Count > 0)
                    {
                        DataTable dtData = dsbal.Tables[0];
                        foreach (DataRow dr in dtData.Rows)
                        {

                            if (dr["Updated"].ToString() == "true")
                            {
                                Info.status = "1";
                                Info.message = "Profile Updated";

                            }
                            else
                            {
                                Info.status = "0";
                                Info.message = "Wrong email id or password";

                            }
                        }
                        return Info;
                    }
                    else
                    {
                        Info.status = "0";
                        Info.message = "Some internel exception";
                        return Info;
                    }
                }
                else
                {
                    Info.status = "0";
                    Info.message = dtForPassPol.Rows[0]["Message"].ToString();
                    
                    return Info;
                }
            }
        }
        public ForgetPasswordStatus ForgetPassword(string EmailID)
        {
            ForgetPasswordStatus Info = new ForgetPasswordStatus();
            DataSet dsbal = new DataSet();
            if (EmailID.Contains("@aku"))
            {
                Info.status = "0";
                Info.message = "You can not retrieve password from here";
                return Info;
            }
            else
            {
                DataSet ds = new DataSet();
                ds = balMobObj.CheckUserNameExistBAL("CheckUserNameExist", EmailID);
                DataTable dt = new DataTable();
                if (ds != null && ds.Tables[0]!=null)
                {
                    dt = ds.Tables[0];
                    foreach (DataRow dr in dt.Rows)
                    {

                        if (dr["UserExists"].ToString() == "true")
                        {
                            bool PassSend = false;
                            PassSend = balMobObj.ForgetPasswordBAL("ForgetPassword", EmailID);
                            if(PassSend==true)
                            {
                                Info.status = "1";
                                Info.message = "Password send successfully";
                                return Info;
                            }
                            else
                            {
                                Info.status = "1";
                                Info.message = "not sent";
                                return Info;
                            }
                        }
                        else
                        {
                            Info.status = "0";
                            Info.message = "User does not exist";
                            return Info;
                        }
                    }
                    return Info;
                }
                else
                {
                    Info.status = "0";
                    Info.message = "User does not exist";
                    return Info;
                }
            }
        }
        public CheckAnnonymous CheckAnnonymousName(string Name)
        {
            CheckAnnonymous chkan = new CheckAnnonymous();
            bool chckAnn = balMobObj.CheckAnnonymousName(Name);
            chkan.IsExist = chckAnn.ToString();
            return chkan;

        }
        public ResponseOfGetAllUserType GetAllUserType()
        {
            ResponseOfGetAllUserType res = new ResponseOfGetAllUserType();
            List<UserTypeListList> typeList = new List<UserTypeListList>();

            DataTable dtbal = new DataTable();
            dtbal = balMobObj.GetAllUserTypeBAL();
            if (dtbal != null && dtbal.Rows.Count > 0)
            {

                foreach (DataRow dr in dtbal.Rows)
                {
                    UserTypeListList usrty = new UserTypeListList();
                    usrty.ID = dr["ID"].ToString();
                    usrty.Title = dr["Title"].ToString();
                    typeList.Add(usrty);

                }
                res.Status = "1";
                res.Message = "Success";
                res.UserTypeListList = typeList;

            }
            else
            {
                res.Status = "0";
                res.Message = "Failiur";
                res.UserTypeListList = null;
            }

            return res;
        }
        //public DataTable CheckPasswordPolicy(string Password)
        //{
        //    return balMobObj.IsValidBAL(Password);
        //}

        #endregion
        #region "Discussion"
        public ResponseOfGetAllDiscussion GetAllDiscussions(string CategoryID,string EmailID,string PageSize, string PageInfo, string StartDate, string EndDate)
        {
            ResponseOfGetAllDiscussion respDb = new ResponseOfGetAllDiscussion();
            if(CategoryID!=null && EmailID!=null && PageSize!=null && PageInfo!=null && StartDate!=null && EndDate!=null )
            {

           
            List<DiscussionBoardDetails> dbres = new List<DiscussionBoardDetails>();
            DataTable dtbal = new DataTable();
            dtbal = balMobObj.GetAllDiscussionsBAL( CategoryID,EmailID,PageSize, PageInfo, StartDate, EndDate);
            if(dtbal !=null && dtbal.Rows.Count>0)
            {
                respDb.statusId = "1";
                respDb.message = "Success";
                foreach (DataRow dr in dtbal.Rows)
                {
                    DiscussionBoardDetails db = new DiscussionBoardDetails();
                    db.DiscussionID = dr["ID"].ToString();
                    db.Topic = dr["Title"].ToString();
                    db.Description = dr["Body"].ToString();
                    db.Replies = dr["ItemChildCount"].ToString();
                    db.Date = dr["Created"].ToString();
                    db.StartedBy = dr["StartedBy"].ToString();
                    db.Category = dr["Category"].ToString();
                    if (dr["ImageByte"].ToString() != null & dr["ImageByte"].ToString() != "")
                    {

                        db.ImageByte = new[] { dr["ImageByte"].ToString() };
                        //string strImgArrs = dr["ImageByte"].ToString();
                        //db.ImageByte = strImgArrs.Select(c => c.ToString()).ToArray();
                    }
                    else
                    {
                        db.ImageByte = ("-1" as object) as string[];
                    }
                   if (dr["IsFavourite"].ToString() != "" && dr["IsFavourite"].ToString() != null)
                    
                    {
                        db.IsFavourite = dr["IsFavourite"].ToString();
                    }
                    else
                    {
                        db.IsFavourite = "-1";
                    }
                    dbres.Add(db);
                    respDb.PageInfo = dr["PageInfo"].ToString();
                }
                respDb.DiscussionDetails = dbres;
            }
            else
            {
                respDb.statusId = "0";
                respDb.message = "Failiur";
                respDb.DiscussionDetails = null;
            }

        }
            else
            {
                respDb.statusId = "0";
                respDb.message = "parameter error";
                respDb.DiscussionDetails = null;
            }

            return respDb;
        }
        public ResponseOfGetDiscussionByID GetDiscussionByID(string DiscussionID, string EmailID)
        {
            ResponseOfGetDiscussionByID respDbbyId =new ResponseOfGetDiscussionByID();
            DataTable dtbal = new DataTable();
            if (DiscussionID != null && EmailID!=null)
            { 
            dtbal = balMobObj.GetDiscussionByIDBAL(DiscussionID, EmailID);
            DiscussionBoardDetails db = new DiscussionBoardDetails();
            if(dtbal !=null && dtbal.Rows.Count>0)
            {
                foreach (DataRow dr in dtbal.Rows)
                {

                    db.DiscussionID = dr["ID"].ToString();
                    db.Topic = dr["Title"].ToString();
                    db.Description = dr["Body"].ToString();
                    db.Replies = dr["ItemChildCount"].ToString();
                    db.Category = dr["Category"].ToString();
                    db.Date = dr["Created"].ToString();
                    db.StartedBy = dr["StartedBy"].ToString();

                    if (dr["ImageByte"].ToString() != null & dr["ImageByte"].ToString() != "")
                    {
                        string[] strImgArr = dr["ImageByte"] as string[];
                        db.ImageByte = strImgArr;
                    }
                    else
                    {
                        db.ImageByte = new[] { "-1" };
                    }
                    
                    if (dr["statusId"].ToString() != "" && dr["statusId"].ToString() != null)
                    {
                        respDbbyId.statusId = dr["statusId"].ToString();
                        respDbbyId.message = dr["message"].ToString();
                    }
                    else
                    {
                        respDbbyId.statusId = "1";
                        respDbbyId.message = "Success";
                        respDbbyId.DiscussionDetails = db;
                    }
                    if (dr["IsFavourite"].ToString() != "" && dr["IsFavourite"].ToString() != null)
                    {
                        db.IsFavourite = dr["IsFavourite"].ToString();
                    }
                    else
                    {
                        db.IsFavourite = false.ToString();
                    }
                    if (dr["ImageByte"].ToString() != "" && dr["ImageByte"].ToString() != null)
                    {
                        string[] newStrArr=new string[]{dr["ImageByte"].ToString()};
                        db.ImageByte = newStrArr;
                    }
                    else
                    {
                        db.ImageByte = null;
                    }

                }
            }
            else
            {
                respDbbyId.statusId = "0";
                respDbbyId.message = "Failiur";
                respDbbyId.DiscussionDetails = null;

            }

            }
            else
            {
                respDbbyId.statusId = "0";
                respDbbyId.message = "Error in parameters";
                respDbbyId.DiscussionDetails = null;
            }

            return respDbbyId;
        }
        public ResponseOfGetAllReplies GetRepliesOfDiscussion(string DiscussionID)
        {

            ResponseOfGetAllReplies res = new ResponseOfGetAllReplies();
            if(DiscussionID!=null)
            {

            DataTable dtbal = new DataTable();
            dtbal = balMobObj.GetRepliesOfDiscussionBAL(DiscussionID);
            List<MessagesDetails> Info = new List<MessagesDetails>();
            if (dtbal != null && dtbal.Rows.Count > 0)
            {
                foreach (DataRow dr in dtbal.Rows)
                {
                    MessagesDetails db = new MessagesDetails();
                    db.ReplyID = dr["ID"].ToString();
                    db.ReplyMessage = dr["Body"].ToString();
                    db.CreatedDate = dr["Created"].ToString() +" "+ dr["Time"].ToString();
                    db.Time = dr["Time"].ToString();
                    db.StartedBy = dr["StartedBy"].ToString();
                    if (dr["statusId"].ToString() != "" && dr["statusId"].ToString() != null)
                    {
                        res.statusId = dr["statusId"].ToString();
                        res.message = dr["message"].ToString();
                    }
                    else
                    {
                        res.statusId = "1";
                        res.message = "Success";

                    }
                    Info.Add(db);
                    res.MessagesDetails = Info;
                }
            }
            else
            {
                MessagesDetails db = new MessagesDetails();
                db.ReplyID = null;
                db.ReplyMessage = null;
                db.CreatedDate = null;
                res.statusId = "0";
                res.message = "Replies does not exist";
                
                res.MessagesDetails = null;
            }
        }
            else
            {
                MessagesDetails db = new MessagesDetails();
                db.ReplyID = null;
                db.ReplyMessage = null;
                db.CreatedDate = null;
                res.statusId = "0";
                res.message = "Parameter error";

                res.MessagesDetails = null;
            }

            return res;
        }
       public GeneralStatus CreateNewDiscussion(CreateNewDiscussionDetails obj)
        //public GeneralStatus CreateNewDiscussion(string Topic, string Body, string StartedBy, string IdOfCategory, string[] ImageByte)
     
       {
            GeneralStatus db = new GeneralStatus();
            try
            {
                bool retVal = balMobObj.CreateNewDiscussionBAL(obj.Topic, obj.Body, obj.StartedBy,obj.EmailID, obj.IdOfCategory, obj.ImageByte);
               
                if (retVal)
                {
                    db.statusId = "1";
                    db.message = "Success";
                }
                else
                {
                    db.statusId = "0";
                    db.message = "Failiur";
                }
                
            }
          catch(Exception ex)
            {
                db.statusId = "0";
                db.message = "Failiure due to parameter issue";
          }
            return db;
        }
        public GeneralStatus ReplyOnDiscussion(CreateNewReplyDetails obj)
        {
            bool ret = balMobObj.ReplyOnDiscussionBAL(obj.DiscussionID, obj.Body, obj.StartedBy);
            GeneralStatus db = new GeneralStatus();
            if (ret)
            {
                db.statusId = "1";
                db.message = "Success";
            }

            return db;
        }
        #endregion
        #region "FeedBack"
        public ResponseOfAddFeedBack CreateFeedBack(CreateFeedBackDetails obj)
      //  public ResponseOfAddFeedBack CreateFeedBack(string EmailID, string Subject, string Comments, string[] ImageByte)
        {
            //CreateFeedBackDetails obj = new CreateFeedBackDetails();
            //obj.EmailID = EmailID;
            //obj.Subject = Subject;
            //obj.Comments = Comments;
            //obj.ImageByte = ImageByte;
            ResponseOfAddFeedBack res = new ResponseOfAddFeedBack();
            bool retAdded = false;
            if (obj.EmailID != null && obj.EmailID != "" && obj.Subject != null && obj.Subject != "" && obj.Comments != null
                && obj.Comments != "")
            {
                retAdded = balMobObj.CreateFeedBackBAL(obj.EmailID, obj.Subject, obj.Comments,obj.ImageByte);
                if (retAdded)
                {
                    res.statusId = "1";
                    res.message = "Successfully send";
                    return res;
                }
                else
                {
                    res.statusId = "0";
                    res.message = "Feed Back not added";
                    return res;
                }

            }
            else
            {
                res.statusId = "0";
                res.message = "Invalid parameters";
                return res;
            }


        }
        #endregion
        #region "Favourites"
        public ResponseOfGetAllFavouritesByID GetAllFavrourites(string EmailID, string PageSize, string PageInfo)
        {
            DataTable dtbal = new DataTable();
            ResponseOfGetAllFavouritesByID res = new ResponseOfGetAllFavouritesByID();
            List<FavouritesDetail> lstFav = new List<FavouritesDetail>();
            dtbal = balMobObj.GetFavrouritesBAL(EmailID, PageSize, PageInfo);


            if (dtbal != null &&  dtbal.Rows.Count > 0)
            {
                foreach (DataRow dr in dtbal.Rows)
                {
                    FavouritesDetail fav = new FavouritesDetail();
                    fav.FavouriteID = dr["ID"].ToString();
                    fav.ItemID = dr["ItemID"].ToString();
                    fav.TypeOfFavourite = dr["TypeOfFavourite"].ToString();
                    fav.Title = dr["TitleOfFav"].ToString();
                    fav.Description = dr["DescriptionOfFav"].ToString();
                    fav.Date = dr["Created"].ToString();
                    fav.Time = dr["Time"].ToString();
                    lstFav.Add(fav);
                    res.PageInfo = dr["PageInfo"].ToString();
                }
                res.StatusID = "1";
                res.Message = "Success";
                res.FavouritesDetail = lstFav;
                return res;
            }
            else
            {
                res.StatusID = "0";
                res.Message = "There is no favourite item";
                res.FavouritesDetail = null;
                return res;
            }
        }
        public ResponseOfAddToFavourites AddToFavourite(InputsOfAddingToFavourites obj)
        {
            bool res = false;
            ResponseOfAddToFavourites resp = new ResponseOfAddToFavourites();
            res = balMobObj.AddToFavouriteBAL(obj.EmailID, obj.ItemID, obj.TypeOfFavourite);
            if(res)
            {
                resp.statusId = "1";
                resp.message = "Successfully marked as favourite";
                return resp;
            }
            else
            {
                resp.statusId = "0";
                resp.message = "Not added";
                return resp;
            }
        }
        public ResponseOfRemovingFavourite RemoveFromFavourite(RemoveFromFavObj obj)
        {
            ResponseOfRemovingFavourite resp = new ResponseOfRemovingFavourite();
            if (obj != null)
            {
                bool res = false;
               
                res = balMobObj.RemoveFromFavouriteBAL(obj.FavouriteID, obj.ItemID, obj.EmailID, obj.TypeOfFavourite);
                if (res)
                {
                    resp.statusId = "1";
                    resp.message = "Successfully removed";

                }
                else
                {
                    resp.statusId = "0";
                    resp.message = "Not deleted";

                }
            }
            else
            {
                resp.statusId = "0";
                resp.message = "Input object is null or empty";
            }
            return resp;
        }
        #endregion
        #region "Category"
        public ResponseOfGetAllCategoriesList GetAllCategoriesList()
        {
            ResponseOfGetAllCategoriesList res = new ResponseOfGetAllCategoriesList();
            List<CategoryList> CatList = new List<CategoryList>();
            
            DataTable dtbal = new DataTable();
            dtbal = balMobObj.GetAllCategoriesListBAL();
            if (dtbal != null && dtbal.Rows.Count > 0)
            {

                foreach (DataRow dr in dtbal.Rows)
                {
                    CategoryList cat = new CategoryList();
                    cat.ID = dr["ID"].ToString();
                    cat.Title = dr["CategoryName"].ToString();
                    CatList.Add(cat);

                }
                res.Status = "1";
                res.Message = "Success";
                res.CategoryList = CatList;

            }
            else
            {
                res.Status = "0";
                res.Message = "Failiur";
                res.CategoryList = null;
            }

            return res;
        }
        #endregion
        #region "Videos"
        public ResponseOfVideoDetails GetAllVideos(string EmailID,string PageSize, string PageInfo)
        {

            ResponseOfVideoDetails res = new ResponseOfVideoDetails();
            List<NormalVideoDetails> infonormal = new List<NormalVideoDetails>();
            List<LiveVideoDetails> infoliv = new List<LiveVideoDetails>();
            DataTable dtbal = new DataTable();
            dtbal = balMobObj.GetAllVideosBAL( EmailID,PageSize, PageInfo);
            if (dtbal != null && dtbal.Rows.Count > 0)
            {

                foreach (DataRow dr in dtbal.Rows)
                {
                    if (dr["TypeOfVideo"].ToString() == "Normal")
                    {
                        NormalVideoDetails infonor = new NormalVideoDetails();
                        infonor.VideoID = dr["ID"].ToString();
                        infonor.Url = dr["Title"].ToString();
                        if (dr["IsFavourite"].ToString() != "" && dr["IsFavourite"].ToString() != null)
                        {
                            infonor.IsFavourite = dr["IsFavourite"].ToString();
                        }
                        infonor.HeadingOfVideo = dr["HeadingOfVid"].ToString();
                        infonor.Description = dr["Description"].ToString();
                        infonor.CreatedOn = dr["Created"].ToString();
                        int pos = dr["Title"].ToString().LastIndexOf("/") + 1;
                        string idOfVid = dr["Title"].ToString().Substring(pos, dr["Title"].ToString().Length - pos);
                        infonor.Thumbnail = "http://img.youtube.com/vi/" + idOfVid + "/0.jpg";
                        infonormal.Add(infonor);
                    }
                    else if (dr["TypeOfVideo"].ToString() == "Live")
                    {
                        LiveVideoDetails infolive = new LiveVideoDetails();
                        infolive.VideoID = dr["ID"].ToString();
                        infolive.Url = dr["Title"].ToString();
                        if (dr["IsFavourite"].ToString() != "" && dr["IsFavourite"].ToString() != null)
                        {
                            infolive.IsFavourite = dr["IsFavourite"].ToString();
                        }
                        infolive.HeadingOfVideo = dr["HeadingOfVid"].ToString();
                        infolive.Description = dr["Description"].ToString();
                        infolive.CreatedOn = dr["Created"].ToString();
                        int pos = dr["Title"].ToString().LastIndexOf("/") + 1;
                        string idOfVid = dr["Title"].ToString().Substring(pos, dr["Title"].ToString().Length - pos);
                        infolive.Thumbnail = "http://img.youtube.com/vi/" + idOfVid + "/0.jpg";
                        infoliv.Add(infolive);
                    }
                    res.Status = "1";
                    res.Message = "Success";
                    res.PageInfo = dr["PageInfo"].ToString();
                    res.NormalVideo = infonormal;
                    res.LiveVideo = infoliv;

                }

            }
            else
            {
                res.Status = "0";
                res.Message = "Fail";
                res.NormalVideo = null;
                res.LiveVideo = null;
            }

            return res;
        }
        public ResponseOfGetVideoDetailByID GetVideoDetailByID(string VideoID, string EmailID)
        {
            ResponseOfGetVideoDetailByID res = new ResponseOfGetVideoDetailByID();
            List<ResponseOfGetVideoDetailByIDList> lst = new List<ResponseOfGetVideoDetailByIDList>();
            DataTable dtbal = new DataTable();
            dtbal = balMobObj.GetVideoDetailByIDBAL(VideoID, EmailID);
            if (dtbal != null && dtbal.Rows.Count > 0)
            {
                foreach (DataRow dr in dtbal.Rows)
                {
                    ResponseOfGetVideoDetailByIDList itm = new ResponseOfGetVideoDetailByIDList();
                    itm.Url = dr["Title"].ToString();
                    int pos = dr["Title"].ToString().LastIndexOf("/") + 1;
                    string idOfVid = dr["Title"].ToString().Substring(pos, dr["Title"].ToString().Length - pos);
                    itm.Thumbnail = "http://img.youtube.com/vi/" + idOfVid + "/0.jpg";
                    itm.Type = dr["TypeOfVideo"].ToString();
                    itm.IsFavourite = dr["IsFavourite"].ToString();
                    itm.HeadingOfVideo = dr["HeadingOfVid"].ToString();
                    itm.Description = dr["Description"].ToString();
                    itm.CreatedOn = dr["Created"].ToString();
                    lst.Add(itm);
                }
                res.StatusId = "1";
                res.Message = "Success";
                res.ResponseOfGetVideoDetailByIDList = lst;
               
            }
            else
            {
                res.StatusId = "0";
                res.Message = "Fail";
                res.ResponseOfGetVideoDetailByIDList = null;
               
            }

            return res;
        }
        public ResponseGetCommentsOfVideoByID GetCommentsOfVideoByID(string VideoID)
        {
            ResponseGetCommentsOfVideoByID res = new ResponseGetCommentsOfVideoByID();
            List<ResponseGetCommentsOfVideoByIDList> info = new List<ResponseGetCommentsOfVideoByIDList>();
           
            DataTable dtbal = new DataTable();
            dtbal = balMobObj.GetCommentsOfVideoByIDBAL(VideoID);
            if (dtbal != null && dtbal.Rows.Count > 0)
            {

                foreach (DataRow dr in dtbal.Rows)
                {
                     ResponseGetCommentsOfVideoByIDList infonor = new ResponseGetCommentsOfVideoByIDList();
                     infonor.CommentID=dr["ID"].ToString();
                     //infonor.EmailID=dr["EmailID"].ToString();
                     infonor.Comment=dr["Comment"].ToString();
                     infonor.CommentedBy = dr["CommentedBy"].ToString();
                    // infonor.AnnonymousName=dr["EmailID_x003a_AnnonymusName"].ToString();
                     infonor.Created = dr["Created"].ToString();
                        info.Add(infonor);
                 }
                  
                    res.StatusId = "1";
                    res.Message = "Success";
                    res.ResponseGetCommentsOfVideoByIDList = info;
                    

                }

          
            else
            {
                    res.StatusId = "1";
                    res.Message = "Success";
                    res.ResponseGetCommentsOfVideoByIDList = null;
                    
            }

            return res;
        }
        public GeneralStatus CommentOnVideo(CreateNewCommentOnVidInput obj)
        {
            GeneralStatus res = new GeneralStatus();
            
            
            bool ret = balMobObj.CommentOnVideoBAL(obj);
            if (ret)
            {
                res.statusId = "1";
                res.message = "Success";
            }
            else
            {
                res.statusId = "0";
                res.message = "Fail";
            }

            return res;
        }
        #endregion
        #region "Learning Material"


        public ResponseOfGetAllTopics GetAllTopics()
        {
            ResponseOfGetAllTopics res = new ResponseOfGetAllTopics();
            List<TopicList> CatList = new List<TopicList>();

            DataTable dtbal = new DataTable();
            dtbal = balMobObj.GetAllTopicsBAL();
            if (dtbal != null && dtbal.Rows.Count > 0)
            {

                foreach (DataRow dr in dtbal.Rows)
                {
                    TopicList cat = new TopicList();
                    cat.ID = dr["ID"].ToString();
                    cat.Title = dr["TopicTitle"].ToString();
                    CatList.Add(cat);

                }
                res.Status = "1";
                res.Message = "Success";
                res.TopicList = CatList;

            }
            else
            {
                res.Status = "0";
                res.Message = "Failiur";
                res.TopicList = null;
            }

            return res;
        }
        public ResponseOfGetAllDocument GetAllDocument(string RowLimit, string PageInfo, string EmailID)
        {
            ResponseOfGetAllDocument res = new ResponseOfGetAllDocument();
            List<ResponseOfGetAllDocumentList> docList = new List<ResponseOfGetAllDocumentList>();

            DataTable dtbal = new DataTable();
            dtbal = balMobObj.GetAllDocumentBAL(RowLimit, PageInfo, EmailID);
            if (dtbal != null && dtbal.Rows.Count > 0)
            {

                foreach (DataRow dr in dtbal.Rows)
                {
                    ResponseOfGetAllDocumentList doc = new ResponseOfGetAllDocumentList();
                    doc.DocID = dr["ID"].ToString();
                    doc.TitleOfDoc = dr["Title"].ToString();
                    doc.Category = dr["Category"].ToString();
                    doc.CategoryId = dr["Category_x003a_ID"].ToString();
                    doc.Topic = dr["Topic"].ToString();
                    doc.TopicId = dr["Topic_x003a_ID"].ToString();
                    if (dr["IsFavourite"] != null && dr["IsFavourite"].ToString() != "")
                    {
                        doc.IsFavourite = dr["IsFavourite"].ToString();
                        doc.FavouriteID = dr["FavouriteID"].ToString();
                       
                  
                    }
                    else
                    {
                        doc.IsFavourite = "-1";
                        doc.FavouriteID = "-1";
                    }
                    if (dr["PostQuiz"].ToString() == "")
                    {
                        doc.PostQuizId = "-1";
                        doc.PostQuizName = "-1";
                    }
                    else
                    {
                        doc.PostQuizId = dr["PostQuiz_x003a_ID"].ToString();
                        doc.PostQuizName = dr["PostQuiz"].ToString();
                    }
                    if (dr["PreQuiz"].ToString() == "")
                    {
                        doc.PreQuizId = "-1";
                        doc.PreQuizName = "-1";
                    }
                    else
                    {
                        doc.PreQuizId = dr["PreQuiz_x003a_ID"].ToString();
                        doc.PreQuizName = dr["PreQuiz"].ToString();
                    }
                   
                    res.PageInfo = dr["PageInfo"].ToString();
                    docList.Add(doc);

                }
                res.Status = "1";
                res.Message = "Success";
                res.ResponseOfGetAllDocumentList = docList;

            }
            else
            {
                res.Status = "0";
                res.Message = "Failiur";
                res.ResponseOfGetAllDocumentList = null;
            }

            return res;
        }
        public ResponseOfGetQuiz GetQuiz(string QuizID)
        {
            ResponseOfGetQuiz res = new ResponseOfGetQuiz();
            List<ResponseOfGetQuizList> quizlst = new List<ResponseOfGetQuizList>();
            

            DataTable dtbal = new DataTable();
            dtbal = balMobObj.GetQuizBAL(QuizID);
            if (dtbal != null && dtbal.Rows.Count > 0)
            {

                foreach (DataRow dr in dtbal.Rows)
                {
                    ResponseOfGetQuizList lst = new ResponseOfGetQuizList();
                    
                    lst.QuestionID = dr["ID"].ToString();
                    lst.Question = dr["QuestionNew"].ToString();
                    lst.Type = dr["QuestionType"].ToString();

                    lst.Options = dr["Options"].ToString().Replace(",","|");
                    List<OptionsArray> arrylst = new List<OptionsArray>();
                    List<string> TagIds = new List<string>(dr["Options"].ToString().Split(','));
                    //foreach (var i in TagIds)
                    //{
                        
                    //    OptionsArray arry = new OptionsArray();
                        
                    //    arry.Value = i;
                    //    arrylst.Add(arry);
                    //}
                    OptionsArray arry = new OptionsArray();
                    if (dr["Option1"].ToString() != "" && dr["Option1"].ToString() != null)
                    {
                        OptionsArray arryval1 = new OptionsArray();
                        arryval1.Value = dr["Option1"].ToString();
                        arrylst.Add(arryval1);
                    }
                    if (dr["Option2"].ToString() != "" && dr["Option2"].ToString() != null)
                    {
                        OptionsArray arryval2 = new OptionsArray();
                        arryval2.Value = dr["Option2"].ToString();
                        arrylst.Add(arryval2);
                    }
                    if (dr["Option3"].ToString() != "" && dr["Option3"].ToString() != null)
                    {
                        OptionsArray arryval3 = new OptionsArray();
                        arryval3.Value = dr["Option3"].ToString();
                        arrylst.Add(arryval3);
                    }
                    if (dr["Option4"].ToString() != "" && dr["Option4"].ToString() != null)
                    {
                        OptionsArray arryval4 = new OptionsArray();
                        arryval4.Value = dr["Option4"].ToString();
                        arrylst.Add(arryval4);
                    }
                    if (dr["Option5"].ToString() != "" && dr["Option5"].ToString() != null)
                    {
                        OptionsArray arryval5 = new OptionsArray();
                        arryval5.Value = dr["Option5"].ToString();
                        arrylst.Add(arryval5);
                    }

                    lst.OptionsArray = arrylst;

                    quizlst.Add(lst);
                    res.QuizName = dr["QuizName"].ToString();
                }
                
                res.Status = "1";
                res.Message = "Success";
                res.ResponseOfGetQuizList = quizlst;

            }
            else
            {
                res.Status = "0";
                res.Message = "Failiur";
                res.ResponseOfGetQuizList = null;
            }

            return res;
        }
        public ResponseOfQuizResponse QuizResponse(InputObjForQuizResponse obj)
        {
            ResponseOfQuizResponse res = new ResponseOfQuizResponse();
            List<ResponseOfQuizResponseList> lst = new List<ResponseOfQuizResponseList>();
            DataTable dtbal = new DataTable();
            dtbal = balMobObj.QuizResponseBAL(obj);
            if (dtbal != null && dtbal.Rows.Count > 0)
            {

                
                res.StatusId = "1";
                res.Message = "Success";
                foreach(DataRow dr in dtbal.Rows)
                {
                ResponseOfQuizResponseList lstdet = new ResponseOfQuizResponseList();
                lstdet.TotalQuestionCount = dr["TotalQuesCount"].ToString();
                lstdet.CorrectAnsCount = dr["CorrectAnsCount"].ToString();
                lstdet.QuizName = dr["QuizName"].ToString();
                lstdet.Date = dr["Date"].ToString();
                lst.Add(lstdet);
               }
                res.ResponseOfQuizResponseList = lst;
            }
            else
            {
                res.StatusId = "0";
                res.Message = "Failiur";
                res.ResponseOfQuizResponseList = null;
            }

            return res;
        }
        public Stream GetDocumentByID(string DocID)
        {
            ResponseOfDownloadDoc res = new ResponseOfDownloadDoc();
            //DataTable dt = new DataTable();
            if (balMobObj.GetDocumentByIDBAL(DocID) != null)
            {
                return balMobObj.GetDocumentByIDBAL(DocID);
            }
            else
            {
                return null;
            }
        }

        public ResponseOfGetAllArticle GetAllArticle(string RowLimit, string PageInfo, string EmailID)
        {
            ResponseOfGetAllArticle res = new ResponseOfGetAllArticle();
            List<ResponseOfGetAllArticleList> docList = new List<ResponseOfGetAllArticleList>();

            DataTable dtbal = new DataTable();
            dtbal = balMobObj.GetAllArticleBAL(RowLimit, PageInfo, EmailID);
            if (dtbal != null && dtbal.Rows.Count > 0)
            {

                foreach (DataRow dr in dtbal.Rows)
                {
                    ResponseOfGetAllArticleList doc = new ResponseOfGetAllArticleList();
                    doc.ID = dr["ID"].ToString();
                    doc.TitleOfArticle = dr["Title"].ToString();
                    doc.ArticleBody = dr["ArticleBody"].ToString();
                    doc.CategoryName = dr["Category"].ToString();
                    doc.CategoryId = dr["Category_x003a_ID"].ToString();
                    doc.TopicName = dr["TopicName"].ToString();
                    doc.TopicId = dr["TopicName_x003a_ID"].ToString();
                    if (dr["IsFavourite"] != null && dr["IsFavourite"].ToString() != "")
                    {
                        doc.IsFavourite = dr["IsFavourite"].ToString();
                        doc.FavouriteID = dr["FavouriteID"].ToString();
                    }
                    else
                    {
                        doc.IsFavourite = "-1";
                        doc.FavouriteID = "-1";
                    }
                    if (dr["PostQuiz"].ToString() == "")
                    {
                        doc.PostQuizId = "-1";
                        doc.PostQuiz = "-1";
                    }
                    else
                    {
                        doc.PostQuizId = dr["PostQuiz_x003a_ID"].ToString();
                        doc.PostQuiz = dr["PostQuiz"].ToString();
                    }
                    if (dr["PreQuiz"].ToString() == "")
                    {
                        doc.PreQuizId = "-1";
                        doc.PreQuiz = "-1";
                    }
                    else
                    {
                        doc.PreQuizId = dr["PreQuiz_x003a_ID"].ToString();
                        doc.PreQuiz = dr["PreQuiz"].ToString();
                    }
                   
                    res.PageInfo = dr["PageInfo"].ToString();
                    docList.Add(doc);

                }
                res.Status = "1";
                res.Message = "Success";
                res.ResponseOfGetAllArticleList = docList;

            }
            else
            {
                res.Status = "0";
                res.Message = "Failiur";
                res.ResponseOfGetAllArticleList = null;
            }

            return res;
        }
        public ResponseOfGetAllArticle GetArticleByID(string ID)
        {
            ResponseOfGetAllArticle res = new ResponseOfGetAllArticle();
            List<ResponseOfGetAllArticleList> docList = new List<ResponseOfGetAllArticleList>();
            DataTable dt = new DataTable();
            dt = balMobObj.GetArticleByIDBAL(ID);
            if (dt != null && dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    ResponseOfGetAllArticleList doc = new ResponseOfGetAllArticleList();
                    doc.ID = dr["ID"].ToString();
                    doc.TitleOfArticle = dr["Title"].ToString();
                    doc.ArticleBody = dr["ArticleBody"].ToString();
                    doc.CategoryName = dr["Category"].ToString();
                    doc.CategoryId = dr["Category_x003a_ID"].ToString();
                    doc.TopicName = dr["TopicName"].ToString();
                    doc.TopicId = dr["TopicName_x003a_ID"].ToString();
                    if (dr["PostQuiz"].ToString() == "")
                    {
                        doc.PostQuizId = "-1";
                        doc.PostQuiz = "-1";
                    }
                    else
                    {
                        doc.PostQuizId = dr["PostQuiz_x003a_ID"].ToString();
                        doc.PostQuiz = dr["PostQuiz"].ToString();
                    }
                    if (dr["PreQuiz"].ToString() == "")
                    {
                        doc.PreQuizId = "-1";
                        doc.PreQuiz = "-1";
                    }
                    else
                    {
                        doc.PreQuizId = dr["PreQuiz_x003a_ID"].ToString();
                        doc.PreQuiz = dr["PreQuiz"].ToString();
                    }
                    
                   
                    docList.Add(doc);

                }
                res.Status = "1";
                res.Message = "Success";
                res.ResponseOfGetAllArticleList = docList;


            }

            else
            {
                res.Status = "0";
                res.Message = "Failiur";
                res.ResponseOfGetAllArticleList = null;
            }



            return res; 
        }
        public ResponseOfGetUserResultResponse GetResultOfUser(string EmailID)
        {
            ResponseOfGetUserResultResponse res = new ResponseOfGetUserResultResponse();
            List<ResponseOfGetUserResultResponseList> docList = new List<ResponseOfGetUserResultResponseList>();
            DataTable dt = new DataTable();
            dt = balMobObj.GetResultOfUserBAL(EmailID);
            if (dt != null && dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    ResponseOfGetUserResultResponseList doc = new ResponseOfGetUserResultResponseList();
                    doc.QuizName = dr["QuizName"].ToString();
                    doc.TotalNumOfQues = dr["TotalNoOfQues"].ToString();
                    doc.CorrectAnsCount = dr["CorrectNoOfQues"].ToString();
                    doc.Date = dr["Date"].ToString();
                    int obt = Convert.ToInt32(doc.CorrectAnsCount);
                    int tot = Convert.ToInt32(doc.TotalNumOfQues);
                    double div =(double)obt / (double)tot ;
                    double perc = div * 100;
                    doc.TotalPercentage = perc.ToString();
                    docList.Add(doc);

                }
                res.Status = "1";
                res.Message = "Success";
                res.ResponseOfGetUserResultResponseList = docList;


            }

            else
            {
                res.Status = "0";
                res.Message = "No result found";
                res.ResponseOfGetUserResultResponseList = null;
            }



            return res; 
        }

        /*we were using this in previous approach*/



        //public TestPurpose GetLearningMaterialByID(string ID)
        //{
        //    TestPurpose res = new TestPurpose();
        //    DataTable dt = new DataTable();
        //    dt = balMobObj.GetLearningMaterialByIDBAL(ID);
        //    res.Status = "1";

        //    return res;
           
        //}

       
        //public ResponseOfGetDocumentByTopicID GetDocumentByTopic(string TopicID)
        //{
        //    DataTable dt = new DataTable();
        //    ResponseOfGetDocumentByTopicID resp = new ResponseOfGetDocumentByTopicID();
        //    dt = balMobObj.GetDocumentByTopicBAL(TopicID);
        //    if (dt.Rows.Count>0)
        //    {
        //        resp.Status = "1";
        //        resp.Message = "Successfully removed";
        //        return resp;
        //    }
        //    else
        //    {
        //        resp.Status = "0";
        //        resp.Message = "Not deleted";
        //        return resp;
        //    }
        //}
        #endregion
        #region "Search from all"
        public SearchResponse SearchFromAll(string SearchQuery, string RowLimit, string PageInfo)
        {
            SearchResponse res = new SearchResponse();
            List<SearchResponseList> lst = new List<SearchResponseList>();

            DataTable dtbal = new DataTable();
            dtbal = balMobObj.SeacrhingFromAllBAL(SearchQuery, RowLimit, PageInfo);
            if (dtbal != null && dtbal.Rows.Count > 0)
            {
                foreach (DataRow dr in dtbal.Rows)
                {
                    SearchResponseList reslst = new SearchResponseList();
                    reslst.ItemID = dr["ItemId"].ToString();
                    reslst.Title = dr["Title"].ToString();
                    reslst.Description = dr["Description"].ToString();
                    reslst.Type = dr["Type"].ToString();
                    reslst.Created = dr["Created"].ToString();
                    res.PageInfo = dr["PageInfo"].ToString();
                    lst.Add(reslst);
                }
                res.StatusId = "1";
                res.Message = "Success";

                res.SearchResList = lst;
            }
            else
            {
                res.StatusId = "0";
                res.Message = "Fail";
                res.SearchResList = null;
            }


            return res;
        }
        #endregion
        #region "Testing"
        public Res SearchInDoc(string Query)
        {
            Res r = new Res();
            DataTable dtbal = new DataTable();
            dtbal = balMobObj.TestSearchInDocBAL(Query);
            return r;
        }

        public void LogEvent(string LogDescription)
        {
            if (!EventLog.SourceExists("BioEithicsWebService"))
            {
                //An event log source should not be created and immediately used.
                //There is a latency time to enable the source, it should be created
                //prior to executing the application that uses the source.
                //Execute this sample a second time to use the new source.
                EventLog.CreateEventSource("BioEithicsWebService", "WebServices");
                // The source is created.  Exit the application to allow it to be registered.
                return;
            }

            // Create an EventLog instance and assign its source.
            EventLog myLog = new EventLog();
            myLog.Source = "BioEithicsWebService";

            // Write an informational entry to the event log.    
            myLog.WriteEntry(LogDescription);
        }
        public TestPurpose TestForReadingCustom()
        {
            DataTable dtbal = new DataTable();
            dtbal = balMobObj.TestForReadingCustomBAL();
            TestPurpose test = new TestPurpose();
            test.Status = "1";
            return test;
        }
        public Res Test(string PageSize, string PageInfo)
        {
            Res r = new Res();
            List<ResponseOfTest> res = new List<ResponseOfTest>();

            DataTable dtbal = new DataTable();
            dtbal = balMobObj.TestBAL(PageSize, PageInfo);
            if (dtbal != null && dtbal.Rows.Count > 0)
            {

                foreach (DataRow dr in dtbal.Rows)
                {

                }

            }
            else
            {
                ResponseOfTest test = new ResponseOfTest();
                test.ID = "";
                test.FirstName = "";
                test.Title = "";
                res.Add(test);
            }

            return r;
        }
        //public ResponseOfGetAllDoc GetDocumentByID(string ID)
        //{
        //    ResponseOfGetAllDoc FinRes = new ResponseOfGetAllDoc();
        //    List<GetAllDocRes> res = new List<GetAllDocRes>();

        //    byte[] arr = new byte[256];

        //    res = balMobObj.DownloadDocumentByID(ID);
        //    if (res != null && res.Count > 0)
        //    {
        //        FinRes.StatusID = "1";
        //        FinRes.Message = "Success";
        //        FinRes.PageInfo = null;
        //        FinRes.GetAllDocRes = res;

        //    }
        //    else
        //    {
        //        FinRes.StatusID = "0";
        //    }


        //    return FinRes;
        //}
        public Res GetDocument()
        {
            Res r = new Res();
            List<ResponseOfTest> res = new List<ResponseOfTest>();

            DataTable dtbal = new DataTable();
            byte[] arr = new byte[256];
            // arr = balMobObj.GetDocumentBAL();
            if (dtbal != null && dtbal.Rows.Count > 0)
            {

                foreach (DataRow dr in dtbal.Rows)
                {
                    ResponseOfTest test = new ResponseOfTest();
                    test.ID = dr["ID"].ToString();
                    test.FirstName = dr["FirstName"].ToString();
                    test.Title = dr["Title"].ToString();
                    res.Add(test);

                }

            }
            else
            {
                ResponseOfTest test = new ResponseOfTest();
                test.ID = "";
                test.FirstName = "";
                test.Title = "";
                res.Add(test);
            }

            return r;
        }


        #endregion

    }
}
