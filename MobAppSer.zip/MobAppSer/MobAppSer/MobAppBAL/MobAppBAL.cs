﻿using System;
using System.Collections.Generic;
using Microsoft.SharePoint.Client;
using SP = Microsoft.SharePoint.Client;
using Microsoft.SharePoint.Client.Search;
using Microsoft.SharePoint.Client.Search.Query;
using MobAppSer;
using System.Data;
using System.Linq;
using System.Data.Entity;
using System.Data;
using System.Data.Common;
using System.Data.Entity;
using System.Data.EntityClient;
using System.Data.Metadata.Edm;
using System.Data.Objects;
using DBDAL;
using constants;
using System.IO;
using Novacode;
using MimeTypes;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Schema;
using System.Reflection;
using System.Net;
using System.ServiceModel.Web;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.Applications;
using Microsoft.SharePoint.Client.Search;
using com.pakhee.common;



namespace BAL.MobAppBAL
{
   public class MobAppBAL
    {
       public string SiteUrl { get { return System.Configuration.ConfigurationSettings.AppSettings["SiteUrl"].ToString(); } }
       public string UserName { get { return System.Configuration.ConfigurationSettings.AppSettings["UserName"].ToString(); } }
       public string Password { get { return System.Configuration.ConfigurationSettings.AppSettings["Password"].ToString(); } }
       public static string settingsReader { get { return System.Configuration.ConfigurationSettings.AppSettings["SecurityKey"].ToString(); } }
       
       public Microsoft.SharePoint.Client.ListItemCollectionPosition itemPosition { get; set; }
        private DBHelper objdl = null;
       

        public MobAppBAL()
        {
            objdl = new DBHelper("FBACon");
        }


        #region "Users"
        /* for authentication from DB of form based users */
        public DataSet ValidateFBAUser(string prname,string EmailID,string password)
        {

            try
            {
                //string clearText = password.Trim();
                //string cipherText = CryptorEngine.Encrypt(clearText, true);
                DBParameterCollection dbparacol = new DBParameterCollection();

                DBParameter dbEmailID = new DBParameter("@EmailId", EmailID);
                DBParameter dbPass = new DBParameter("@Password", password);
                dbparacol.Add(dbEmailID);
                dbparacol.Add(dbPass);
                DataSet dsBAL = new DataSet();
                dsBAL = objdl.ExecuteDataSet(prname, dbparacol, CommandType.StoredProcedure);

                return dsBAL;
            }
            catch (Exception ex)
            {
                throw ex;
            }
           


        }


       /* for creating user of FBA in DB */

        public int CreateUserBAL(string prname,string AppName, string username, string password,string PassSalt,
            string Email,string passQues,string PassAnswer,string isApproved,string CurrentTimeUtc,string CreateDate,
            string UniqueEmail ,string PasswordFormat,string UserID)
        {
            //string clearText = password.Trim();
            //string cipherText = CryptorEngine.Encrypt(clearText, true);
          
            DBParameterCollection dbparacol = new DBParameterCollection();

            DBParameter dbAppName = new DBParameter("@ApplicationName", AppName);
            DBParameter dbusername = new DBParameter("@UserName", username);
            DBParameter dbpassword = new DBParameter("@Password", password);
            DBParameter dbPassSalt = new DBParameter("@PasswordSalt", PassSalt);
            DBParameter dbEmail = new DBParameter("@Email", Email);
            DBParameter dbpassQues = new DBParameter("@PasswordQuestion", passQues);
            DBParameter dbPassAnswer = new DBParameter("@PasswordAnswer", PassAnswer);
            DBParameter dbisApproved = new DBParameter("@IsApproved", isApproved);
            DBParameter dbCurrentTimeUtc = new DBParameter("@CurrentTimeUtc", CurrentTimeUtc);
            DBParameter dbCreateDate = new DBParameter("@CreateDate", CreateDate);
            DBParameter dbUniqueEmail = new DBParameter("@UniqueEmail", UniqueEmail);
            DBParameter dbPasswordFormat = new DBParameter("@PasswordFormat", PasswordFormat);
            DBParameter dbUserID = new DBParameter("@UserId", DBNull.Value, DbType.String, ParameterDirection.Output, 200);

            dbparacol.Add(dbAppName);
            dbparacol.Add(dbusername);
            dbparacol.Add(dbpassword);
            dbparacol.Add(dbPassSalt);
            dbparacol.Add(dbEmail);
            dbparacol.Add(dbpassQues);
            dbparacol.Add(dbPassAnswer);
            dbparacol.Add(dbisApproved);
            dbparacol.Add(dbCurrentTimeUtc);
            dbparacol.Add(dbCreateDate);
            dbparacol.Add(dbUniqueEmail);
            dbparacol.Add(dbPasswordFormat);
            dbparacol.Add(dbUserID);

            int rowsAffcted = objdl.ExecuteNonQuery(prname, dbparacol, CommandType.StoredProcedure);


            return rowsAffcted;


        }

       /* For Chccking FBA user exist in DB*/

        public DataSet CheckUserNameExistBAL(string prname, string EmailID)
        {

            DBParameterCollection dbparacol = new DBParameterCollection();

            DBParameter dbEmailID = new DBParameter("@EmailID", EmailID);

            dbparacol.Add(dbEmailID);
            
            DataSet dsBAL = new DataSet();
            dsBAL = objdl.ExecuteDataSet(prname, dbparacol, CommandType.StoredProcedure);

            return dsBAL;


        }
       
       /* Adding in SP List both AKU and NONAKU */
        
        public bool AddListItem(string EmailID, string PasswordForList, string FullName, string MobileNumber,
            string Extension, string UserType, string AnnonymusName, string AboutMe, string Designation,string Type)
        {
            try
            {
                MobAppSer.ParameterHelperCommon paramHelp = new MobAppSer.ParameterHelperCommon();
                paramHelp.URL = SiteUrl;
                paramHelp.UserID = UserName;
                paramHelp.Password = Password;
                paramHelp.ListName = "UserExtendedProperties";
                bool isValidate = MobAppSer.SPClientHelper.ValidateLogin(paramHelp);
                ClientContext clientContext = MobAppSer.SPClientHelper.ConnectToSite(paramHelp);

                Web w = clientContext.Web;
                var lists = clientContext.LoadQuery(w.Lists);

                clientContext.Load(w);
                Microsoft.SharePoint.Client.List list = w.Lists.GetByTitle(paramHelp.ListName);
                clientContext.Load(list);


                SP.List oList = clientContext.Web.Lists.GetByTitle("UserExtendedProperties");

                ListItemCreationInformation itemCreateInfo = new ListItemCreationInformation();
                ListItem oListItem = oList.AddItem(itemCreateInfo);
                oListItem["EmailID"] = EmailID;
                oListItem["AboutMe"] = AboutMe;
                oListItem["AnnonymusName"] = AnnonymusName;
                oListItem["Designation"] = Designation;
                oListItem["Domain"] = Type;
                oListItem["ExtensionNumber"] = Extension;
                oListItem["FullName"] = FullName;
                oListItem["MobileNumber"] = MobileNumber;
                
                oListItem["UserType"] = UserType;

                oListItem.Update();

                clientContext.ExecuteQuery();
                AddUsersInGroup(EmailID, "Bioethics Members", Type);
                EmailHelper emailObj = new EmailHelper();
                emailObj.EmailTo = EmailID;
                emailObj.EmailCC = "bioethicsapp@aku.edu";
                emailObj.EmailFrom = EmailID;
                emailObj.EmailSubject = "New Registration For BioethicsApp";
               // emailObj.EmailBody = "New user has been register. kindly approve or reject his/her registeration from admin link";
                emailObj.EmailBody = "Thankyou for registration, we are looking into your request. A confirmation email will be send to you after review.";

                EmailHelper.SendEmail(emailObj);

                EmailHelper emailObj2 = new EmailHelper();
                emailObj2.EmailTo = "bioethicsapp@aku.edu";
                emailObj2.EmailCC = "farah.salman@aku.edu";
                emailObj2.EmailFrom = EmailID;
                emailObj2.EmailSubject = "New Registration For BioethicsApp";
                emailObj2.EmailBody = "New user has been register. kindly approve or reject his/her registeration from admin link";
               // emailObj2.EmailBody = "Thankyou for registration, we are looking into your request. A confirmation email will be send to you after review.";

                EmailHelper.SendEmail(emailObj2);

                return true;

            }
           catch(Exception ex)
            {
                return false;
                throw ex;

            }
        }

       /* Adding users in group */
        public void AddUsersInGroup(string EmailID, string groupName,string Type)
        {
            if(Type=="NONAKU")
            { 
            string username = EmailID.Remove(EmailID.IndexOf("@"));
            if (username != null && groupName != null)
            {
                MobAppSer.ParameterHelperCommon paramHelp = new MobAppSer.ParameterHelperCommon();
                paramHelp.URL = SiteUrl;
                paramHelp.UserID = UserName;
                paramHelp.Password = Password;
                paramHelp.ListName = "UserExtendedProperties";
                bool isValidate = MobAppSer.SPClientHelper.ValidateLogin(paramHelp);
                ClientContext clientContext = MobAppSer.SPClientHelper.ConnectToSite(paramHelp);

                Web w = clientContext.Web;
                var lists = clientContext.LoadQuery(w.Lists);

                clientContext.Load(w);
                // User member = w.EnsureUser(@"i:0#.f|sql_membership|testuser15@gmail.com");
                User member = w.EnsureUser(@"i:0#.f|sql_membership|" + EmailID);
                GroupCollection groupCollection = w.SiteGroups;

                clientContext.Load(groupCollection);
                clientContext.ExecuteQuery();

                foreach (Group group in groupCollection)
                {
                    if (group.Title.Equals(groupName))
                    {
                        group.Users.AddUser(member);
                        group.Update();
                        w.Update();
                        clientContext.ExecuteQuery();
                    }
                }
            }
            }
            else if(Type=="AKU")
            {
                string username = EmailID.Remove(EmailID.IndexOf("@"));
                if (username != null && groupName != null)
                {
                    MobAppSer.ParameterHelperCommon paramHelp = new MobAppSer.ParameterHelperCommon();
                    paramHelp.URL = SiteUrl;
                    paramHelp.UserID = UserName;
                    paramHelp.Password = Password;
                    paramHelp.ListName = "UserExtendedProperties";
                    bool isValidate = MobAppSer.SPClientHelper.ValidateLogin(paramHelp);
                    ClientContext clientContext = MobAppSer.SPClientHelper.ConnectToSite(paramHelp);

                    Web w = clientContext.Web;
                    var lists = clientContext.LoadQuery(w.Lists);

                    clientContext.Load(w);
                    User member = w.EnsureUser(@"i:0#.w|aku\" + username);
                    GroupCollection groupCollection = w.SiteGroups;

                    clientContext.Load(groupCollection);
                    clientContext.ExecuteQuery();

                    foreach (Group group in groupCollection)
                    {
                        if (group.Title.Equals(groupName))
                        {
                            group.Users.AddUser(member);
                            group.Update();
                            w.Update();
                            clientContext.ExecuteQuery();
                        }
                    }
                }

            }
        }

       /* Updating profile in sp list */
       public bool UpdateProfileBAL(string EmailID,string FullName, string MobileNumber, string Extension,
             string UserType, string AnnonymusName, string AboutMe, string Designation)
        {
            
            MobAppSer.ParameterHelperCommon paramHelp = new MobAppSer.ParameterHelperCommon();
            paramHelp.URL = SiteUrl;
            paramHelp.UserID = UserName;
            paramHelp.Password = Password;
            paramHelp.ListName = "UserExtendedProperties";

            bool isValidate = MobAppSer.SPClientHelper.ValidateLogin(paramHelp);
            ClientContext clientContext = MobAppSer.SPClientHelper.ConnectToSite(paramHelp);

            Web w = clientContext.Web;
            var lists = clientContext.LoadQuery(w.Lists);

            clientContext.Load(w);
            Microsoft.SharePoint.Client.List list = w.Lists.GetByTitle(paramHelp.ListName);
            clientContext.Load(list);


            List<string> strConditionsOrderBy = new List<string>();

            strConditionsOrderBy.Add(CAMLHelper.GetCAMLFieldRefCondition(UsersProperties.Columns.EmailID.ToString(), CAMLHelper.DataType.Text, EmailID.ToString(), CAMLHelper.OpeatorType.Equal, false));
            string FinalCondition = CAMLHelper.MergeCAMLConditions(strConditionsOrderBy, CAMLHelper.MergeType.And, true);
            paramHelp.CAMLQuery = "<View><Query>" + FinalCondition + "</View></Query>";


            paramHelp.CAMLQuery=FinalCondition;


            ListItemCollection listitemCol = MobAppSer.SPClientHelper.GetRecordsByCAML(paramHelp,FullName,MobileNumber,
                 Extension,UserType,AnnonymusName, AboutMe, Designation);
            if (listitemCol==null)
            {
                return false;
            }
            else
            {
                return true;
            }

        }

       /* Getting group in which user exit */
       public string GetGroup(string EmailID)
       {
           System.Text.StringBuilder sb = new System.Text.StringBuilder();

               MobAppSer.ParameterHelperCommon paramHelp = new MobAppSer.ParameterHelperCommon();
            paramHelp.URL = SiteUrl;
            paramHelp.UserID = UserName;
            paramHelp.Password = Password;
            paramHelp.ListName = "UserExtendedProperties";
            bool isValidate = MobAppSer.SPClientHelper.ValidateLogin(paramHelp);
            ClientContext clientContext = MobAppSer.SPClientHelper.ConnectToSite(paramHelp);

            Web w = clientContext.Web;
            var lists = clientContext.LoadQuery(w.Lists);

            clientContext.Load(w);
            Microsoft.SharePoint.Client.List list = w.Lists.GetByTitle(paramHelp.ListName);
            clientContext.Load(list);     
                  
           GroupCollection collGroup = clientContext.Web.SiteGroups;

                  clientContext.Load(collGroup);

                  clientContext.Load(collGroup,
                  groups => groups.Include(
                  group => group.Users));

                  clientContext.ExecuteQuery();
                  
                  DataTable dt = new DataTable();
                  dt.Columns.Add("GroupName");
                  string strGrpNam=null;
                  foreach (Group oGroup in collGroup)
                   {
                     UserCollection collUser = oGroup.Users;

                     foreach (User oUser in collUser)
                       {
                           if (oUser.Email == EmailID)
                      
                        {
                            if (strGrpNam != null)
                            {
                                strGrpNam = strGrpNam + "," + oGroup.Title;
                            }
                            else
                            {
                                strGrpNam = oGroup.Title;
                            }
                                                   
                       
                        }


                        }
                     }
                  return strGrpNam;
                }
   

       /* Getting user from SP List by email */
        public DataTable GetUserByUserNameBAL(string UserNamestr)
        {
           
            MobAppSer.ParameterHelperCommon paramHelp = new MobAppSer.ParameterHelperCommon();
            paramHelp.URL = SiteUrl;
            paramHelp.UserID = UserName;
            paramHelp.Password = Password;
            paramHelp.ListName = "UserExtendedProperties";
            bool isValidate = MobAppSer.SPClientHelper.ValidateLogin(paramHelp);



            ClientContext clientContext = MobAppSer.SPClientHelper.ConnectToSite(paramHelp);

            Web w = clientContext.Web;
            var lists = clientContext.LoadQuery(w.Lists);

            clientContext.Load(w);
            Microsoft.SharePoint.Client.List list = w.Lists.GetByTitle(paramHelp.ListName);
            clientContext.Load(list);


            List<string> strConditionsOrderBy = new List<string>();

            strConditionsOrderBy.Add(CAMLHelper.GetCAMLFieldRefCondition("EmailID", CAMLHelper.DataType.Text, UserNamestr, CAMLHelper.OpeatorType.Equal, false));
            string FinalCondition = CAMLHelper.MergeCAMLConditions(strConditionsOrderBy, CAMLHelper.MergeType.And,true);


            CamlQuery camlQuery = new CamlQuery();
            //camlQuery.ViewXml = "<View><Query><FieldRef Name='Title'/></Query></View>";
           // camlQuery.ViewXml = "<Where><Eq><FieldRef Name='UserName'/><Value Type='Text'>farahsalman</Value></Eq></Where>";
            camlQuery.ViewXml = FinalCondition;


            ListItemCollection ListColletion = list.GetItems(camlQuery);
            clientContext.Load(list);
            clientContext.Load(ListColletion);
            DataTable dt = new DataTable();
            string strGrp=null;
            clientContext.ExecuteQuery();
            strGrp=GetGroup(UserNamestr);
            dt = ConvertListCollInDatatable(ListColletion);
            if (dt != null)
            {
                DataView dv1 = dt.DefaultView;

                dv1.RowFilter = "EmailID='" + UserNamestr.Trim() + "'";
                DataTable dtNew = dv1.ToTable();
                dtNew.Columns.Add("GroupName");
                foreach (DataRow dr in dtNew.Rows)
                {
                    dr["GroupName"] = strGrp;
                }
                return dtNew;
            }
            else
            {
                dt = null;
                return dt;
            }



        }

       /*checking unique annonymous name */
       public bool CheckAnnonymousName(string annNam)
        {
            MobAppSer.ParameterHelperCommon paramHelp = new MobAppSer.ParameterHelperCommon();
            paramHelp.URL = SiteUrl;
            paramHelp.UserID = UserName;
            paramHelp.Password = Password;
            paramHelp.ListName = "UserExtendedProperties";
            bool isValidate = MobAppSer.SPClientHelper.ValidateLogin(paramHelp);



            ClientContext clientContext = MobAppSer.SPClientHelper.ConnectToSite(paramHelp);

            Web w = clientContext.Web;
            var lists = clientContext.LoadQuery(w.Lists);

            clientContext.Load(w);
            Microsoft.SharePoint.Client.List list = w.Lists.GetByTitle(paramHelp.ListName);
            clientContext.Load(list);


            List<string> strConditionsOrderBy = new List<string>();

            strConditionsOrderBy.Add(CAMLHelper.GetCAMLFieldRefCondition("AnnonymusName".ToString(), CAMLHelper.DataType.Text, annNam.ToString(), CAMLHelper.OpeatorType.Equal, false));
            string FinalCondition = CAMLHelper.MergeCAMLConditions(strConditionsOrderBy, CAMLHelper.MergeType.And, true);

           paramHelp.CAMLQuery = "<View Scope='RecursiveAll'><Query>" + FinalCondition + "</View></Query>";

            SP.CamlQuery query = new SP.CamlQuery();
            query.ViewXml = paramHelp.CAMLQuery;

            var ListitemChck = list.GetItems(query);

          

           // ListItemCollection ListColletion = list.GetItems(camlQuery);
            clientContext.Load(list);
            clientContext.Load(ListitemChck);
            DataTable dt = new DataTable();
            //string strGrp = null;
            clientContext.ExecuteQuery();
           // strGrp = GetGroup(UserNamestr);
            dt = ConvertListCollInDatatable(ListitemChck);
            if (dt != null)
            {
                return true;
                //DataView dv1 = dt.DefaultView;

                //dv1.RowFilter = "EmailID='" + UserNamestr.Trim() + "'";
                //DataTable dtNew = dv1.ToTable();
                //dtNew.Columns.Add("GroupName");
                //foreach (DataRow dr in dtNew.Rows)
                //{
                //    dr["GroupName"] = strGrp;
                //}
                //return dtNew;
            }
            else
            {
                return false;
                //dt = null;
                //return dt;
            }


        }

       /* converting to datatable */
        public DataTable ConvertListCollInDatatable(ListItemCollection listColl)
        {
            DataTable table = new DataTable();
            if (listColl.Count > 0)
            {
                foreach (var field in listColl[0].FieldValues.Keys)
                {
                    table.Columns.Add(field);
                }
                foreach (var item in listColl)
                {
                    DataRow dr = table.NewRow();

                    foreach (var obj in item.FieldValues)
                    {
                        if (obj.Value != null)
                        {
                            string key = obj.Key;
                            string type = obj.Value.GetType().FullName;

                            if (type == "Microsoft.SharePoint.Client.FieldLookupValue")
                            {
                                dr[obj.Key] = ((FieldLookupValue)obj.Value).LookupValue;
                            }
                            else if (type == "Microsoft.SharePoint.Client.FieldUserValue")
                            {
                                dr[obj.Key] = ((FieldUserValue)obj.Value).LookupValue;
                            }
                            else if (type == "Microsoft.SharePoint.Client.FieldUserValue[]")
                            {
                                FieldUserValue[] multValue = (FieldUserValue[])obj.Value;
                                foreach (FieldUserValue fieldUserValue in multValue)
                                {
                                    dr[obj.Key] += (fieldUserValue).LookupValue;
                                }
                            }
                            else if (type == "System.DateTime")
                            {
                                if (obj.Value.ToString().Length > 0)
                                {
                                    var date = obj.Value.ToString().Split(' ');
                                    if (date[0].Length > 0)
                                    {
                                        dr[obj.Key] = date[0];
                                    }
                                }
                            }
                            else
                            {
                                dr[obj.Key] = obj.Value;
                            }
                        }
                        else
                        {
                            dr[obj.Key] = null;
                        }
                    }
                    table.Rows.Add(dr);
                }
                return table;
            }
            else
            {
                table = null;
                return table;
            }
            
        }


       /* changing current password */
        public DataSet ChangePasswordBAL(string ProcName,string EmailID, string CurrentPassword, string NewPassword)
        {
            //string currPass = CurrentPassword.Trim();
            //string currPassEnc = CryptorEngine.Encrypt(currPass, true);

            //string newPass = NewPassword.Trim();
            //string newPassEnc = CryptorEngine.Encrypt(newPass, true);
          

            DBParameterCollection dbparacol = new DBParameterCollection();
            DBParameter dbEmailID = new DBParameter("@EmailId", EmailID);
            DBParameter dbCurrentPassword = new DBParameter("@CurrentPassword", CurrentPassword);
            DBParameter dbNewPassword = new DBParameter("@NewPassword", NewPassword);

            dbparacol.Add(dbEmailID);
            dbparacol.Add(dbCurrentPassword);
            dbparacol.Add(dbNewPassword);

            DataSet dsBAL = new DataSet();
            dsBAL = objdl.ExecuteDataSet(ProcName, dbparacol, CommandType.StoredProcedure);

            return dsBAL;

        }




        /* forget password bal func for retrival of password on non aku in email */
        public bool ForgetPasswordBAL(string ProcName, string EmailID)
        {
            
            

            DBParameterCollection dbparacol = new DBParameterCollection();
            DBParameter dbEmailID = new DBParameter("@EmailId", EmailID);
           

            dbparacol.Add(dbEmailID);
          

            DataSet dsBAL = new DataSet();
            dsBAL = objdl.ExecuteDataSet(ProcName, dbparacol, CommandType.StoredProcedure);
             DataTable dt = new DataTable();
             string decryptedPassword = null;
             if (dsBAL != null && dsBAL.Tables[0] != null)
             {
                 dt = dsBAL.Tables[0];
                 foreach (DataRow dr in dt.Rows)
                 {

                     if (dr["Password"].ToString()!=null)
                     {
                         string cipherText = dr["Password"].ToString().Trim();
                         CryptLib _crypt = new CryptLib();
                         String iv = "BioEthicsMobApp1";// CryptLib.GenerateRandomIV(16); //16 bytes = 128 bits
                         string key = CryptLib.getHashSha256(settingsReader, 32); //32 bytes = 256 bits

                         decryptedPassword = _crypt.decrypt(cipherText, key, iv);
                         
                     }
                 }

                 EmailHelper emailObj = new EmailHelper();
                 emailObj.EmailTo = EmailID;
                 emailObj.EmailCC = "farah.salman@aku.edu";
                 emailObj.EmailFrom = "bioethicsapp@aku.edu";
                 emailObj.EmailSubject = "Retrival of Password";
                 emailObj.EmailBody = "Your password is: "+decryptedPassword;

                 EmailHelper.SendEmail(emailObj);
                 return true;
             }
             else
             {
                 return false;

             }
           

        }
        /*for getting all user type list */
        public DataTable GetAllUserTypeBAL()
        {
            MobAppSer.ParameterHelperCommon paramHelp = new MobAppSer.ParameterHelperCommon();
            paramHelp.URL = SiteUrl;
            paramHelp.UserID = UserName;
            paramHelp.Password = Password;
            paramHelp.ListName = "UserExtendedProperties";
            bool isValidate = MobAppSer.SPClientHelper.ValidateLogin(paramHelp);

            ClientContext clientContext = MobAppSer.SPClientHelper.ConnectToSite(paramHelp);

            Web w = clientContext.Web;
            clientContext.Load(w);
            var list = w.Lists.GetByTitle("UserType");
            clientContext.Load(list);

            List<string> strConditionsOrderBy = new List<string>();
            SP.CamlQuery query = new SP.CamlQuery();
            var qry = SP.CamlQuery.CreateAllFoldersQuery();
            var type = list.GetItems(query);
            clientContext.Load(type);
            clientContext.ExecuteQuery();
            DataTable dt = new DataTable();

            dt = ConvertListCollInDatatable(type);

            return dt;
        }


       /* checking password policy*/
           public DataTable IsValidBAL(string Password)
            {

                return PasswordPolicy.IsValid(Password);
            }





        #endregion
        #region "Discussion"
        /* For get all discussion from discussion board */
        public DataTable GetAllDiscussionsBAL(string CategoryID,string EmailID,string RowLimit, string PageInfo,string StartDate,string EndDate)
        {
            MobAppSer.ParameterHelperCommon paramHelp = new MobAppSer.ParameterHelperCommon();
            paramHelp.URL = SiteUrl;
            paramHelp.UserID = UserName;
            paramHelp.Password = Password;
            paramHelp.ListName = "UserExtendedProperties";
            bool isValidate = MobAppSer.SPClientHelper.ValidateLogin(paramHelp);

            ClientContext clientContext = MobAppSer.SPClientHelper.ConnectToSite(paramHelp);

            Web w = clientContext.Web;

            clientContext.Load(w);
            GroupCollection collGroup = clientContext.Web.SiteGroups;

            clientContext.Load(collGroup);

            clientContext.Load(collGroup,
            groups => groups.Include(
            group => group.Users));
            bool isUserExist = false;
            clientContext.ExecuteQuery();
            foreach (Group oGroup in collGroup)
            {
                UserCollection collUser = oGroup.Users;
                if (oGroup.Title == "CommitteeMembers")
                {
                    foreach (User oUser in collUser)
                    {
                        try
                        {
                           if( oUser.Email == EmailID)
                           {
                               isUserExist = true;
                           }
                        }
                        catch (Exception ex)
                        {
                          
                        }


                    }
                }
            }
            var list = w.Lists.GetByTitle("Discussion Board");
            clientContext.Load(list);
            ListItemCollection discussionItems=null ;
            if(isUserExist==false)
            {

           
             List<string> strConditionsOrderBy = new List<string>();
            //  strConditionsOrderBy.Add(CAMLHelper.GetCAMLFieldRefCondition("FSObjType".ToString(), CAMLHelper.DataType.Integer, "1".ToString(), CAMLHelper.OpeatorType.Equal, false));
           
                strConditionsOrderBy.Add(CAMLHelper.GetCAMLFieldRefCondition("ContentType".ToString(), CAMLHelper.DataType.Text, "Discussion".ToString(), CAMLHelper.OpeatorType.Equal, false));
                strConditionsOrderBy.Add(CAMLHelper.GetCAMLFieldRefCondition("IsPrivate".ToString(), CAMLHelper.DataType.Text, "False".ToString(), CAMLHelper.OpeatorType.Equal, false));
            
                if (CategoryID != null && CategoryID != "")
             {
                 strConditionsOrderBy.Add(CAMLHelper.GetCAMLFieldRefCondition("Category_x003a_ID".ToString(), CAMLHelper.DataType.Text, CategoryID.ToString(), CAMLHelper.OpeatorType.Equal, false));
             }
             string FinalCondition = CAMLHelper.MergeCAMLConditions(strConditionsOrderBy, CAMLHelper.MergeType.And, true);
             paramHelp.CAMLQuery = "<View Scope='RecursiveAll'><Query><OrderBy><FieldRef Name=Created  Ascending='False'/></OrderBy> " + FinalCondition + "</Query><RowLimit>" + RowLimit + "</RowLimit></View>";
             Microsoft.SharePoint.Client.ListItemCollectionPosition test = new ListItemCollectionPosition();
           test.PagingInfo = "Paged=TRUE&" + PageInfo;
            

             SP.CamlQuery query = new SP.CamlQuery();
             if (StartDate != "" && StartDate != null && EndDate != "" && EndDate != null)
             {
                 query.ViewXml = "<View Scope='RecursiveAll'><Query><OrderBy><FieldRef Name=Created  Ascending='False'/></OrderBy><Where><And><And><Geq><FieldRef Name='Created' /><Value Type='DateTime'>" + StartDate + "T00:00:00Z</Value></Geq><Leq><FieldRef Name='Created' /><Value Type='DateTime'>" + EndDate + "T00:00:00Z</Value></Leq></And><Eq><FieldRef Name='ContentType'/><Value Type='Text'>Discussion</Value></Eq></And></Where></Query><RowLimit>" + RowLimit + "</RowLimit></View>";
             }
             else
             {
                 query.ViewXml = paramHelp.CAMLQuery;
             }
          
            query.ListItemCollectionPosition = test;

           // var qry = SP.CamlQuery.CreateAllFoldersQuery();

             discussionItems = list.GetItems(query);
            clientContext.Load(discussionItems);
            clientContext.ExecuteQuery();
            itemPosition = discussionItems.ListItemCollectionPosition;
            }
            else
            {

                List<string> strConditionsOrderBy = new List<string>();
                //  strConditionsOrderBy.Add(CAMLHelper.GetCAMLFieldRefCondition("FSObjType".ToString(), CAMLHelper.DataType.Integer, "1".ToString(), CAMLHelper.OpeatorType.Equal, false));

                strConditionsOrderBy.Add(CAMLHelper.GetCAMLFieldRefCondition("ContentType".ToString(), CAMLHelper.DataType.Text, "Discussion".ToString(), CAMLHelper.OpeatorType.Equal, false));
               // strConditionsOrderBy.Add(CAMLHelper.GetCAMLFieldRefCondition("IsPrivate".ToString(), CAMLHelper.DataType.Text, "true".ToString(), CAMLHelper.OpeatorType.Equal, false));

                if (CategoryID != null && CategoryID != "")
                {
                    strConditionsOrderBy.Add(CAMLHelper.GetCAMLFieldRefCondition("Category_x003a_ID".ToString(), CAMLHelper.DataType.Text, CategoryID.ToString(), CAMLHelper.OpeatorType.Equal, false));
                }
                string FinalCondition = CAMLHelper.MergeCAMLConditions(strConditionsOrderBy, CAMLHelper.MergeType.And, true);
                paramHelp.CAMLQuery = "<View Scope='RecursiveAll'><Query><OrderBy><FieldRef Name=Created  Ascending='False'/></OrderBy> " + FinalCondition + "</Query><RowLimit>" + RowLimit + "</RowLimit></View>";
                Microsoft.SharePoint.Client.ListItemCollectionPosition test = new ListItemCollectionPosition();
                test.PagingInfo = "Paged=TRUE&" + PageInfo;


                SP.CamlQuery query = new SP.CamlQuery();
                if (StartDate != "" && StartDate != null && EndDate != "" && EndDate != null)
                {
                    query.ViewXml = "<View Scope='RecursiveAll'><Query><OrderBy><FieldRef Name=Created  Ascending='False'/></OrderBy><Where><And><And><Geq><FieldRef Name='Created' /><Value Type='DateTime'>" + StartDate + "T00:00:00Z</Value></Geq><Leq><FieldRef Name='Created' /><Value Type='DateTime'>" + EndDate + "T00:00:00Z</Value></Leq></And><Eq><FieldRef Name='ContentType'/><Value Type='Text'>Discussion</Value></Eq></And></Where></Query><RowLimit>" + RowLimit + "</RowLimit></View>";
                }
                else
                {
                    query.ViewXml = paramHelp.CAMLQuery;
                }

                query.ListItemCollectionPosition = test;

                // var qry = SP.CamlQuery.CreateAllFoldersQuery();

                 discussionItems = list.GetItems(query);
                clientContext.Load(discussionItems);
                clientContext.ExecuteQuery();
                itemPosition = discussionItems.ListItemCollectionPosition;
            }
            /********** For Geting list of favourites for checking isFavourite **************/

            var listOfFav = w.Lists.GetByTitle("Favourites");
            clientContext.Load(listOfFav);

            List<string> strConditions = new List<string>();
            strConditions.Add(CAMLHelper.GetCAMLFieldRefCondition("EmailID".ToString(), CAMLHelper.DataType.Text, EmailID.ToString(), CAMLHelper.OpeatorType.Equal, false));
            strConditions.Add(CAMLHelper.GetCAMLFieldRefCondition("TypeOfFavourite".ToString(), CAMLHelper.DataType.Text, "Discussion".ToString(), CAMLHelper.OpeatorType.Equal, false));
            
            string FinalConditionOfFav = CAMLHelper.MergeCAMLConditions(strConditions, CAMLHelper.MergeType.And, true);
            paramHelp.CAMLQuery = "<View Scope='RecursiveAll'><Query>" + FinalConditionOfFav + " </Query></View>";
          
            SP.CamlQuery queryForFav = new SP.CamlQuery();
            queryForFav.ViewXml = paramHelp.CAMLQuery;

            var FavItems = listOfFav.GetItems(queryForFav);
            clientContext.Load(FavItems);
            clientContext.ExecuteQuery();

            DataTable dtOfFav = new DataTable();

            dtOfFav = ConvertListCollInDatatable(FavItems);
            

            DataTable dt = new DataTable();
            string str = null;
           
            clientContext.ExecuteQuery();
            if (itemPosition != null)
            {
                str = itemPosition.PagingInfo.Substring(itemPosition.PagingInfo.IndexOf('&') + 1);
            }
            dt = ConvertListCollInDatatable(discussionItems);


            DataTable dtFinal = new DataTable();

            /***** for ImageByte ******/

            //if (dt.Rows[0]["Attachments"].ToString() == "True")
            //{
            string doc = null;
            dt.Columns.Add("ImageByte");
                foreach (DataRow dr in dt.Rows)
                {
                    if (dr["Attachments"].ToString() == "True")
                    {
                        //var fileRef = "/Lists/Discussion Board/attachments/" + dr["ID"].ToString() + "/Pic.png";
                        var fileRef = "/Lists/Test Discussion Board/attachments/" + dr["ID"].ToString() + "/Pic.png";
                        Microsoft.SharePoint.Client.FileInformation fileInfo = Microsoft.SharePoint.Client.File.OpenBinaryDirect(clientContext, fileRef);
                        byte[] buffer = new byte[16 * 1024];
                        using (MemoryStream ms = new MemoryStream())
                        {

                            fileInfo.Stream.CopyTo(ms);
                            buffer = ms.ToArray();

                        }
                       
                        doc = Convert.ToBase64String(buffer);
                        dr["ImageByte"] = doc;
                    } 
                    else
                    {
                        dr["ImageByte"] = "-1";
                    }
                }

           // }


            clientContext.ExecuteQuery();

            if (dt != null && dt.Rows.Count > 0)
            {
                dt.Columns.Add("PageInfo");
                dt.Columns.Add("IsFavourite");
                foreach (DataRow dr in dt.Rows)
                {
                    dr["PageInfo"] = str;
                }
                if (dtOfFav != null && dtOfFav.Rows.Count > 0)
                {
                    /* used for joining two datatables */
                    var ret = (from p in dt.AsEnumerable()
                               join q in dtOfFav.AsEnumerable() on p.Field<string>("ID") equals q.Field<string>("ItemID")
                               into UP
                               from q in UP.DefaultIfEmpty()//stuff in UP.DefaultIfEmpty()
                               select new
                               {
                                   ID = p.Field<string>("ID"),
                                   Title = p.Field<string>("Title"),
                                   Body = p.Field<string>("Body"),
                                   ItemChildCount = p.Field<string>("ItemChildCount"),
                                   StartedBy = p.Field<string>("StartedBy"),
                                   Created=p.Field<string>("Created"),
                                   Category = p.Field<string>("Category"),
                                   PageInfo = p.Field<string>("PageInfo"),
                                   IsFavourite = q == null ? "False" : "True",// q.Field<string>("ItemID") 
                                   ImageByte = p.Field<string>("ImageByte")
                                   //    ItemID = false
                               });//.ToList();

                    dtFinal = LINQResultToDataTable(ret);
                    return dtFinal;
                }
                else
                {
                    return dt;
                }
            }
            else
            {
                return null;
            }
            
    
        }

       /* for converting list into datatable */
        public static DataTable LINQResultToDataTable<T>(IEnumerable<T> Linqlist)
        {
            DataTable dt = new DataTable();


            PropertyInfo[] columns = null;

            if (Linqlist == null) return dt;

            foreach (T Record in Linqlist)
            {

                if (columns == null)
                {
                    columns = ((Type)Record.GetType()).GetProperties();
                    foreach (PropertyInfo GetProperty in columns)
                    {
                        Type IcolType = GetProperty.PropertyType;

                        if ((IcolType.IsGenericType) && (IcolType.GetGenericTypeDefinition()
                        == typeof(Nullable<>)))
                        {
                            IcolType = IcolType.GetGenericArguments()[0];
                        }

                        dt.Columns.Add(new DataColumn(GetProperty.Name, IcolType));
                    }
                }

                DataRow dr = dt.NewRow();

                foreach (PropertyInfo p in columns)
                {
                    dr[p.Name] = p.GetValue(Record, null) == null ? DBNull.Value : p.GetValue
                    (Record, null);
                }

                dt.Rows.Add(dr);
            }
            return dt;
        }
       /* For getting discussion by id*/
        public DataTable GetDiscussionByIDBAL(string DiscussionID,string EmailID)
        { 
             string doc=null;
            int i = 0;
            bool result = int.TryParse(DiscussionID, out i);
            if(DiscussionID ==null)
            {
                DataTable dt = new DataTable();
                dt.Columns.Add("statusId");
                dt.Columns.Add("message");
                dt.Columns.Add("ID");
                dt.Columns.Add("Title");
                dt.Columns.Add("body");
                dt.Columns.Add("Replies");
                dt.Columns.Add("Date");
                dt.Rows.Add("0", "Parameter is null","","","","","");
                return dt;
            }
            else if (result)
            {

                MobAppSer.ParameterHelperCommon paramHelp = new MobAppSer.ParameterHelperCommon();
                paramHelp.URL = SiteUrl;
                paramHelp.UserID = UserName;
                paramHelp.Password = Password;
                paramHelp.ListName = "UserExtendedProperties";
                bool isValidate = MobAppSer.SPClientHelper.ValidateLogin(paramHelp);

                ClientContext clientContext = MobAppSer.SPClientHelper.ConnectToSite(paramHelp);

                Web w = clientContext.Web;
               

                clientContext.Load(w);
                
                var list = w.Lists.GetByTitle("Discussion Board");
                clientContext.Load(list);
               
               
          
                List<string> strConditionsOrderBy = new List<string>();
                strConditionsOrderBy.Add(CAMLHelper.GetCAMLFieldRefCondition("ContentType".ToString(), CAMLHelper.DataType.Text, "Discussion".ToString(), CAMLHelper.OpeatorType.Equal, false));
                strConditionsOrderBy.Add(CAMLHelper.GetCAMLFieldRefCondition("ID".ToString(), CAMLHelper.DataType.Text, DiscussionID.ToString(), CAMLHelper.OpeatorType.Equal, false));

                string FinalCondition = CAMLHelper.MergeCAMLConditions(strConditionsOrderBy, CAMLHelper.MergeType.And, true);
                paramHelp.CAMLQuery = "<View Scope='RecursiveAll'><Query>" + FinalCondition + "</View></Query>";

                SP.CamlQuery query = new SP.CamlQuery();
                query.ViewXml = paramHelp.CAMLQuery;

                var discussionItems = list.GetItems(query);
                clientContext.Load(discussionItems);
                clientContext.ExecuteQuery();
                clientContext.Load(list);
                
            
               
                /********** For Geting list of favourites for checking isFavourite **************/

                var listOfFav = w.Lists.GetByTitle("Favourites");
                clientContext.Load(listOfFav);

                List<string> strConditions = new List<string>();
                strConditions.Add(CAMLHelper.GetCAMLFieldRefCondition("EmailID".ToString(), CAMLHelper.DataType.Text, EmailID.ToString(), CAMLHelper.OpeatorType.Equal, false));
                strConditions.Add(CAMLHelper.GetCAMLFieldRefCondition("TypeOfFavourite".ToString(), CAMLHelper.DataType.Text, "Discussion".ToString(), CAMLHelper.OpeatorType.Equal, false));
                strConditions.Add(CAMLHelper.GetCAMLFieldRefCondition("ItemID".ToString(), CAMLHelper.DataType.Text, DiscussionID.ToString(), CAMLHelper.OpeatorType.Equal, false));

                string FinalConditionOfFav = CAMLHelper.MergeCAMLConditions(strConditions, CAMLHelper.MergeType.And, true);
                paramHelp.CAMLQuery = "<View Scope='RecursiveAll'><Query>" + FinalConditionOfFav + " </Query></View>";

                SP.CamlQuery queryForFav = new SP.CamlQuery();
                queryForFav.ViewXml = paramHelp.CAMLQuery;

                var FavItems = listOfFav.GetItems(queryForFav);
                clientContext.Load(FavItems);
                clientContext.ExecuteQuery();

                DataTable dtOfFav = new DataTable();

                dtOfFav = ConvertListCollInDatatable(FavItems);
                DataTable dtFinal = new DataTable();
                DataTable dt = new DataTable();
                dt = ConvertListCollInDatatable(discussionItems);
                
                /***** for ImageByte ******/
            
                if (dt.Rows[0]["Attachments"].ToString() == "True")
                {
                    foreach (ListItem li in discussionItems)
                    {

                        var fileRef = "/Lists/Test Discussion Board/attachments/" + DiscussionID.ToString() + "/Pic.png";
                        Microsoft.SharePoint.Client.FileInformation fileInfo = Microsoft.SharePoint.Client.File.OpenBinaryDirect(clientContext, fileRef);
                        byte[] buffer = new byte[16 * 1024];
                        using (MemoryStream ms = new MemoryStream())
                        {

                            fileInfo.Stream.CopyTo(ms);
                            buffer = ms.ToArray();

                        }
                        doc = Convert.ToBase64String(buffer);
                    }

                }
                else
                {
                    doc = "-1";
                }

                clientContext.ExecuteQuery();

                if (dt != null && dt.Rows.Count > 0)
                {
                    dt.Columns.Add("statusId");
                    dt.Columns.Add("message");
                    dt.Columns.Add("IsFavourite");
                    dt.Columns.Add("ImageByte");
                }

                if (dtOfFav != null && dtOfFav.Rows.Count > 0)
                {
                    /* used for joining two datatables */
                    var ret = (from p in dt.AsEnumerable()
                               join q in dtOfFav.AsEnumerable() on p.Field<string>("ID") equals q.Field<string>("ItemID")
                               into UP
                               from q in UP.DefaultIfEmpty()//stuff in UP.DefaultIfEmpty()
                               select new
                               {
                                   ID = p.Field<string>("ID"),
                                   Title = p.Field<string>("Title"),
                                   Body = p.Field<string>("Body"),
                                   ItemChildCount = p.Field<string>("ItemChildCount"),
                                   StartedBy = p.Field<string>("StartedBy"),
                                   Created = p.Field<string>("Created"),
                                   Category = p.Field<string>("Category"),
                                   statusId = p.Field<string>("statusId"),
                                   message = p.Field<string>("message"),
                                   IsFavourite = q == null ? "False" : "True",// q.Field<string>("ItemID") 
                                   ImageByte=doc
                                  
                               });

                    dtFinal = LINQResultToDataTable(ret);
                    return dtFinal;
                }
                else
                {
                    dt.Rows[0]["ImageByte"] = doc;
                    return dt;
                }



                
            }
            else
            {
                DataTable dt = new DataTable();
                dt.Columns.Add("statusId");
                dt.Columns.Add("message");
                dt.Columns.Add("ID");
                dt.Columns.Add("Title");
                dt.Columns.Add("body");
                dt.Columns.Add("Replies");
                dt.Columns.Add("Date");

                dt.Rows.Add("0", "Invalid parameter","","","","","");
                return dt;
            }
        }


       /* For getting  all replies of particular discussion input is discussion id */
        public DataTable GetRepliesOfDiscussionBAL(string DiscussionID)
        {
            int i = 0;
            bool result = int.TryParse(DiscussionID, out i);
            if (DiscussionID == null)
            {
                DataTable dt = new DataTable();
                dt.Columns.Add("statusId");
                dt.Columns.Add("message");
                dt.Columns.Add("ID");
                dt.Columns.Add("Title");
                dt.Columns.Add("body");
                dt.Rows.Add("0", "Parameter is null", "", "", "");
                return dt;
            }
            else if (result)
            {

                MobAppSer.ParameterHelperCommon paramHelp = new MobAppSer.ParameterHelperCommon();
                paramHelp.URL = SiteUrl;
                paramHelp.UserID = UserName;
                paramHelp.Password = Password;
                paramHelp.ListName = "UserExtendedProperties";
                bool isValidate = MobAppSer.SPClientHelper.ValidateLogin(paramHelp);

                ClientContext clientContext = MobAppSer.SPClientHelper.ConnectToSite(paramHelp);

                Web w = clientContext.Web;
                //var lists = clientContext.LoadQuery(w.Lists);

                clientContext.Load(w);
                //List list = w.Lists.GetByTitle(paramHelp.ListName);
                // clientContext.Load(list);

                var list = w.Lists.GetByTitle("Discussion Board");
                clientContext.Load(list);

                List<string> strConditionsOrderBy = new List<string>();
                strConditionsOrderBy.Add(CAMLHelper.GetCAMLFieldRefCondition("ParentFolderId".ToString(), CAMLHelper.DataType.Text, DiscussionID.ToString(), CAMLHelper.OpeatorType.Equal, false));

                string FinalCondition = CAMLHelper.MergeCAMLConditions(strConditionsOrderBy, CAMLHelper.MergeType.And, true);
                paramHelp.CAMLQuery = "<View Scope='RecursiveAll'><Query>" + FinalCondition + "</View></Query>";

                SP.CamlQuery query = new SP.CamlQuery();
                query.ViewXml = paramHelp.CAMLQuery;

                var replies = list.GetItems(query);
               
               
                clientContext.Load(replies);
                DataTable dt = new DataTable();


                clientContext.ExecuteQuery();
                dt = ConvertListCollInDatatable(replies);
                if (dt != null && dt.Rows.Count > 0)
                {
                    dt.Columns.Add("statusId");
                    dt.Columns.Add("message");
                }
                return dt;
            }
            else
            {
                DataTable dt = new DataTable();
                dt.Columns.Add("statusId");
                dt.Columns.Add("message");
                dt.Columns.Add("ID");
                dt.Columns.Add("Title");
                dt.Columns.Add("body");
                dt.Rows.Add("0", "Invalid parameter", "", "", "");
                return dt;
            }
        }

       /* Creating new discussion in sp discussion board */
        public bool CreateNewDiscussionBAL(string Topic, string Body, string StartedBy,string EmailID, string IdOfCategory, string[] ImageByte)
       {
           MobAppSer.ParameterHelperCommon paramHelp = new MobAppSer.ParameterHelperCommon();
           paramHelp.URL = SiteUrl;
           paramHelp.UserID = UserName;
           paramHelp.Password = Password;
           paramHelp.ListName = "UserExtendedProperties";
           bool isValidate = MobAppSer.SPClientHelper.ValidateLogin(paramHelp);

           ClientContext clientContext = MobAppSer.SPClientHelper.ConnectToSite(paramHelp);

           Web w = clientContext.Web;
           //var lists = clientContext.LoadQuery(w.Lists);

           clientContext.Load(w);
          
           var list = w.Lists.GetByTitle("Discussion Board");
           clientContext.Load(list);
          
           //Create the topic
           ListItem t = Microsoft.SharePoint.Client.Utilities.Utility.CreateNewDiscussion(clientContext, list, Topic);
           t["Body"] =Body;
           t["StartedBy"] = StartedBy;
           t["EmailID"] = EmailID;
           t["Category"] = IdOfCategory;
           t.Update();
           byte[] arr = null;
           List<byte> bytes = new System.Collections.Generic.List<byte>();
           if (ImageByte != null && ImageByte[0].ToString().Length>0)
           {
               foreach (string str in ImageByte)
               {
                   //combine image bytes
                   byte[] imageBytes = Convert.FromBase64String(str);
                   bytes.AddRange(imageBytes);
               }
               byte[] bary = bytes.ToArray();

               var attachmnt = new AttachmentCreationInformation();
               attachmnt.FileName = "Pic.png";
               attachmnt.ContentStream = new MemoryStream(bary);

               Attachment att = t.AttachmentFiles.Add(attachmnt);
               clientContext.Load(att);
               clientContext.ExecuteQuery();

           }
           clientContext.ExecuteQuery();
           return true;

       }



       /* Reply on particular discussion */
       public bool ReplyOnDiscussionBAL(string DiscussionID, string Body, string StartedBy)
       {
           int i = 0;
           bool result = int.TryParse(DiscussionID, out i);
           if (DiscussionID == null)
           {
               return false;
           }
           else if (result)
           {

               MobAppSer.ParameterHelperCommon paramHelp = new MobAppSer.ParameterHelperCommon();
               paramHelp.URL = SiteUrl;
               paramHelp.UserID = UserName;
               paramHelp.Password = Password;
               paramHelp.ListName = "UserExtendedProperties";
               bool isValidate = MobAppSer.SPClientHelper.ValidateLogin(paramHelp);

               ClientContext clientContext = MobAppSer.SPClientHelper.ConnectToSite(paramHelp);

               Web w = clientContext.Web;
               //var lists = clientContext.LoadQuery(w.Lists);

               clientContext.Load(w);
               //List list = w.Lists.GetByTitle(paramHelp.ListName);
               // clientContext.Load(list);

               var list = w.Lists.GetByTitle("Discussion Board");
               clientContext.Load(list);

               List<string> strConditionsOrderBy = new List<string>();
               strConditionsOrderBy.Add(CAMLHelper.GetCAMLFieldRefCondition("ContentType".ToString(), CAMLHelper.DataType.Text, "Discussion".ToString(), CAMLHelper.OpeatorType.Equal, false));

               strConditionsOrderBy.Add(CAMLHelper.GetCAMLFieldRefCondition("ID".ToString(), CAMLHelper.DataType.Text, DiscussionID.ToString(), CAMLHelper.OpeatorType.Equal, false));

               string FinalCondition = CAMLHelper.MergeCAMLConditions(strConditionsOrderBy, CAMLHelper.MergeType.And, true);
               paramHelp.CAMLQuery = "<View Scope='RecursiveAll'><Query>" + FinalCondition + "</View></Query>";

               SP.CamlQuery query = new SP.CamlQuery();
               query.ViewXml = paramHelp.CAMLQuery;

               var discussionItems = list.GetItems(query);

               clientContext.Load(discussionItems);
               DataTable dt = new DataTable();
               clientContext.ExecuteQuery();
               ListItem t = discussionItems[0];
               //Create the reply
               ListItem r = Microsoft.SharePoint.Client.Utilities.Utility.CreateNewDiscussionReply(clientContext, t);
               r["Body"] = Body;
               r["StartedBy"] = StartedBy;
               r.Update();
               clientContext.ExecuteQuery();

               return true;
           }
           else
           {
               return false;
           }
       }


        #endregion
        #region "FeedBack"
       /* Adding Feedback to list and sending email to admin */
       public void WriteToFeedback(string EmailID, string Subject, string Comments)
       {
           MobAppSer.ParameterHelperCommon paramHelp = new MobAppSer.ParameterHelperCommon();
           paramHelp.URL = SiteUrl;
           paramHelp.UserID = UserName;
           paramHelp.Password = Password;
           paramHelp.ListName = "UserExtendedProperties";
           bool isValidate = MobAppSer.SPClientHelper.ValidateLogin(paramHelp);
           ClientContext clientContext = MobAppSer.SPClientHelper.ConnectToSite(paramHelp);

           Web w = clientContext.Web;
           var lists = clientContext.LoadQuery(w.Lists);

           clientContext.Load(w);
           Microsoft.SharePoint.Client.List list = w.Lists.GetByTitle(paramHelp.ListName);
           clientContext.Load(list);


           SP.List oList = clientContext.Web.Lists.GetByTitle("FeedBack");

           ListItemCreationInformation itemCreateInfo = new ListItemCreationInformation();
           ListItem oListItem = oList.AddItem(itemCreateInfo);
           oListItem["EmailID"] = EmailID;
           oListItem["Subject"] = Subject;
           oListItem["Comments"] = Comments;
           oListItem.Update();
       }
       public bool CreateFeedBackBAL(string EmailID, string Subject, string Comments, string[] ImageByte)
       {
           try
           {
               MobAppSer.ParameterHelperCommon paramHelp = new MobAppSer.ParameterHelperCommon();
               paramHelp.URL = SiteUrl;
               paramHelp.UserID = UserName;
               paramHelp.Password = Password;
               paramHelp.ListName = "UserExtendedProperties";
               bool isValidate = MobAppSer.SPClientHelper.ValidateLogin(paramHelp);
               ClientContext clientContext = MobAppSer.SPClientHelper.ConnectToSite(paramHelp);

               Web w = clientContext.Web;
               var lists = clientContext.LoadQuery(w.Lists);

               clientContext.Load(w);
               Microsoft.SharePoint.Client.List list = w.Lists.GetByTitle(paramHelp.ListName);
               clientContext.Load(list);


               SP.List oList = clientContext.Web.Lists.GetByTitle("FeedBack");

               ListItemCreationInformation itemCreateInfo = new ListItemCreationInformation();
               ListItem oListItem = oList.AddItem(itemCreateInfo);
               oListItem["EmailID"] = EmailID;
               oListItem["Subject"] = Subject;
               oListItem["Comments"] = Comments;
               oListItem.Update();

             //  byte[] arr = System.IO.File.ReadAllBytes("C:\\Users\\akusps.devadmin\\Desktop\\test.png");


              
              // arr = Convert.FromBase64String(ImageByte);
               
                   byte[] arr = null;
                   List<byte> bytes = new System.Collections.Generic.List<byte>();
                   GroupCollection collGroup = clientContext.Web.SiteGroups;
                   Attachments at = new Attachments();
                   clientContext.Load(collGroup);

                   clientContext.Load(collGroup,
                   groups => groups.Include(
                   group => group.Users));
                   if (ImageByte != null && ImageByte[0].ToString().Length > 0)
                   {
                       foreach (string str in ImageByte)
                       {
                           //combine image bytes
                           byte[] imageBytes = Convert.FromBase64String(str);
                           bytes.AddRange(imageBytes);
                       }
                       byte[] bary = bytes.ToArray();

                       var attachmnt = new AttachmentCreationInformation();
                       attachmnt.FileName = "Pic.png";
                       attachmnt.ContentStream = new MemoryStream(bary);

                       Attachment att = oListItem.AttachmentFiles.Add(attachmnt);
                       clientContext.Load(att);
                       clientContext.ExecuteQuery();

                       clientContext.ExecuteQuery();
                     
                     
                       at.Name = "pic.png";
                       at.Content = bary;
                   }
               clientContext.ExecuteQuery();
               foreach (Group oGroup in collGroup)
               {
                   UserCollection collUser = oGroup.Users;
                   if (oGroup.Title == "Bioethics Owners")
                   {
                       foreach (User oUser in collUser)
                       {
                           try
                           {
                               EmailHelper emailObj = new EmailHelper();
                               emailObj.EmailTo = oUser.Email;
                               //emailObj.EmailCC = "farah.salman@aku.edu";
                               emailObj.EmailFrom = "bioethicsapp@aku.edu";
                               emailObj.EmailSubject = "Feed Back";
                               emailObj.EmailBody = "<h3>From: " + EmailID + "</h3><table style='width:100%'><tr><th>Subject</th><th>Comments</th>" +
      "</tr><tr><td>" + Subject + "</td><td>" + Comments + "</td></tr></table>";
                               emailObj.Attachments = new List<Attachments>();
                               if (at.Content != null && at.Content.ToString() != "")
                               {
                                   emailObj.Attachments.Add(at);
                               }
                               EmailHelper.SendEmail(emailObj);
                           }
                           catch (Exception ex)
                           {
                               WriteToFeedback(oUser.Email, ex.Message, ex.InnerException + ex.StackTrace);
                           }


                       }
                   }
               }

               
               return true;

           }
           catch (Exception ex)
           {
               
               
              return false;
               throw ex;

           }
       }
       #endregion
        #region "Favourites"
       /* Getting favrourites of particular user by his email id */
       public DataTable GetFavrouritesBAL(string EmailID, string RowLimit, string PageInfo)
       {
           DataTable dtFinalFav = new DataTable();
           DataTable dtDiscussion = new DataTable();
           DataTable dtVideo = new DataTable();
           DataTable dtArt = new DataTable();

           DataTable dtDoc = new DataTable();

         

               MobAppSer.ParameterHelperCommon paramHelp = new MobAppSer.ParameterHelperCommon();
               paramHelp.URL = SiteUrl;
               paramHelp.UserID = UserName;
               paramHelp.Password = Password;
               paramHelp.ListName = "UserExtendedProperties";
               bool isValidate = MobAppSer.SPClientHelper.ValidateLogin(paramHelp);

               ClientContext clientContext = MobAppSer.SPClientHelper.ConnectToSite(paramHelp);

               Web w = clientContext.Web;
              
               clientContext.Load(w);
            
               var list = w.Lists.GetByTitle("Favourites");
               clientContext.Load(list);

               List<string> strConditionsOrderBy = new List<string>();
               strConditionsOrderBy.Add(CAMLHelper.GetCAMLFieldRefCondition("EmailID".ToString(), CAMLHelper.DataType.Text, EmailID.ToString(), CAMLHelper.OpeatorType.Equal, false));
               string FinalCondition = CAMLHelper.MergeCAMLConditions(strConditionsOrderBy, CAMLHelper.MergeType.And, true);
               paramHelp.CAMLQuery = "<View Scope='RecursiveAll'><Query>" + FinalCondition + " </Query><RowLimit>" + RowLimit + "</RowLimit></View>";
               Microsoft.SharePoint.Client.ListItemCollectionPosition test = new ListItemCollectionPosition();
               test.PagingInfo = "Paged=TRUE&" + PageInfo;


               SP.CamlQuery query = new SP.CamlQuery();
               query.ViewXml = paramHelp.CAMLQuery;
               query.ListItemCollectionPosition = test;
               var favourites = list.GetItems(query);
           
               clientContext.Load(favourites);
               clientContext.ExecuteQuery();
               itemPosition = favourites.ListItemCollectionPosition;
             
               string str = null;
               clientContext.ExecuteQuery();
               if (itemPosition != null)
               {
                    str = itemPosition.PagingInfo.Substring(itemPosition.PagingInfo.IndexOf('&') + 1);
               }

               dtFinalFav = ConvertListCollInDatatable(favourites);
               if (dtFinalFav != null && dtFinalFav.Rows.Count > 0)
               {
                   dtFinalFav.Columns.Add("PageInfo");
                   dtFinalFav.Columns.Add("TitleOfFav");
                   dtFinalFav.Columns.Add("DescriptionOfFav");
                   foreach (DataRow dr in dtFinalFav.Rows)
                   {
                       dr["PageInfo"] = str;
                   }
                   foreach (DataRow dr in dtFinalFav.Rows)
                   {
                       #region "For Discussion"
                       if (dr["TypeOfFavourite"].ToString() == "Discussion")
                       {
                           var listForDisc = w.Lists.GetByTitle("Discussion Board");
                           clientContext.Load(listForDisc);

                           List<string> strConditionsOrderByForDis = new List<string>();
                           strConditionsOrderByForDis.Add(CAMLHelper.GetCAMLFieldRefCondition("ContentType".ToString(), CAMLHelper.DataType.Text, "Discussion".ToString(), CAMLHelper.OpeatorType.Equal, false));

                           strConditionsOrderByForDis.Add(CAMLHelper.GetCAMLFieldRefCondition("ID".ToString(), CAMLHelper.DataType.Text, dr["ItemID"].ToString(), CAMLHelper.OpeatorType.Equal, false));

                           string FinalConditionForDis = CAMLHelper.MergeCAMLConditions(strConditionsOrderByForDis, CAMLHelper.MergeType.And, true);
                           paramHelp.CAMLQuery = "<View Scope='RecursiveAll'><Query>" + FinalConditionForDis + "</View></Query>";

                           SP.CamlQuery queryfordis = new SP.CamlQuery();
                           queryfordis.ViewXml = paramHelp.CAMLQuery;

                           var discussionItems = listForDisc.GetItems(queryfordis);

                           clientContext.Load(discussionItems);
                           DataTable dt = new DataTable();
                           clientContext.ExecuteQuery();
                           dtDiscussion = ConvertListCollInDatatable(discussionItems);
                           if (dtDiscussion != null && dtDiscussion.Rows.Count > 0)
                           {
                               dr["TitleOfFav"] = dtDiscussion.Rows[0]["Title"];
                               dr["DescriptionOfFav"] = dtDiscussion.Rows[0]["Body"];
                           }
                           else
                           {
                               dr["TitleOfFav"] = "";
                               dr["DescriptionOfFav"] = "";
                           }
                       }
                       #endregion
                       #region "For Videos"
                       else if (dr["TypeOfFavourite"].ToString() == "Video")
                       {
                           var listofVid = w.Lists.GetByTitle("Videos");
                           clientContext.Load(listofVid);

                           List<string> strConditionsOrderByOfVid = new List<string>();

                           strConditionsOrderByOfVid.Add(CAMLHelper.GetCAMLFieldRefCondition("Active".ToString(), CAMLHelper.DataType.Text, "1".ToString(), CAMLHelper.OpeatorType.Equal, false));
                           strConditionsOrderByOfVid.Add(CAMLHelper.GetCAMLFieldRefCondition("ID".ToString(), CAMLHelper.DataType.Text, dr["ItemID"].ToString(), CAMLHelper.OpeatorType.Equal, false));

                           string FinalConditionofVid = CAMLHelper.MergeCAMLConditions(strConditionsOrderByOfVid, CAMLHelper.MergeType.And, true);
                           paramHelp.CAMLQuery = "<View Scope='RecursiveAll'><Query>" + FinalConditionofVid + "</Query></View>";

                          
                           SP.CamlQuery queryofVid = new SP.CamlQuery();
                           queryofVid.ViewXml = paramHelp.CAMLQuery;

                           var Viditems = listofVid.GetItems(queryofVid);

                           clientContext.Load(Viditems);
                           clientContext.ExecuteQuery();
                           dtVideo = ConvertListCollInDatatable(Viditems);
                           if (dtVideo != null && dtVideo.Rows.Count > 0)
           
                           {
                               dr["TitleOfFav"] = dtVideo.Rows[0]["HeadingOfVid"];
                               dr["DescriptionOfFav"] = dtVideo.Rows[0]["Description"];
                           }
                           else
                           {
                               dr["TitleOfFav"] = "";
                               dr["DescriptionOfFav"] = "";
                           }

                       }
                       #endregion
                       #region "For Article"
                       else if (dr["TypeOfFavourite"].ToString() == "Article")
                       {
                           var listofArt = w.Lists.GetByTitle("LearningMaterialArticlesList");
                           clientContext.Load(listofArt);

                           List<string> strConditionsOrderByOfArt = new List<string>();

                           strConditionsOrderByOfArt.Add(CAMLHelper.GetCAMLFieldRefCondition("ID".ToString(), CAMLHelper.DataType.Text, dr["ItemID"].ToString(), CAMLHelper.OpeatorType.Equal, false));

                           string FinalConditionofArt = CAMLHelper.MergeCAMLConditions(strConditionsOrderByOfArt, CAMLHelper.MergeType.And, true);
                           paramHelp.CAMLQuery = "<View Scope='RecursiveAll'><Query>" + FinalConditionofArt + "</Query></View>";


                           SP.CamlQuery queryofVid = new SP.CamlQuery();
                           queryofVid.ViewXml = paramHelp.CAMLQuery;

                           var Artitems = listofArt.GetItems(queryofVid);

                           clientContext.Load(Artitems);
                           clientContext.ExecuteQuery();
                           dtArt = ConvertListCollInDatatable(Artitems);
                           if (dtArt != null && dtArt.Rows.Count > 0)
                           {
                               dr["TitleOfFav"] = dtArt.Rows[0]["Title"];
                               dr["DescriptionOfFav"] = dtArt.Rows[0]["ArticleBody"];
                           }
                           else
                           {
                               dr["TitleOfFav"] = "";
                               dr["DescriptionOfFav"] = "";
                           }

                       }
                       #endregion
                       #region "For Document"
                       else if (dr["TypeOfFavourite"].ToString() == "Document")
                       {
                           var listofDoc = w.Lists.GetByTitle("LearningMaterialDocuments");
                           clientContext.Load(listofDoc);

                           List<string> strConditionsOrderByOfDoc = new List<string>();

                           strConditionsOrderByOfDoc.Add(CAMLHelper.GetCAMLFieldRefCondition("ID".ToString(), CAMLHelper.DataType.Text, dr["ItemID"].ToString(), CAMLHelper.OpeatorType.Equal, false));

                           string FinalConditionofDoc = CAMLHelper.MergeCAMLConditions(strConditionsOrderByOfDoc, CAMLHelper.MergeType.And, true);
                           paramHelp.CAMLQuery = "<View Scope='RecursiveAll'><Query>" + FinalConditionofDoc + "</Query></View>";


                           SP.CamlQuery queryofArt = new SP.CamlQuery();
                           queryofArt.ViewXml = paramHelp.CAMLQuery;

                           var Docitems = listofDoc.GetItems(queryofArt);

                           clientContext.Load(Docitems);
                           clientContext.ExecuteQuery();
                           dtDoc = ConvertListCollInDatatable(Docitems);
                           if (dtDoc != null && dtDoc.Rows.Count > 0)
                           {
                               dr["TitleOfFav"] = dtDoc.Rows[0]["Title"];
                               dr["DescriptionOfFav"] = dtDoc.Rows[0]["Topic"];
                           }
                           else
                           {
                               dr["TitleOfFav"] = "";
                               dr["DescriptionOfFav"] = "";
                           }

                       }
                       #endregion
                   }

                   



               }
               return dtFinalFav;
          
       }

       /* Creating favourites */
       public bool AddToFavouriteBAL(string EmailID, string ItemID, string TypeOfFavourite)
       {
           try
           {
               MobAppSer.ParameterHelperCommon paramHelp = new MobAppSer.ParameterHelperCommon();
               paramHelp.URL = SiteUrl;
               paramHelp.UserID = UserName;
               paramHelp.Password = Password;
               paramHelp.ListName = "UserExtendedProperties";
               bool isValidate = MobAppSer.SPClientHelper.ValidateLogin(paramHelp);
               ClientContext clientContext = MobAppSer.SPClientHelper.ConnectToSite(paramHelp);

               Web w = clientContext.Web;
               var lists = clientContext.LoadQuery(w.Lists);

               clientContext.Load(w);
               Microsoft.SharePoint.Client.List list = w.Lists.GetByTitle(paramHelp.ListName);
               clientContext.Load(list);


               SP.List oList = clientContext.Web.Lists.GetByTitle("Favourites");

               ListItemCreationInformation itemCreateInfo = new ListItemCreationInformation();
               ListItem oListItem = oList.AddItem(itemCreateInfo);
               oListItem["ItemID"] = ItemID;
               oListItem["EmailID"] = EmailID;
               oListItem["TypeOfFavourite"] = TypeOfFavourite;
               
               oListItem.Update();

               clientContext.ExecuteQuery();
              
               return true;

           }
           catch (Exception ex)
           {
               return false;
               throw ex;

           }
       }


       /* Removing from favourites */
       public bool RemoveFromFavouriteBAL(string FavouriteID, string ItemID, string EmailID, string TypeOfFavourite)
       {
           MobAppSer.ParameterHelperCommon paramHelp = new MobAppSer.ParameterHelperCommon();
           paramHelp.URL = SiteUrl;
           paramHelp.UserID = UserName;
           paramHelp.Password = Password;
           paramHelp.ListName = "UserExtendedProperties";
           bool isValidate = MobAppSer.SPClientHelper.ValidateLogin(paramHelp);
           ClientContext clientContext = MobAppSer.SPClientHelper.ConnectToSite(paramHelp);

           Web w = clientContext.Web;
           var lists = clientContext.LoadQuery(w.Lists);

           clientContext.Load(w);
           // List list = w.Lists.GetByTitle(paramHelp.ListName);
           // clientContext.Load(list);


           var list = w.Lists.GetByTitle("Favourites");
           clientContext.Load(list);
           if (FavouriteID != "" && FavouriteID != null)
           {
               try
               {
                  


                   List<string> strConditionsOrderBy = new List<string>();
                   strConditionsOrderBy.Add(CAMLHelper.GetCAMLFieldRefCondition("ID".ToString(), CAMLHelper.DataType.Text, FavouriteID.ToString(), CAMLHelper.OpeatorType.Equal, false));

                   string FinalCondition = CAMLHelper.MergeCAMLConditions(strConditionsOrderBy, CAMLHelper.MergeType.And, true);
                   paramHelp.CAMLQuery = "<View><Query>" + FinalCondition + "</View></Query>";

                   SP.CamlQuery query = new SP.CamlQuery();
                   query.ViewXml = paramHelp.CAMLQuery;

                   ListItemCollection favourites = list.GetItems(query);
                   clientContext.Load(favourites);

                   clientContext.ExecuteQuery();

                   clientContext.Load(favourites,
                        eachItem => eachItem.Include(
                        item => item,
                        item => item["ID"]));
                   clientContext.ExecuteQuery();
                   if (favourites.Count > 0)
                   {
                       favourites[0].DeleteObject();
                       list.Update();
                       clientContext.ExecuteQuery();
                       return true;
                   }
                   else
                   {
                       return false;
                      

                   }
               }
               catch (Exception ex)
               {
                   return false;
                   throw ex;

               }
           }
           else
           {
               List<string> strFortempItemId = new List<string>();
               strFortempItemId.Add(CAMLHelper.GetCAMLFieldRefCondition("ItemID".ToString(), CAMLHelper.DataType.Text, ItemID.ToString(), CAMLHelper.OpeatorType.Equal, false));
               strFortempItemId.Add(CAMLHelper.GetCAMLFieldRefCondition("EmailID".ToString(), CAMLHelper.DataType.Text, EmailID.ToString(), CAMLHelper.OpeatorType.Equal, false));
               strFortempItemId.Add(CAMLHelper.GetCAMLFieldRefCondition("TypeOfFavourite".ToString(), CAMLHelper.DataType.Text, TypeOfFavourite.ToString(), CAMLHelper.OpeatorType.Equal, false));

               string FinalConditionfortempItem = CAMLHelper.MergeCAMLConditions(strFortempItemId, CAMLHelper.MergeType.And, true);
               paramHelp.CAMLQuery = "<View><Query>" + FinalConditionfortempItem + "</View></Query>";

               SP.CamlQuery query2 = new SP.CamlQuery();
               query2.ViewXml = paramHelp.CAMLQuery;

               ListItemCollection favourites2 = list.GetItems(query2);
               clientContext.Load(favourites2);

               clientContext.ExecuteQuery();

               clientContext.Load(favourites2,
                    eachItem => eachItem.Include(
                    item => item,
                    item => item["ID"],
                    item => item["ItemID"]));
               clientContext.ExecuteQuery();
               if (favourites2.Count > 0)
               {
                   foreach (ListItem it in favourites2)
                   {
                       it.DeleteObject();
                       list.Update();
                      
                   }
                   clientContext.ExecuteQuery();
                   return true;
               }
               else
               {
                   return false;
               }
           }
       }
       #endregion
        #region "Videos"
       /* For getting all active videos  details */
       public DataTable GetAllVideosBAL(string EmailID,string RowLimit, string PageInfo)
       {
           MobAppSer.ParameterHelperCommon paramHelp = new MobAppSer.ParameterHelperCommon();
           paramHelp.URL = SiteUrl;
           paramHelp.UserID = UserName;
           paramHelp.Password = Password;
           paramHelp.ListName = "UserExtendedProperties";
           bool isValidate = MobAppSer.SPClientHelper.ValidateLogin(paramHelp);

           ClientContext clientContext = MobAppSer.SPClientHelper.ConnectToSite(paramHelp);

           Web w = clientContext.Web;
           //var lists = clientContext.LoadQuery(w.Lists);

           clientContext.Load(w);
           //List list = w.Lists.GetByTitle(paramHelp.ListName);
           // clientContext.Load(list);

           var list = w.Lists.GetByTitle("Videos");
           clientContext.Load(list);

           List<string> strConditionsOrderBy = new List<string>();
           //   strConditionsOrderBy.Add(CAMLHelper.GetCAMLFieldRefCondition("ContentType".ToString(), CAMLHelper.DataType.Text, "Discussion".ToString(), CAMLHelper.OpeatorType.Equal, false));

           strConditionsOrderBy.Add(CAMLHelper.GetCAMLFieldRefCondition("Active".ToString(), CAMLHelper.DataType.Text, "1".ToString(), CAMLHelper.OpeatorType.Equal, false));

           string FinalCondition = CAMLHelper.MergeCAMLConditions(strConditionsOrderBy, CAMLHelper.MergeType.And, true);
           paramHelp.CAMLQuery = "<View Scope='RecursiveAll'>" + FinalCondition + "<RowLimit>"+RowLimit+"</RowLimit></View>";

           Microsoft.SharePoint.Client.ListItemCollectionPosition test = new ListItemCollectionPosition();
           test.PagingInfo = "Paged=TRUE&" + PageInfo;


           SP.CamlQuery query = new SP.CamlQuery();
           query.ViewXml = paramHelp.CAMLQuery;
           query.ListItemCollectionPosition = test;
           var discussionItems = list.GetItems(query);

           clientContext.Load(discussionItems);
           clientContext.ExecuteQuery();
           itemPosition = discussionItems.ListItemCollectionPosition;

           /********** For Geting list of favourites for checking isFavourite **************/

           var listOfFav = w.Lists.GetByTitle("Favourites");
           clientContext.Load(listOfFav);

           List<string> strConditions = new List<string>();
           strConditions.Add(CAMLHelper.GetCAMLFieldRefCondition("EmailID".ToString(), CAMLHelper.DataType.Text, EmailID.ToString(), CAMLHelper.OpeatorType.Equal, false));
           strConditions.Add(CAMLHelper.GetCAMLFieldRefCondition("TypeOfFavourite".ToString(), CAMLHelper.DataType.Text, "Video".ToString(), CAMLHelper.OpeatorType.Equal, false));

           string FinalConditionOfFav = CAMLHelper.MergeCAMLConditions(strConditions, CAMLHelper.MergeType.And, true);
           paramHelp.CAMLQuery = "<View Scope='RecursiveAll'><Query>" + FinalConditionOfFav + " </Query></View>";

           SP.CamlQuery queryForFav = new SP.CamlQuery();
           queryForFav.ViewXml = paramHelp.CAMLQuery;

           var FavItems = listOfFav.GetItems(queryForFav);
           clientContext.Load(FavItems);
           clientContext.ExecuteQuery();

           DataTable dtOfFav = new DataTable();

           dtOfFav = ConvertListCollInDatatable(FavItems);
            


           DataTable dt = new DataTable();

           string str = null;
           clientContext.ExecuteQuery();
           if (itemPosition != null)
           {
                str = itemPosition.PagingInfo.Substring(itemPosition.PagingInfo.IndexOf('&') + 1);
           }
           DataTable dtFinal = new DataTable();
           dt = ConvertListCollInDatatable(discussionItems);
           if (dt != null && dt.Rows.Count > 0)
           {
               dt.Columns.Add("PageInfo");
               dt.Columns.Add("IsFavourite");
               foreach (DataRow dr in dt.Rows)
               {
                   dr["PageInfo"] = str;
               }
               if (dtOfFav != null && dtOfFav.Rows.Count > 0)
               {
                   /* used for joining two datatables */
                   var ret = (from p in dt.AsEnumerable()
                              join q in dtOfFav.AsEnumerable() on p.Field<string>("ID") equals q.Field<string>("ItemID")
                              into UP
                              from q in UP.DefaultIfEmpty()//stuff in UP.DefaultIfEmpty()
                              select new
                              {
                                  ID = p.Field<string>("ID"),
                                  Title = p.Field<string>("Title"),
                                  HeadingOfVid = p.Field<string>("HeadingOfVid"),
                                  Description = p.Field<string>("Description"),
                                  Created = p.Field<string>("Created"),
                                  TypeOfVideo = p.Field<string>("TypeOfVideo"),
                                  PageInfo = p.Field<string>("PageInfo"),
                                  IsFavourite = q == null ? "False" : "True"// q.Field<string>("ItemID") 
                                  //    ItemID = false
                              });//.ToList();

                   dtFinal = LINQResultToDataTable(ret);
                   return dtFinal;
               }
               else
               {
                   return dt;
               }
           }
           else
           {
               return null;
           }
          
       }
       public DataTable GetVideoDetailByIDBAL(string VideoID, string EmailID)
       {
           MobAppSer.ParameterHelperCommon paramHelp = new MobAppSer.ParameterHelperCommon();
           paramHelp.URL = SiteUrl;
           paramHelp.UserID = UserName;
           paramHelp.Password = Password;
           paramHelp.ListName = "UserExtendedProperties";
           bool isValidate = MobAppSer.SPClientHelper.ValidateLogin(paramHelp);

           ClientContext clientContext = MobAppSer.SPClientHelper.ConnectToSite(paramHelp);

           Web w = clientContext.Web;
        

           clientContext.Load(w);
           
           var list = w.Lists.GetByTitle("Videos");
           clientContext.Load(list);

           List<string> strConditionsOrderBy = new List<string>();
           strConditionsOrderBy.Add(CAMLHelper.GetCAMLFieldRefCondition("ID".ToString(), CAMLHelper.DataType.Text, VideoID.ToString(), CAMLHelper.OpeatorType.Equal, false));

           strConditionsOrderBy.Add(CAMLHelper.GetCAMLFieldRefCondition("Active".ToString(), CAMLHelper.DataType.Text, "1".ToString(), CAMLHelper.OpeatorType.Equal, false));

           string FinalCondition = CAMLHelper.MergeCAMLConditions(strConditionsOrderBy, CAMLHelper.MergeType.And, true);
           paramHelp.CAMLQuery = "<View Scope='RecursiveAll'><Query>" + FinalCondition + "</Query></View>";

           
           SP.CamlQuery query = new SP.CamlQuery();
           query.ViewXml = paramHelp.CAMLQuery;
          
           var videoitem = list.GetItems(query);

           clientContext.Load(videoitem);
           clientContext.ExecuteQuery();
           
           /********** For Geting list of favourites for checking isFavourite **************/

           var listOfFav = w.Lists.GetByTitle("Favourites");
           clientContext.Load(listOfFav);

           List<string> strConditions = new List<string>();
           strConditions.Add(CAMLHelper.GetCAMLFieldRefCondition("EmailID".ToString(), CAMLHelper.DataType.Text, EmailID.ToString(), CAMLHelper.OpeatorType.Equal, false));
           strConditions.Add(CAMLHelper.GetCAMLFieldRefCondition("TypeOfFavourite".ToString(), CAMLHelper.DataType.Text, "Video".ToString(), CAMLHelper.OpeatorType.Equal, false));

           string FinalConditionOfFav = CAMLHelper.MergeCAMLConditions(strConditions, CAMLHelper.MergeType.And, true);
           paramHelp.CAMLQuery = "<View Scope='RecursiveAll'><Query>" + FinalConditionOfFav + " </Query></View>";

           SP.CamlQuery queryForFav = new SP.CamlQuery();
           queryForFav.ViewXml = paramHelp.CAMLQuery;

           var FavItems = listOfFav.GetItems(queryForFav);
           clientContext.Load(FavItems);
           clientContext.ExecuteQuery();

           DataTable dtOfFav = new DataTable();

           dtOfFav = ConvertListCollInDatatable(FavItems);



           DataTable dt = new DataTable();

           string str = null;
           clientContext.ExecuteQuery();
          
           DataTable dtFinal = new DataTable();
           dt = ConvertListCollInDatatable(videoitem);
           if (dt != null && dt.Rows.Count > 0)
           {
               
               dt.Columns.Add("IsFavourite");
              
               if (dtOfFav != null && dtOfFav.Rows.Count > 0)
               {
                   /* used for joining two datatables */
                   var ret = (from p in dt.AsEnumerable()
                              join q in dtOfFav.AsEnumerable() on p.Field<string>("ID") equals q.Field<string>("ItemID")
                              into UP
                              from q in UP.DefaultIfEmpty()//stuff in UP.DefaultIfEmpty()
                              select new
                              {
                                  ID = p.Field<string>("ID"),
                                  Title = p.Field<string>("Title"),
                                  HeadingOfVid = p.Field<string>("HeadingOfVid"),
                                  Description = p.Field<string>("Description"),
                                  Created = p.Field<string>("Created"),
                                  TypeOfVideo = p.Field<string>("TypeOfVideo"),
                                  
                                  IsFavourite = q == null ? "False" : "True"// q.Field<string>("ItemID") 
                                  //    ItemID = false
                              });//.ToList();

                   dtFinal = LINQResultToDataTable(ret);
                   return dtFinal;
               }
               else
               {
                   return dt;
               }
           }
           else
           {
               return null;
           }

       }
       public DataTable GetCommentsOfVideoByIDBAL(string VideoID)
       {
           MobAppSer.ParameterHelperCommon paramHelp = new MobAppSer.ParameterHelperCommon();
           paramHelp.URL = SiteUrl;
           paramHelp.UserID = UserName;
           paramHelp.Password = Password;
           paramHelp.ListName = "UserExtendedProperties";
           bool isValidate = MobAppSer.SPClientHelper.ValidateLogin(paramHelp);

           ClientContext clientContext = MobAppSer.SPClientHelper.ConnectToSite(paramHelp);

           Web w = clientContext.Web;
           

           clientContext.Load(w);


           var list = w.Lists.GetByTitle("VideosComments");
           clientContext.Load(list);

           List<string> strConditionsOrderBy = new List<string>();
           strConditionsOrderBy.Add(CAMLHelper.GetCAMLFieldRefCondition("VideoID".ToString(), CAMLHelper.DataType.Text, VideoID.ToString(), CAMLHelper.OpeatorType.Equal, false));

           string FinalCondition = CAMLHelper.MergeCAMLConditions(strConditionsOrderBy, CAMLHelper.MergeType.And, true);
           paramHelp.CAMLQuery = "<View Scope='RecursiveAll'><Query>" + FinalCondition + "</Query></View>";
          
           SP.CamlQuery query = new SP.CamlQuery();
           query.ViewXml = paramHelp.CAMLQuery;
          
           var discussionItems = list.GetItems(query);

           clientContext.Load(discussionItems);
           clientContext.ExecuteQuery();
           DataTable dt = new DataTable();
           dt = ConvertListCollInDatatable(discussionItems);
           return dt;
       }
       public bool CommentOnVideoBAL(CreateNewCommentOnVidInput obj)
       {
           int i = 0;
           bool result = int.TryParse(obj.VideoID, out i);
           if (obj.VideoID == null)
           {
               return false;
           }
           else if (result)
           {

               MobAppSer.ParameterHelperCommon paramHelp = new MobAppSer.ParameterHelperCommon();
               paramHelp.URL = SiteUrl;
               paramHelp.UserID = UserName;
               paramHelp.Password = Password;
               paramHelp.ListName = "UserExtendedProperties";
               bool isValidate = MobAppSer.SPClientHelper.ValidateLogin(paramHelp);

               ClientContext clientContext = MobAppSer.SPClientHelper.ConnectToSite(paramHelp);

               Web w = clientContext.Web;
             
               clientContext.Load(w);
               
               var list = w.Lists.GetByTitle("VideosComments");
               clientContext.Load(list);
               clientContext.ExecuteQuery();
               //var list2 = w.Lists.GetByTitle("UserExtendedProperties");
               //clientContext.Load(list2);
            
               
               //List<string> strConditionsOrderBy = new List<string>();
               //strConditionsOrderBy.Add(CAMLHelper.GetCAMLFieldRefCondition("EmailID".ToString(), CAMLHelper.DataType.Text, obj.EmailID.ToString(), CAMLHelper.OpeatorType.Equal, false));
               //string FinalCondition = CAMLHelper.MergeCAMLConditions(strConditionsOrderBy, CAMLHelper.MergeType.And, true);
               //paramHelp.CAMLQuery = "<View Scope='RecursiveAll'><Query>" + FinalCondition + "</Query></View>";
               //SP.CamlQuery query = new SP.CamlQuery();
               //query.ViewXml = paramHelp.CAMLQuery;
               //var discussionItems = list2.GetItems(query);

               //clientContext.Load(discussionItems);
               //clientContext.ExecuteQuery();

               ListItemCreationInformation itemCreateInfo = new ListItemCreationInformation();
               ListItem oListItem = list.AddItem(itemCreateInfo);
               oListItem["VideoID"] = obj.VideoID;
               oListItem["CommentedBy"] = obj.EmailID;
               //FieldLookupValue lv = new FieldLookupValue();
               //lv.LookupId = int.Parse(discussionItems[0]["ID"].ToString());
               //oListItem["EmailID"] = lv;
               oListItem["Comment"] = obj.CommentBody;
               oListItem.Update();
               clientContext.ExecuteQuery();

               return true;

              
           }
           else
           {
               return false;
           }
       }
       #endregion
        #region "Learning Material"
       #region "testing"
       public DataTable GetLearningMaterialByIDBAL(string ID)
       {
           MobAppSer.ParameterHelperCommon paramHelp = new MobAppSer.ParameterHelperCommon();
           paramHelp.URL = SiteUrl;
           paramHelp.UserID = UserName;
           paramHelp.Password = Password;
           paramHelp.ListName = "UserExtendedProperties";
           bool isValidate = MobAppSer.SPClientHelper.ValidateLogin(paramHelp);

           ClientContext clientContext = MobAppSer.SPClientHelper.ConnectToSite(paramHelp);

           Web w = clientContext.Web;
           clientContext.Load(w);

           string LibraryName = "Test Doc";
           var list = clientContext.Web.Lists.GetByTitle(LibraryName);

           clientContext.Load(list, l => l.RootFolder.ServerRelativeUrl);
           clientContext.ExecuteQuery();

           List<string> strConditionsOrderBy = new List<string>();
           strConditionsOrderBy.Add(CAMLHelper.GetCAMLFieldRefCondition("ID".ToString(), CAMLHelper.DataType.Text, ID.ToString(), CAMLHelper.OpeatorType.Equal, false));

           string FinalCondition = CAMLHelper.MergeCAMLConditions(strConditionsOrderBy, CAMLHelper.MergeType.And, true);
           paramHelp.CAMLQuery = "<View><Query>" + FinalCondition + "</View></Query>";

           SP.CamlQuery query = new SP.CamlQuery();
           query.ViewXml = paramHelp.CAMLQuery;


           var items = list.GetItems(query);
           clientContext.Load(items, l => l.IncludeWithDefaultProperties(i => i.Folder, i => i.File, i => i.DisplayName));
           clientContext.ExecuteQuery();


           DataTable dt = new DataTable();
           dt = ConvertListCollInDatatable(items);


           if(dt!=null && dt.Rows.Count>0)
           {
             
                   DownloadDoc();
             

           }

           return dt;



       }
       public DataTable QuizHandling(string QuizID)
       {
           MobAppSer.ParameterHelperCommon paramHelp = new MobAppSer.ParameterHelperCommon();
           paramHelp.URL = SiteUrl;
           paramHelp.UserID = UserName;
           paramHelp.Password = Password;
           paramHelp.ListName = "UserExtendedProperties";
           bool isValidate = MobAppSer.SPClientHelper.ValidateLogin(paramHelp);

           ClientContext clientContext = MobAppSer.SPClientHelper.ConnectToSite(paramHelp);

           Web w = clientContext.Web;

           clientContext.Load(w);

          string hashValue=null;
          string choices = null;
          string typofAns = null;
          string corrAns = null;
           var list = w.Lists.GetByTitle(QuizID);
           clientContext.Load(list);
           clientContext.Load(list.Fields);
           clientContext.ExecuteQuery();
           DataTable dt = new DataTable();
           dt.Columns.Add("Question");
           dt.Columns.Add("Choices");
           dt.Columns.Add("Type");

           List<String> test = new List<String>();


           foreach (Field Fi in list.Fields)
           {

               if(Fi.Hidden != true)
               {
                   if(Fi.TypeAsString=="QuestionOfTypeText")
                   {
                       
                       dt.Rows.Add(Fi.Title, "", "TextBox");

                   }
                   else if(Fi.TypeAsString=="QuestionOfTypeChoice")
                   {
                       var xmlforval = Fi.SchemaXml;
                       XDocument doc = XDocument.Parse(xmlforval);

                      foreach (XElement hashElement in doc.Descendants("Name"))
                       {
                           
                          hashValue = (string)hashElement;
                         
                          if(hashValue == "CorrectAnswer")
                          {
                              XNode nod = hashElement.NextNode;
                              corrAns = (string)(nod as XElement);
                             
                          }
                         else if (hashValue == "Options")
                          {
                              XNode nod = hashElement.NextNode;
                              choices = (string)(nod as XElement);
                             
                          }
                          else if (hashValue == "TypeOfQuestion")
                          {
                              XNode nod = hashElement.NextNode;
                              typofAns = (string)(nod as XElement);
                              //foreach (XElement hasValue in doc.Descendants("Value"))
                              //{
                              //    typofAns = (string)hasValue;
                              //}
                          }
                       }
                      dt.Rows.Add(Fi.Title, choices, typofAns);
                   }
               }


           }
           return dt;
       }
       public bool DownloadDoc()
       {
           return false;
       }
       #endregion


       /*for geting all topics of learning material */
        public DataTable GetAllTopicsBAL()
       {
           MobAppSer.ParameterHelperCommon paramHelp = new MobAppSer.ParameterHelperCommon();
           paramHelp.URL = SiteUrl;
           paramHelp.UserID = UserName;
           paramHelp.Password = Password;
           paramHelp.ListName = "UserExtendedProperties";
           bool isValidate = MobAppSer.SPClientHelper.ValidateLogin(paramHelp);

           ClientContext clientContext = MobAppSer.SPClientHelper.ConnectToSite(paramHelp);

           Web w = clientContext.Web;
           clientContext.Load(w);
           var list = w.Lists.GetByTitle("TopicsForLearningMaterial");
           clientContext.Load(list);

           List<string> strConditionsOrderBy = new List<string>();
          
           SP.CamlQuery query = new SP.CamlQuery();
           var qry = SP.CamlQuery.CreateAllFoldersQuery();
           var category = list.GetItems(query);
           clientContext.Load(category);
           clientContext.ExecuteQuery();
           DataTable dt = new DataTable();

           dt = ConvertListCollInDatatable(category);

           return dt;
       }
        public DataTable GetAllDocumentBAL(string RowLimit, string PageInfo,string EmailID)
        {
            MobAppSer.ParameterHelperCommon paramHelp = new MobAppSer.ParameterHelperCommon();
            paramHelp.URL = SiteUrl;
            paramHelp.UserID = UserName;
            paramHelp.Password = Password;
            paramHelp.ListName = "UserExtendedProperties";
            bool isValidate = MobAppSer.SPClientHelper.ValidateLogin(paramHelp);

            ClientContext clientContext = MobAppSer.SPClientHelper.ConnectToSite(paramHelp);

            Web w = clientContext.Web;
            clientContext.Load(w);
            var list = w.Lists.GetByTitle("LearningMaterialDocuments");
            clientContext.Load(list);

            Microsoft.SharePoint.Client.ListItemCollectionPosition test = new ListItemCollectionPosition();
            test.PagingInfo = "Paged=TRUE&" + PageInfo;


            List<string> strConditionsOrderBy = new List<string>();

            SP.CamlQuery query = new SP.CamlQuery();
            query.ViewXml = "<View Scope='RecursiveAll'><RowLimit>" + RowLimit + "</RowLimit></View>";
            query.ListItemCollectionPosition = test;

            string str = "";

            var document = list.GetItems(query);
            clientContext.Load(document);
            clientContext.ExecuteQuery();

            itemPosition = document.ListItemCollectionPosition;

            DataTable dtItm = new DataTable();
            if (itemPosition != null)
            {
                str = itemPosition.PagingInfo.Substring(itemPosition.PagingInfo.IndexOf('&') + 1);
            }


            /********** For Geting list of favourites for checking isFavourite **************/

            var listOfFav = w.Lists.GetByTitle("Favourites");
            clientContext.Load(listOfFav);

            List<string> strConditions = new List<string>();
            strConditions.Add(CAMLHelper.GetCAMLFieldRefCondition("EmailID".ToString(), CAMLHelper.DataType.Text, EmailID.ToString(), CAMLHelper.OpeatorType.Equal, false));
            strConditions.Add(CAMLHelper.GetCAMLFieldRefCondition("TypeOfFavourite".ToString(), CAMLHelper.DataType.Text, "Document".ToString(), CAMLHelper.OpeatorType.Equal, false));

            string FinalConditionOfFav = CAMLHelper.MergeCAMLConditions(strConditions, CAMLHelper.MergeType.And, true);
            paramHelp.CAMLQuery = "<View Scope='RecursiveAll'><Query>" + FinalConditionOfFav + " </Query></View>";

            SP.CamlQuery queryForFav = new SP.CamlQuery();
            queryForFav.ViewXml = paramHelp.CAMLQuery;

            var FavItems = listOfFav.GetItems(queryForFav);
            clientContext.Load(FavItems);
            clientContext.ExecuteQuery();

            DataTable dtOfFav = new DataTable();

            dtOfFav = ConvertListCollInDatatable(FavItems);
            
            DataTable dt = new DataTable();
            DataTable dtFinal = new DataTable();

            dt = ConvertListCollInDatatable(document);

            if (dt != null && dt.Rows.Count > 0)
            {
                dt.Columns.Add("PageInfo");
                dt.Columns.Add("IsFavourite");
                dt.Columns.Add("FavouriteID");
                foreach (DataRow dr in dt.Rows)
                {
                    dr["PageInfo"] = str;
                }
                if (dtOfFav != null && dtOfFav.Rows.Count > 0)
                {
                    /* used for joining two datatables */
                    var ret = (from p in dt.AsEnumerable()
                               join q in dtOfFav.AsEnumerable() on p.Field<string>("ID") equals q.Field<string>("ItemID")
                               into UP
                               from q in UP.DefaultIfEmpty()//stuff in UP.DefaultIfEmpty()
                               select new
                               {
                                   ID = p.Field<string>("ID"),
                                   Title = p.Field<string>("Title"),
                                   Category = p.Field<string>("Category"),
                                   Category_x003a_ID = p.Field<string>("Category_x003a_ID"),
                                   Topic = p.Field<string>("Topic"),
                                   Topic_x003a_ID = p.Field<string>("Topic_x003a_ID"),
                                   PostQuiz = p.Field<string>("PostQuiz"),
                                   PostQuiz_x003a_ID = p.Field<string>("PostQuiz_x003a_ID"),
                                   PreQuiz = p.Field<string>("PreQuiz"),
                                   PreQuiz_x003a_ID = p.Field<string>("PreQuiz_x003a_ID"),
                                   PageInfo = p.Field<string>("PageInfo"),
                                   IsFavourite = q == null ? "False" : "True",
                                   FavouriteID =q == null ?"-1": q.Field<string>("ID")
                                   // q.Field<string>("ItemID") 
                                   //    ItemID = false
                               });//.ToList();

                    dtFinal = LINQResultToDataTable(ret);
                    return dtFinal;
                }
                else
                {
                    return dt;
                }
            }
            else
            {
                return null;
            }
           
           
        }
        public DataTable GetAllArticleBAL(string RowLimit, string PageInfo,string EmailID)
        {
            MobAppSer.ParameterHelperCommon paramHelp = new MobAppSer.ParameterHelperCommon();
            paramHelp.URL = SiteUrl;
            paramHelp.UserID = UserName;
            paramHelp.Password = Password;
            paramHelp.ListName = "UserExtendedProperties";
            bool isValidate = MobAppSer.SPClientHelper.ValidateLogin(paramHelp);

            ClientContext clientContext = MobAppSer.SPClientHelper.ConnectToSite(paramHelp);

            Web w = clientContext.Web;
            clientContext.Load(w);
            var list = w.Lists.GetByTitle("LearningMaterialArticlesList");
            clientContext.Load(list);

            Microsoft.SharePoint.Client.ListItemCollectionPosition test = new ListItemCollectionPosition();
            test.PagingInfo = "Paged=TRUE&" + PageInfo;


            List<string> strConditionsOrderBy = new List<string>();

            SP.CamlQuery query = new SP.CamlQuery();
           //// query.ViewXml = "<View'><RowLimit>" + RowLimit + "</RowLimit></View>";
           //   query = SP.CamlQuery.CreateAllFoldersQuery();
           //var category = list.GetItems(query)
            query.ListItemCollectionPosition = test;

            string str = "";

            var document = list.GetItems(query);
            clientContext.Load(document);
            clientContext.ExecuteQuery();

            itemPosition = document.ListItemCollectionPosition;

            DataTable dtItm = new DataTable();
            if (itemPosition != null)
            {
                str = itemPosition.PagingInfo.Substring(itemPosition.PagingInfo.IndexOf('&') + 1);
            }


            DataTable dt = new DataTable();

            dt = ConvertListCollInDatatable(document);
            /********** For Geting list of favourites for checking isFavourite **************/

            var listOfFav = w.Lists.GetByTitle("Favourites");
            clientContext.Load(listOfFav);

            List<string> strConditions = new List<string>();
            strConditions.Add(CAMLHelper.GetCAMLFieldRefCondition("EmailID".ToString(), CAMLHelper.DataType.Text, EmailID.ToString(), CAMLHelper.OpeatorType.Equal, false));
            strConditions.Add(CAMLHelper.GetCAMLFieldRefCondition("TypeOfFavourite".ToString(), CAMLHelper.DataType.Text, "Article".ToString(), CAMLHelper.OpeatorType.Equal, false));

            string FinalConditionOfFav = CAMLHelper.MergeCAMLConditions(strConditions, CAMLHelper.MergeType.And, true);
            paramHelp.CAMLQuery = "<View Scope='RecursiveAll'><Query>" + FinalConditionOfFav + " </Query></View>";

            SP.CamlQuery queryForFav = new SP.CamlQuery();
            queryForFav.ViewXml = paramHelp.CAMLQuery;

            var FavItems = listOfFav.GetItems(queryForFav);
            clientContext.Load(FavItems);
            clientContext.ExecuteQuery();

            DataTable dtOfFav = new DataTable();

            dtOfFav = ConvertListCollInDatatable(FavItems);

           
            DataTable dtFinal = new DataTable();

            dt = ConvertListCollInDatatable(document);

            if (dt != null && dt.Rows.Count > 0)
            {
                dt.Columns.Add("PageInfo");
                dt.Columns.Add("IsFavourite");
                dt.Columns.Add("FavouriteID");
                foreach (DataRow dr in dt.Rows)
                {
                    dr["PageInfo"] = str;
                }
                if (dtOfFav != null && dtOfFav.Rows.Count > 0)
                {
                    /* used for joining two datatables */
                    var ret = (from p in dt.AsEnumerable()
                               join q in dtOfFav.AsEnumerable() on p.Field<string>("ID") equals q.Field<string>("ItemID")
                               into UP
                               from q in UP.DefaultIfEmpty()//stuff in UP.DefaultIfEmpty()
                               select new
                               {
                                   ID = p.Field<string>("ID"),
                                   Title = p.Field<string>("Title"),
                                   ArticleBody = p.Field<string>("ArticleBody"),
                                   Category = p.Field<string>("Category"),
                                   Category_x003a_ID = p.Field<string>("Category_x003a_ID"),
                                   TopicName = p.Field<string>("TopicName"),
                                   TopicName_x003a_ID = p.Field<string>("TopicName_x003a_ID"),
                                   PostQuiz = p.Field<string>("PostQuiz"),
                                   PostQuiz_x003a_ID = p.Field<string>("PostQuiz_x003a_ID"),
                                   PreQuiz = p.Field<string>("PreQuiz"),
                                   PreQuiz_x003a_ID = p.Field<string>("PreQuiz_x003a_ID"),
                                   PageInfo = p.Field<string>("PageInfo"),
                                   IsFavourite = q == null ? "False" : "True",
                                   FavouriteID = q == null ? "-1" : q.Field<string>("ID")// q.Field<string>("ItemID") 
                                   //    ItemID = false
                               });//.ToList();

                    dtFinal = LINQResultToDataTable(ret);
                    return dtFinal;
                }
                else
                {
                    return dt;
                }
            }
            else
            {
                return null;
            }
            //dt.Columns.Add("PageInfo");
            //foreach (DataRow dr in dt.Rows)
            //    {
            //        dr["PageInfo"] = str;
            //    }
            //return dt;
        }
        public DataTable GetQuizBAL(string QuizID)
        {
            MobAppSer.ParameterHelperCommon paramHelp = new MobAppSer.ParameterHelperCommon();
            paramHelp.URL = SiteUrl;
            paramHelp.UserID = UserName;
            paramHelp.Password = Password;
            paramHelp.ListName = "UserExtendedProperties";
            bool isValidate = MobAppSer.SPClientHelper.ValidateLogin(paramHelp);

            ClientContext clientContext = MobAppSer.SPClientHelper.ConnectToSite(paramHelp);

            Web w = clientContext.Web;
            clientContext.Load(w);
            var list = w.Lists.GetByTitle("LearningMaterialQuizes");
            clientContext.Load(list);
            clientContext.ExecuteQuery();

            ListItem lstitm=list.GetItemById(QuizID);
            clientContext.Load(lstitm);
            clientContext.ExecuteQuery();

            List<string> strConditionsOrderBy = new List<string>();
            strConditionsOrderBy.Add(CAMLHelper.GetCAMLFieldRefCondition("FileDirRef".ToString(), CAMLHelper.DataType.Text, "/Lists/LearningMaterialQuizes/" + lstitm["Title"].ToString(), CAMLHelper.OpeatorType.Equal, false));
            string FinalCondition = CAMLHelper.MergeCAMLConditions(strConditionsOrderBy, CAMLHelper.MergeType.And, true);
            paramHelp.CAMLQuery = "<View Scope='RecursiveAll'><Query>" + FinalCondition + " </Query></View>";
           // paramHelp.CAMLQuery = "<View Scope='RecursiveAll'><Query></Query></View>";
            

            SP.CamlQuery query = new SP.CamlQuery();
            query.ViewXml = paramHelp.CAMLQuery;

            ListItemCollection quiz = list.GetItems(query);


            FolderCollection collFolder = list.RootFolder.Folders;
            clientContext.Load(collFolder);
            clientContext.ExecuteQuery();


            //clientContext.Load(quiz);
            clientContext.Load(quiz);
            
            clientContext.ExecuteQuery();
           
            DataTable dt = new DataTable();

            dt = ConvertListCollInDatatable(quiz);
            if(dt!=null)
            {
                dt.Columns.Add("QuizName");
                foreach(DataRow dr in dt.Rows)
                {
                    dr["QuizName"] = lstitm["Title"].ToString();
                }
            }
            return dt;
        }
        public DataTable QuizResponseBAL(InputObjForQuizResponse obj)
        {
            MobAppSer.ParameterHelperCommon paramHelp = new MobAppSer.ParameterHelperCommon();
            paramHelp.URL = SiteUrl;
            paramHelp.UserID = UserName;
            paramHelp.Password = Password;
            paramHelp.ListName = "UserExtendedProperties";
            bool isValidate = MobAppSer.SPClientHelper.ValidateLogin(paramHelp);

            ClientContext clientContext = MobAppSer.SPClientHelper.ConnectToSite(paramHelp);

            Web w = clientContext.Web;
            clientContext.Load(w);
            var list = w.Lists.GetByTitle("LearningMaterialQuizeResponses");
            clientContext.Load(list);

            Guid g;
            g = Guid.NewGuid();

            ListItemCreationInformation info = new ListItemCreationInformation();
            info.UnderlyingObjectType = FileSystemObjectType.Folder;
            string FolderName = "";
            FolderName = obj.QuizID + "_" + obj.AnnonymousName + "_" + g;
            info.LeafName = FolderName.Trim();//Trim for spaces.Just extra check
            ListItem newItem = list.AddItem(info);
            newItem["Title"] = FolderName;


           

            var listOfQuiz = w.Lists.GetByTitle("LearningMaterialQuizes");
            clientContext.Load(listOfQuiz);

            List<string> strConditionslistOfQuiz = new List<string>();
            strConditionslistOfQuiz.Add(CAMLHelper.GetCAMLFieldRefCondition("ID".ToString(), CAMLHelper.DataType.Text, obj.QuizID.ToString(), CAMLHelper.OpeatorType.Equal, false));
            string FinalConditionOfQuiz = CAMLHelper.MergeCAMLConditions(strConditionslistOfQuiz, CAMLHelper.MergeType.And, true);
            paramHelp.CAMLQuery = "<View Scope='RecursiveAll'><Query>" + FinalConditionOfQuiz + "</Query></View>";
            SP.CamlQuery queryOfQuiz = new SP.CamlQuery();
            queryOfQuiz.ViewXml = paramHelp.CAMLQuery;
            var quizlist = listOfQuiz.GetItems(queryOfQuiz);

            clientContext.Load(quizlist);
            clientContext.ExecuteQuery();


            FieldLookupValue lvforquiz = new FieldLookupValue();
            lvforquiz.LookupId = int.Parse(quizlist[0]["ID"].ToString());
            newItem["QuizId"] = lvforquiz;

            newItem.Update();
            var list2 = w.Lists.GetByTitle("UserExtendedProperties");
            clientContext.Load(list2);

            List<string> strConditionsOrderByForusr = new List<string>();
            strConditionsOrderByForusr.Add(CAMLHelper.GetCAMLFieldRefCondition("EmailID".ToString(), CAMLHelper.DataType.Text, obj.EmailID.ToString(), CAMLHelper.OpeatorType.Equal, false));
            string FinalConditionForusr = CAMLHelper.MergeCAMLConditions(strConditionsOrderByForusr, CAMLHelper.MergeType.And, true);
            paramHelp.CAMLQuery = "<View Scope='RecursiveAll'><Query>" + FinalConditionForusr + "</Query></View>";
            SP.CamlQuery queryforusr = new SP.CamlQuery();
            queryforusr.ViewXml = paramHelp.CAMLQuery;
            var usrlist = list2.GetItems(queryforusr);

            clientContext.Load(usrlist);
            clientContext.ExecuteQuery();

            FieldLookupValue lv = new FieldLookupValue();
            lv.LookupId = int.Parse(usrlist[0]["ID"].ToString());
            newItem["EmailId"] = lv;
            newItem.Update();

            newItem["DocumentOrArticleId"] = obj.DocOrArtID;
            newItem.Update();
            newItem["TypeDocOrArt"] = obj.TypeDocOrArt;
            newItem.Update();
            clientContext.ExecuteQuery();



            foreach (var iteminlst in obj.ResponseOfQuizResponseList)
            {
                ListItemCreationInformation listInfo = new ListItemCreationInformation();

                string str = "/Lists/LearningMaterialQuizeResponses/" + FolderName;

                listInfo.FolderUrl = str;

                ListItem item = list.AddItem(listInfo);

                item["QuestionId"] = iteminlst.QuestionID;
                item["QuestionAns"] = iteminlst.QuestionsAns;

                item.Update();
            }
            
            clientContext.ExecuteQuery();
            var listofquiz = w.Lists.GetByTitle("LearningMaterialQuizes");
            clientContext.Load(listofquiz);
            clientContext.ExecuteQuery();
            DataTable dtForCrctAns = new DataTable();

            ListItem lstitm = listofquiz.GetItemById(obj.QuizID);
            clientContext.Load(lstitm);
            clientContext.ExecuteQuery();

            string QuizName = lstitm["Title"].ToString();


            List<string> strConditionsOrderBy = new List<string>();
            strConditionsOrderBy.Add(CAMLHelper.GetCAMLFieldRefCondition("FileDirRef".ToString(), CAMLHelper.DataType.Text, "/Lists/LearningMaterialQuizes/" + lstitm["Title"].ToString(), CAMLHelper.OpeatorType.Equal, false));
            string FinalCondition = CAMLHelper.MergeCAMLConditions(strConditionsOrderBy, CAMLHelper.MergeType.And, true);
            paramHelp.CAMLQuery = "<View Scope='RecursiveAll'><Query>" + FinalCondition + " </Query></View>";
            DataTable dtFromCrctAns = new DataTable();
            dtFromCrctAns.Columns.Add("QustionID");
            dtFromCrctAns.Columns.Add("CorrectAns");


            SP.CamlQuery query = new SP.CamlQuery();
            query.ViewXml = paramHelp.CAMLQuery;

            ListItemCollection quizforCrctAns = listofquiz.GetItems(query);
            clientContext.Load(quizforCrctAns);

            clientContext.ExecuteQuery();
            DataTable dt = new DataTable();
            dt = ConvertListCollInDatatable(quizforCrctAns);

           

            if (dt != null && dt.Rows.Count > 0)
            {
                

                foreach (DataRow dr in dt.Rows)
                {
                    dtFromCrctAns.Rows.Add(dr["ID"], dr["CorrectAnswer"]);
                }
            }
            string date = null;
            foreach (DataRow drforupd in dtFromCrctAns.Rows)
            {
                List<string> strConditionsOrderBy2 = new List<string>();
                strConditionsOrderBy2.Add(CAMLHelper.GetCAMLFieldRefCondition("FileDirRef".ToString(), CAMLHelper.DataType.Text, "/Lists/LearningMaterialQuizeResponses/" + FolderName.ToString(), CAMLHelper.OpeatorType.Equal, false));
                strConditionsOrderBy2.Add(CAMLHelper.GetCAMLFieldRefCondition("QuestionId".ToString(), CAMLHelper.DataType.Text, drforupd["QustionID"].ToString(), CAMLHelper.OpeatorType.Equal, false));
                string FinalCondition2 = CAMLHelper.MergeCAMLConditions(strConditionsOrderBy2, CAMLHelper.MergeType.And, true);
                paramHelp.CAMLQuery = "<View Scope='RecursiveAll'><Query>" + FinalCondition2 + " </Query></View>";


                SP.CamlQuery query2 = new SP.CamlQuery();
                query2.ViewXml = paramHelp.CAMLQuery;

                ListItemCollection itmcol = list.GetItems(query2);
                clientContext.Load(itmcol);
                clientContext.ExecuteQuery();
                if (itmcol.Count > 0)
                {
                    itmcol[0]["CorrectAns"] = drforupd["CorrectAns"].ToString();
                    if (itmcol[0]["QuestionAns"].ToString().Equals(itmcol[0]["CorrectAns"].ToString()))
                    {
                        itmcol[0]["IsCorrect"] = "1";
                    }
                    date = itmcol[0]["Created"].ToString();
                    itmcol[0].Update();
                }
            }

            List<string> strConditionsOrderBy3 = new List<string>();
            strConditionsOrderBy3.Add(CAMLHelper.GetCAMLFieldRefCondition("FileDirRef".ToString(), CAMLHelper.DataType.Text, "/Lists/LearningMaterialQuizeResponses/" + FolderName.ToString(), CAMLHelper.OpeatorType.Equal, false));
            strConditionsOrderBy3.Add(CAMLHelper.GetCAMLFieldRefCondition("IsCorrect".ToString(), CAMLHelper.DataType.Text, "1".ToString(), CAMLHelper.OpeatorType.Equal, false));
            string FinalCondition3 = CAMLHelper.MergeCAMLConditions(strConditionsOrderBy3, CAMLHelper.MergeType.And, true);
            paramHelp.CAMLQuery = "<View Scope='RecursiveAll'><Query>" + FinalCondition3 + " </Query></View>";


            SP.CamlQuery query3 = new SP.CamlQuery();
            query3.ViewXml = paramHelp.CAMLQuery;

            ListItemCollection itmcolForall = list.GetItems(query3);
            clientContext.Load(itmcolForall);
            clientContext.ExecuteQuery();



            List<string> strConditionsOrderBy4 = new List<string>();
            strConditionsOrderBy4.Add(CAMLHelper.GetCAMLFieldRefCondition("FileDirRef".ToString(), CAMLHelper.DataType.Text, "/Lists/LearningMaterialQuizeResponses/" + FolderName.ToString(), CAMLHelper.OpeatorType.Equal, false));
            string FinalCondition4 = CAMLHelper.MergeCAMLConditions(strConditionsOrderBy4, CAMLHelper.MergeType.And, true);
            paramHelp.CAMLQuery = "<View Scope='RecursiveAll'><Query>" + FinalCondition4 + " </Query></View>";


            SP.CamlQuery query4 = new SP.CamlQuery();
            query4.ViewXml = paramHelp.CAMLQuery;

            ListItemCollection itmforCountAll = list.GetItems(query4);
            clientContext.Load(itmforCountAll);
            clientContext.ExecuteQuery();


            
            dtForCrctAns.Columns.Add("TotalQuesCount");
            dtForCrctAns.Columns.Add("CorrectAnsCount");
            dtForCrctAns.Columns.Add("QuizName");
            dtForCrctAns.Columns.Add("Date");
            if (itmforCountAll.Count > 0)
            {
                dtForCrctAns.Rows.Add(itmforCountAll.Count.ToString(), itmcolForall.Count.ToString() == "" ? "0" : itmcolForall.Count.ToString(), QuizName,date);
            }
            else
            {
                dtForCrctAns.Rows.Add("0");
            }



          

            return dtForCrctAns;
        }
        public Stream GetDocumentByIDBAL(string DocID)
        {
            Stream stream = null;
            MobAppSer.ParameterHelperCommon paramHelp = new MobAppSer.ParameterHelperCommon();
            paramHelp.URL = SiteUrl;
            paramHelp.UserID = UserName;
            paramHelp.Password = Password;
            paramHelp.ListName = "UserExtendedProperties";
            bool isValidate = MobAppSer.SPClientHelper.ValidateLogin(paramHelp);

            ClientContext clientContext = MobAppSer.SPClientHelper.ConnectToSite(paramHelp);

            Web w = clientContext.Web;

            clientContext.Load(w);

            string LibraryName = "LearningMaterialDocuments";
            var list = clientContext.Web.Lists.GetByTitle(LibraryName);

            clientContext.Load(list, l => l.RootFolder.ServerRelativeUrl);
            clientContext.ExecuteQuery();

            List<string> strConditionsOrderBy = new List<string>();
            strConditionsOrderBy.Add(CAMLHelper.GetCAMLFieldRefCondition("ID".ToString(), CAMLHelper.DataType.Text, DocID.ToString(), CAMLHelper.OpeatorType.Equal, false));

            string FinalCondition = CAMLHelper.MergeCAMLConditions(strConditionsOrderBy, CAMLHelper.MergeType.And, true);
            paramHelp.CAMLQuery = "<View><Query>" + FinalCondition + "</View></Query>";

            SP.CamlQuery query = new SP.CamlQuery();
            query.ViewXml = paramHelp.CAMLQuery;
            bool found = false;
            var listItem=null as ListItem;
            try
            {
                var items = list.GetItems(query);

                clientContext.Load(items, l => l.IncludeWithDefaultProperties(i => i.Folder, i => i.File, i => i.DisplayName));
                clientContext.ExecuteQuery();

                 listItem = list.GetItemById(DocID);
                clientContext.Load(list);
                clientContext.Load(listItem);
                clientContext.Load(listItem, i => i.File);
                clientContext.ExecuteQuery();
                found = true;
            }
            catch (Exception e)
            {
                found = false;
            }

            if (found)
            {
                var fileRef = listItem.File.ServerRelativeUrl;
                var fileInfo = Microsoft.SharePoint.Client.File.OpenBinaryDirect(clientContext, fileRef);
                fileInfo.Stream.ReadTimeout = 120000000;
                var fileName = Path.Combine("C:\\Docs", (string)listItem.File.Name);
                using (var fileStream = System.IO.File.Create(fileName))
                {
                    fileInfo.Stream.CopyTo(fileStream);
                }

                string path = @"C:\\Docs\\" + (string)listItem.File.Name;
                System.IO.FileInfo file = new System.IO.FileInfo(path);
                try
                {
                    if (file.Exists)
                    {
                        stream = DownloadFile(path, file);

                        //System.Web.HttpContext.Current.Response.Clear();
                        //System.Web.HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment; filename=" + file.Name);
                        //System.Web.HttpContext.Current.Response.AddHeader("Content-Length", file.Length.ToString());
                        //System.Web.HttpContext.Current.Response.ContentType = "application/octet-stream";
                        //// System.Web.HttpContext.Current.Response.ContentType = MimeTypes.MimeTypeMap.GetMimeType("png");
                        //System.Web.HttpContext.Current.Response.WriteFile(file.FullName);


                        //System.Web.HttpContext.Current.Response.WriteFile(file.FullName, 0, file.Length);

                        //System.Web.HttpContext.Current.Response.End();
                        //System.Web.HttpContext.Current.Response.Close();
                        System.IO.FileInfo fi = new System.IO.FileInfo(path);
                        fi.Delete();


                        //Web w2 = clientContext.Web;
                        //clientContext.Load(w);
                        //var list2 = w.Lists.GetByTitle("LogMobAppError");
                        //clientContext.Load(list2);

                        //ListItemCreationInformation itemCreateInfo = new ListItemCreationInformation();
                        //ListItem oListItem = list2.AddItem(itemCreateInfo);
                        //oListItem["Error"] = file.Length;


                        //oListItem.Update();

                        //clientContext.ExecuteQuery(); 
                    }
                    else
                    {
                        throw new Exception("File not found");
                    }

                }
                catch (Exception ex)
                {


                    Web w2 = clientContext.Web;
                    clientContext.Load(w);
                    var list2 = w.Lists.GetByTitle("LogMobAppError");
                    clientContext.Load(list2);

                    ListItemCreationInformation itemCreateInfo = new ListItemCreationInformation();
                    ListItem oListItem = list2.AddItem(itemCreateInfo);
                    oListItem["Error"] = "My New Item!";


                    oListItem.Update();

                    clientContext.ExecuteQuery();

                    System.Web.HttpContext.Current.Response.ContentType = "text/plain";
                    System.Web.HttpContext.Current.Response.Write(ex.Message);
                    System.Web.HttpContext.Current.Response.End();
                    System.Web.HttpContext.Current.Response.Close();
                }
                finally
                {

                }

                //using (WebClient myWebClient = new WebClient())
                //{
                //    string myStringWebResource = "C:\\Docs";
                //    // Download the Web resource and save it into the current filesystem folder.
                //    myWebClient.DownloadFile(myStringWebResource, "test.png");
                //}


                //DataTable dt = new DataTable();
                //return dt;
                return stream;
            }
            else
            {

                stream = null;
                return stream;
            }
        }
        public DataTable GetArticleByIDBAL(string ID)
        {
           
            MobAppSer.ParameterHelperCommon paramHelp = new MobAppSer.ParameterHelperCommon();
            paramHelp.URL = SiteUrl;
            paramHelp.UserID = UserName;
            paramHelp.Password = Password;
            paramHelp.ListName = "UserExtendedProperties";
            bool isValidate = MobAppSer.SPClientHelper.ValidateLogin(paramHelp);

            ClientContext clientContext = MobAppSer.SPClientHelper.ConnectToSite(paramHelp);

            Web w = clientContext.Web;

            clientContext.Load(w);

            string LibraryName = "LearningMaterialArticlesList";
            var list = clientContext.Web.Lists.GetByTitle(LibraryName);

            clientContext.Load(list, l => l.RootFolder.ServerRelativeUrl);
            clientContext.ExecuteQuery();

            List<string> strConditionsOrderBy = new List<string>();
            strConditionsOrderBy.Add(CAMLHelper.GetCAMLFieldRefCondition("ID".ToString(), CAMLHelper.DataType.Text, ID.ToString(), CAMLHelper.OpeatorType.Equal, false));

            string FinalCondition = CAMLHelper.MergeCAMLConditions(strConditionsOrderBy, CAMLHelper.MergeType.And, true);
            paramHelp.CAMLQuery = "<View><Query>" + FinalCondition + "</View></Query>";

            SP.CamlQuery query = new SP.CamlQuery();
            query.ViewXml = paramHelp.CAMLQuery;


            var items = list.GetItems(query);
            clientContext.Load(items, l => l.IncludeWithDefaultProperties(i => i.Folder, i => i.File, i => i.DisplayName));
            clientContext.ExecuteQuery();

            var listItem = list.GetItemById(ID);
            clientContext.Load(list);
            clientContext.Load(listItem, i => i.File);
            clientContext.ExecuteQuery();
             DataTable dt = new DataTable();

           dt = ConvertListCollInDatatable(items);
            return dt;
           

           
        }
        public DataTable GetResultOfUserBAL(string EmailID)
           {
               
            MobAppSer.ParameterHelperCommon paramHelp = new MobAppSer.ParameterHelperCommon();
            paramHelp.URL = SiteUrl;
            paramHelp.UserID = UserName;
            paramHelp.Password = Password;
            paramHelp.ListName = "UserExtendedProperties";
            bool isValidate = MobAppSer.SPClientHelper.ValidateLogin(paramHelp);

            ClientContext clientContext = MobAppSer.SPClientHelper.ConnectToSite(paramHelp);

            Web w = clientContext.Web;

            clientContext.Load(w);

            string LibraryName = "LearningMaterialQuizeResponses";
            var list = clientContext.Web.Lists.GetByTitle(LibraryName);

            clientContext.Load(list, l => l.RootFolder.ServerRelativeUrl);
            clientContext.ExecuteQuery();

            List<string> strConditionsOrderBy = new List<string>();
            strConditionsOrderBy.Add(CAMLHelper.GetCAMLFieldRefCondition("EmailId".ToString(), CAMLHelper.DataType.Text, EmailID.ToString(), CAMLHelper.OpeatorType.Equal, false));
            //strConditionsOrderBy.Add(CAMLHelper.GetCAMLFieldRefCondition("DocumentOrArticleId".ToString(), CAMLHelper.DataType.Text, DocOrArtID.ToString(), CAMLHelper.OpeatorType.Equal, false));
            //strConditionsOrderBy.Add(CAMLHelper.GetCAMLFieldRefCondition("TypeDocOrArt".ToString(), CAMLHelper.DataType.Text, TypeDocOrArt.ToString(), CAMLHelper.OpeatorType.Equal, false));
            //strConditionsOrderBy.Add(CAMLHelper.GetCAMLFieldRefCondition("QuizId_x003A_ID".ToString(), CAMLHelper.DataType.Text, QuizID.ToString(), CAMLHelper.OpeatorType.Equal, false));

            string FinalCondition = CAMLHelper.MergeCAMLConditions(strConditionsOrderBy, CAMLHelper.MergeType.And, true);
            paramHelp.CAMLQuery = "<View><Query>" + FinalCondition + "</View></Query>";

            SP.CamlQuery query = new SP.CamlQuery();
            query.ViewXml = paramHelp.CAMLQuery;


            var items = list.GetItems(query);
            clientContext.Load(items, l => l.IncludeWithDefaultProperties(i => i.Folder, i => i.File, i => i.DisplayName));
            clientContext.ExecuteQuery();

           
            clientContext.ExecuteQuery();
             DataTable dt = new DataTable();
             if (items.Count > 0)
             {
                 dt = ConvertListCollInDatatable(items);

                 //var listofquiz = w.Lists.GetByTitle("LearningMaterialQuizes");
                 //clientContext.Load(listofquiz);
                 //clientContext.ExecuteQuery();
                 DataTable dtForRept = new DataTable();
                 dtForRept.Columns.Add("QuizName");
                 dtForRept.Columns.Add("Date");
                 dtForRept.Columns.Add("TotalNoOfQues");
                 dtForRept.Columns.Add("CorrectNoOfQues");
                 string Date = null;
                 foreach (DataRow dr in dt.Rows)
                 {
                     List<string> strConditionsForQuiz = new List<string>();
                     strConditionsForQuiz.Add(CAMLHelper.GetCAMLFieldRefCondition("FileDirRef".ToString(), CAMLHelper.DataType.Text, "/Lists/LearningMaterialQuizeResponses/" + dr["Title"].ToString(), CAMLHelper.OpeatorType.Equal, false));
                     string FinalConditionForQuiz = CAMLHelper.MergeCAMLConditions(strConditionsForQuiz, CAMLHelper.MergeType.And, true);
                     paramHelp.CAMLQuery = "<View Scope='RecursiveAll'><Query>" + FinalConditionForQuiz + " </Query></View>";


                     SP.CamlQuery queryforQuiz = new SP.CamlQuery();
                     queryforQuiz.ViewXml = paramHelp.CAMLQuery;

                     ListItemCollection quizforCrctAns = list.GetItems(queryforQuiz);
                     clientContext.Load(quizforCrctAns);

                     clientContext.ExecuteQuery();

                     DataTable dtForQuiz = new DataTable();

                     dtForQuiz = ConvertListCollInDatatable(quizforCrctAns);
                     // Date = dtForQuiz.Rows[0]["Created"].ToString();

                     Date = quizforCrctAns[0]["Created"].ToString();


                     List<string> strConditionsOrderBy3 = new List<string>();
                     strConditionsOrderBy3.Add(CAMLHelper.GetCAMLFieldRefCondition("FileDirRef".ToString(), CAMLHelper.DataType.Text, "/Lists/LearningMaterialQuizeResponses/" + dr["Title"].ToString(), CAMLHelper.OpeatorType.Equal, false));
                     strConditionsOrderBy3.Add(CAMLHelper.GetCAMLFieldRefCondition("IsCorrect".ToString(), CAMLHelper.DataType.Text, "1".ToString(), CAMLHelper.OpeatorType.Equal, false));
                     string FinalCondition3 = CAMLHelper.MergeCAMLConditions(strConditionsOrderBy3, CAMLHelper.MergeType.And, true);
                     paramHelp.CAMLQuery = "<View Scope='RecursiveAll'><Query>" + FinalCondition3 + " </Query></View>";


                     SP.CamlQuery query3 = new SP.CamlQuery();
                     query3.ViewXml = paramHelp.CAMLQuery;

                     ListItemCollection itmcolForall = list.GetItems(query3);
                     clientContext.Load(itmcolForall);
                     clientContext.ExecuteQuery();

                     DataTable dtForQuizCorrctAns = new DataTable();

                     dtForQuizCorrctAns = ConvertListCollInDatatable(itmcolForall);


                     if (quizforCrctAns.Count > 0)
                     {
                         dtForRept.Rows.Add(dr["QuizId"].ToString(), Date, quizforCrctAns.Count.ToString(), itmcolForall.Count.ToString() == "" ? "0" : itmcolForall.Count.ToString());
                     }
                     else
                     {
                         dtForRept.Rows.Add("0");
                     }
                 }
                 return dtForRept;
             }
             else
             {
                 return null;
             }
           
           

           }
       #endregion
        #region "Category"
       public DataTable GetAllCategoriesListBAL()
       {
           MobAppSer.ParameterHelperCommon paramHelp = new MobAppSer.ParameterHelperCommon();
           paramHelp.URL = SiteUrl;
           paramHelp.UserID = UserName;
           paramHelp.Password = Password;
           paramHelp.ListName = "UserExtendedProperties";
           bool isValidate = MobAppSer.SPClientHelper.ValidateLogin(paramHelp);

           ClientContext clientContext = MobAppSer.SPClientHelper.ConnectToSite(paramHelp);

           Web w = clientContext.Web;
           //var lists = clientContext.LoadQuery(w.Lists);

           clientContext.Load(w);
           //List list = w.Lists.GetByTitle(paramHelp.ListName);
           // clientContext.Load(list);

           var list = w.Lists.GetByTitle("Category");
           clientContext.Load(list);

           List<string> strConditionsOrderBy = new List<string>();
           //   strConditionsOrderBy.Add(CAMLHelper.GetCAMLFieldRefCondition("ContentType".ToString(), CAMLHelper.DataType.Text, "Discussion".ToString(), CAMLHelper.OpeatorType.Equal, false));

           // strConditionsOrderBy.Add(CAMLHelper.GetCAMLFieldRefCondition("Active".ToString(), CAMLHelper.DataType.Text, "1".ToString(), CAMLHelper.OpeatorType.Equal, false));

           //  string FinalCondition = CAMLHelper.MergeCAMLConditions(strConditionsOrderBy, CAMLHelper.MergeType.And, true);
           //   paramHelp.CAMLQuery = "<View Scope='RecursiveAll'>" + FinalCondition + "<RowLimit>" + RowLimit + "</RowLimit></View>";

           //  Microsoft.SharePoint.Client.ListItemCollectionPosition test = new ListItemCollectionPosition();
           //   test.PagingInfo = "Paged=TRUE&" + PageInfo;


           // SP.CamlQuery query = new SP.CamlQuery();
           // query.ViewXml = paramHelp.CAMLQuery;
           //  query.ListItemCollectionPosition = test;
           SP.CamlQuery query = new SP.CamlQuery();
           var qry = SP.CamlQuery.CreateAllFoldersQuery();
           var category = list.GetItems(query);
           clientContext.Load(category);
           clientContext.ExecuteQuery();
           DataTable dt = new DataTable();

           dt = ConvertListCollInDatatable(category);

           return dt;
       }
       #endregion"
        #region "Search all"
       public DataTable SeacrhingFromAllBAL(string SearchQuery, string RowLimit, string PageInfo)
       {
           MobAppSer.ParameterHelperCommon paramHelp = new MobAppSer.ParameterHelperCommon();
           paramHelp.URL = SiteUrl;
           paramHelp.UserID = UserName;
           paramHelp.Password = Password;
           paramHelp.ListName = "UserExtendedProperties";
           bool isValidate = MobAppSer.SPClientHelper.ValidateLogin(paramHelp);

           ClientContext clientContext = MobAppSer.SPClientHelper.ConnectToSite(paramHelp);

           Web w = clientContext.Web;
           clientContext.Load(w);
           DataTable dt = new DataTable();
           dt.Columns.Add("ItemId");
           dt.Columns.Add("Title");
           dt.Columns.Add("Description");
           dt.Columns.Add("LinkOfVideo");
           dt.Columns.Add("Type");
           dt.Columns.Add("Created");
           dt.Columns.Add("PageInfo");

           #region "For discussion list"
           var listofDiscussion = w.Lists.GetByTitle("Discussion Board");
           clientContext.Load(listofDiscussion);

           string str = "";
           List<string> strConditionsOrderBy = new List<string>();
           List<string> FinalStr = new List<string>();


           strConditionsOrderBy.Add(CAMLHelper.GetCAMLFieldRefCondition("FSObjType".ToString(), CAMLHelper.DataType.Integer, "1".ToString(), CAMLHelper.OpeatorType.Equal, false));
           strConditionsOrderBy.Add(CAMLHelper.GetCAMLFieldRefCondition("IsPrivate".ToString(), CAMLHelper.DataType.Text, "False".ToString(), CAMLHelper.OpeatorType.Equal, false));
           strConditionsOrderBy.Add(CAMLHelper.GetCAMLFieldRefCondition("Title".ToString(), CAMLHelper.DataType.Text, SearchQuery.ToString(), CAMLHelper.OpeatorType.Contains, false));

           FinalStr.Add(CAMLHelper.MergeCAMLConditions(strConditionsOrderBy, CAMLHelper.MergeType.And, false));
           List<string> strCondiOr = new List<string>();

           strCondiOr.Add(CAMLHelper.GetCAMLFieldRefCondition("FSObjType".ToString(), CAMLHelper.DataType.Integer, "1".ToString(), CAMLHelper.OpeatorType.Equal, false));
           strCondiOr.Add(CAMLHelper.GetCAMLFieldRefCondition("IsPrivate".ToString(), CAMLHelper.DataType.Text, "False".ToString(), CAMLHelper.OpeatorType.Equal, false));
           strCondiOr.Add(CAMLHelper.GetCAMLFieldRefCondition("Body".ToString(), CAMLHelper.DataType.Text, SearchQuery.ToString(), CAMLHelper.OpeatorType.Contains, false));
           FinalStr.Add(CAMLHelper.MergeCAMLConditions(strCondiOr, CAMLHelper.MergeType.And, false));


           string Final = CAMLHelper.MergeCAMLConditions(FinalStr, CAMLHelper.MergeType.Or, true);



           paramHelp.CAMLQuery = "<View Scope='RecursiveAll'><Query>" + Final + "</Query><RowLimit>" + RowLimit + "</RowLimit></View>";

           Microsoft.SharePoint.Client.ListItemCollectionPosition test = new ListItemCollectionPosition();
           test.PagingInfo = "Paged=TRUE&" + PageInfo;

           SP.CamlQuery query = new SP.CamlQuery();
           query.ViewXml = paramHelp.CAMLQuery;
           query.ListItemCollectionPosition = test;
           ListItemCollection discussionItems = listofDiscussion.GetItems(query);

           clientContext.Load(discussionItems);
           clientContext.ExecuteQuery();


           itemPosition = discussionItems.ListItemCollectionPosition;

           DataTable dtItm = new DataTable();
           if (itemPosition != null)
           {
               str = itemPosition.PagingInfo.Substring(itemPosition.PagingInfo.IndexOf('&') + 1);
           }


           clientContext.ExecuteQuery();
           dtItm = ConvertListCollInDatatable(discussionItems);
           if (dtItm != null && dtItm.Rows.Count > 0)
           {
               foreach (DataRow drOfFin in dtItm.Rows)
               {
                   dt.Rows.Add(drOfFin["ID"], drOfFin["Title"], drOfFin["Body"], "", "Discussion", drOfFin["Created"], "");
               }
               foreach (DataRow dr in dt.Rows)
               {
                   dr["PageInfo"] = str;
               }
           }

          
          
           #endregion
           #region "For Video list"

           int newRowLimit = 0;
           if (discussionItems.Count < Convert.ToInt32(RowLimit))
           {
               newRowLimit = Convert.ToInt32(RowLimit) - discussionItems.Count;


               var listofVid = w.Lists.GetByTitle("Videos");
               clientContext.Load(listofVid);

               List<string> strConditionsOrderByForVid = new List<string>();
               List<string> strCond = new List<string>();
               

               strConditionsOrderByForVid.Add(CAMLHelper.GetCAMLFieldRefCondition("Active".ToString(), CAMLHelper.DataType.Text, "1".ToString(), CAMLHelper.OpeatorType.Equal, false));
               strConditionsOrderByForVid.Add(CAMLHelper.GetCAMLFieldRefCondition("HeadingOfVid".ToString(), CAMLHelper.DataType.Text, SearchQuery.ToString(), CAMLHelper.OpeatorType.Contains, false));
               strCond.Add(CAMLHelper.MergeCAMLConditions(strConditionsOrderByForVid, CAMLHelper.MergeType.And, false));

               List<string> strCondForDesc = new List<string>();
               strCondForDesc.Add(CAMLHelper.GetCAMLFieldRefCondition("Active".ToString(), CAMLHelper.DataType.Text, "1".ToString(), CAMLHelper.OpeatorType.Equal, false));
               strCondForDesc.Add(CAMLHelper.GetCAMLFieldRefCondition("Description".ToString(), CAMLHelper.DataType.Text, SearchQuery.ToString(), CAMLHelper.OpeatorType.Contains, false));
               strCond.Add(CAMLHelper.MergeCAMLConditions(strCondForDesc, CAMLHelper.MergeType.And, false));

               string FinalVidSearch = CAMLHelper.MergeCAMLConditions(strCond, CAMLHelper.MergeType.Or, true);

               paramHelp.CAMLQuery = "<View Scope='RecursiveAll'><Query>" + FinalVidSearch + "</Query><RowLimit>" + newRowLimit + "</RowLimit></View>";

               Microsoft.SharePoint.Client.ListItemCollectionPosition testforVid = new ListItemCollectionPosition();
               testforVid.PagingInfo = "Paged=TRUE&" + PageInfo;


               SP.CamlQuery queryforVid = new SP.CamlQuery();
               queryforVid.ViewXml = paramHelp.CAMLQuery;
               queryforVid.ListItemCollectionPosition = testforVid;
               var videoItems = listofVid.GetItems(queryforVid);

               clientContext.Load(videoItems);
               clientContext.ExecuteQuery();
               itemPosition = videoItems.ListItemCollectionPosition;
               DataTable dtItmForVid = new DataTable();
               if (itemPosition != null)
               {
                   str = itemPosition.PagingInfo.Substring(itemPosition.PagingInfo.IndexOf('&') + 1);
               }


               clientContext.ExecuteQuery();
               dtItmForVid = ConvertListCollInDatatable(videoItems);
               if (dtItmForVid != null && dtItmForVid.Rows.Count > 0)
               {
                   foreach (DataRow drOfVid in dtItmForVid.Rows)
                   {
                       dt.Rows.Add(drOfVid["ID"], drOfVid["HeadingOfVid"], drOfVid["Description"], drOfVid["Title"], "Video", drOfVid["Created"], "");
                   }
                   foreach (DataRow dr in dt.Rows)
                   {
                       dr["PageInfo"] = str;
                   }
               }
           }
           #endregion
           #region "For Document List"

           int newRowLimitForDoc = 0;
           if (dt.Rows.Count < Convert.ToInt32(RowLimit))
           {
               newRowLimitForDoc = Convert.ToInt32(RowLimit) - dt.Rows.Count;


               var listOfDoc = w.Lists.GetByTitle("LearningMaterialDocuments");
               clientContext.Load(listOfDoc);

               List<string> strConditionsSearchFromDoc = new List<string>();

               //strConditionsSearchFromDoc.Add(CAMLHelper.GetCAMLFieldRefCondition("Active".ToString(), CAMLHelper.DataType.Text, "1".ToString(), CAMLHelper.OpeatorType.Equal, false));
               strConditionsSearchFromDoc.Add(CAMLHelper.GetCAMLFieldRefCondition("Title".ToString(), CAMLHelper.DataType.Text, SearchQuery.ToString(), CAMLHelper.OpeatorType.Contains, false));
               //strConditionsOrderBy.Add(CAMLHelper.GetCAMLFieldRefCondition("Description".ToString(), CAMLHelper.DataType.Text, SearchQuery.ToString(), CAMLHelper.OpeatorType.Contains, false));

               string FinalConditionForDoc = CAMLHelper.MergeCAMLConditions(strConditionsSearchFromDoc, CAMLHelper.MergeType.And, true);
               paramHelp.CAMLQuery = "<View Scope='RecursiveAll'><Query>" + FinalConditionForDoc + "</Query><RowLimit>" + newRowLimitForDoc + "</RowLimit></View>";

               Microsoft.SharePoint.Client.ListItemCollectionPosition testforDoc = new ListItemCollectionPosition();
               testforDoc.PagingInfo = "Paged=TRUE&" + PageInfo;


               SP.CamlQuery queryforDoc = new SP.CamlQuery();
               queryforDoc.ViewXml = paramHelp.CAMLQuery;
               queryforDoc.ListItemCollectionPosition = testforDoc;
               var DocItems = listOfDoc.GetItems(queryforDoc);

               clientContext.Load(DocItems);
               clientContext.ExecuteQuery();
               itemPosition = DocItems.ListItemCollectionPosition;
               DataTable dtItmForDoc = new DataTable();
               if (itemPosition != null)
               {
                   str = itemPosition.PagingInfo.Substring(itemPosition.PagingInfo.IndexOf('&') + 1);
               }


               clientContext.ExecuteQuery();
               dtItmForDoc = ConvertListCollInDatatable(DocItems);
               if (dtItmForDoc != null && dtItmForDoc.Rows.Count > 0)
               {
                   foreach (DataRow drOfVid in dtItmForDoc.Rows)
                   {
                       dt.Rows.Add(drOfVid["ID"], drOfVid["Title"], drOfVid["FileLeafRef"], drOfVid["Title"], "Document","", "");
                   }
                   foreach (DataRow dr in dt.Rows)
                   {
                       dr["PageInfo"] = str;
                   }
               }
           }
           #endregion
           #region "For Article List"

           int newRowLimitForArt = 0;
           if (dt.Rows.Count < Convert.ToInt32(RowLimit))
           {
               newRowLimitForArt = Convert.ToInt32(RowLimit) - dt.Rows.Count;


               var listOfArt = w.Lists.GetByTitle("LearningMaterialArticlesList");
               clientContext.Load(listOfArt);

               List<string> strConditionsSearchFromArt = new List<string>();
               List<string> strCondFin = new List<string>();
               List<string> strCondForDesc = new List<string>();


              
               strConditionsSearchFromArt.Add(CAMLHelper.GetCAMLFieldRefCondition("Title".ToString(), CAMLHelper.DataType.Text, SearchQuery.ToString(), CAMLHelper.OpeatorType.Contains, false));
               strConditionsSearchFromArt.Add(CAMLHelper.GetCAMLFieldRefCondition("ArticleBody".ToString(), CAMLHelper.DataType.Text, SearchQuery.ToString(), CAMLHelper.OpeatorType.Contains, false));
               string FinalConditionForArt=CAMLHelper.MergeCAMLConditions(strConditionsSearchFromArt, CAMLHelper.MergeType.Or, true);
              
               paramHelp.CAMLQuery = "<View Scope='RecursiveAll'><Query>" + FinalConditionForArt + "</Query><RowLimit>" + newRowLimitForArt + "</RowLimit></View>";

               Microsoft.SharePoint.Client.ListItemCollectionPosition testforArt = new ListItemCollectionPosition();
               testforArt.PagingInfo = "Paged=TRUE&" + PageInfo;


               SP.CamlQuery queryforArt = new SP.CamlQuery();
               queryforArt.ViewXml = paramHelp.CAMLQuery;
               queryforArt.ListItemCollectionPosition = testforArt;
               var ArtItems = listOfArt.GetItems(queryforArt);

               clientContext.Load(ArtItems);
               clientContext.ExecuteQuery();
               itemPosition = ArtItems.ListItemCollectionPosition;
               DataTable dtItmForArt = new DataTable();
               if (itemPosition != null)
               {
                   str = itemPosition.PagingInfo.Substring(itemPosition.PagingInfo.IndexOf('&') + 1);
               }


               clientContext.ExecuteQuery();
               dtItmForArt = ConvertListCollInDatatable(ArtItems);
               if (dtItmForArt != null && dtItmForArt.Rows.Count > 0)
               {
                   foreach (DataRow drOfVid in dtItmForArt.Rows)
                   {
                       dt.Rows.Add(drOfVid["ID"], drOfVid["Title"], drOfVid["ArticleBody"], drOfVid["Title"], "Article", "", "");
                   }
                   foreach (DataRow dr in dt.Rows)
                   {
                       dr["PageInfo"] = str;
                   }
               }
           }
           #endregion

           return dt;
       }
       
       
       #endregion


       public List<GetAllDocRes> DownloadDocumentByID(string ID)
       {

           MobAppSer.ParameterHelperCommon paramHelp = new MobAppSer.ParameterHelperCommon();
           paramHelp.URL = SiteUrl;
           paramHelp.UserID = UserName;
           paramHelp.Password = Password;
           paramHelp.ListName = "UserExtendedProperties";
           bool isValidate = MobAppSer.SPClientHelper.ValidateLogin(paramHelp);

           ClientContext clientContext = MobAppSer.SPClientHelper.ConnectToSite(paramHelp);

           Web w = clientContext.Web;

           clientContext.Load(w);

           string LibraryName = "Test Doc";
           var list = clientContext.Web.Lists.GetByTitle(LibraryName);

           clientContext.Load(list, l => l.RootFolder.ServerRelativeUrl);
           clientContext.ExecuteQuery();

           List<string> strConditionsOrderBy = new List<string>();
           strConditionsOrderBy.Add(CAMLHelper.GetCAMLFieldRefCondition("ID".ToString(), CAMLHelper.DataType.Text, ID.ToString(), CAMLHelper.OpeatorType.Equal, false));

           string FinalCondition = CAMLHelper.MergeCAMLConditions(strConditionsOrderBy, CAMLHelper.MergeType.And, true);
           paramHelp.CAMLQuery = "<View><Query>" + FinalCondition + "</View></Query>";

           SP.CamlQuery query = new SP.CamlQuery();
           query.ViewXml = paramHelp.CAMLQuery;


           var items = list.GetItems(query);
           clientContext.Load(items, l => l.IncludeWithDefaultProperties(i => i.Folder, i => i.File, i => i.DisplayName));
           clientContext.ExecuteQuery();

           // Url for first item
           var url = SiteUrl + "/" + LibraryName + "/" + items[0]["Title"];
           List<GetAllDocRes> res = new List<GetAllDocRes>();
           string path = null;
           string casestring = "";
           foreach (ListItem li in items)
           {
               GetAllDocRes item = new GetAllDocRes();
               var fileRef = li.File.ServerRelativeUrl;
               item.ID = li.Id.ToString();
               item.Title = li.File.Title;

               Microsoft.SharePoint.Client.FileInformation fileInfo = Microsoft.SharePoint.Client.File.OpenBinaryDirect(clientContext, fileRef);
               clientContext.ExecuteQuery();

               string[] fileext = li.File.Name.Split('.');
               int a = fileext.Length;

               // Get the extension of File to determine the file type
                casestring = "";
                casestring = fileext[a - 1].ToString();
                Stream fileStream = null;
                try
                {
                    using (fileStream = new System.IO.FileStream(@"C:\MobAppSer-10-4-17\DownloadedDoc\testStream." + casestring, System.IO.FileMode.Create))
                    {

                        fileInfo.Stream.CopyTo(fileStream);

                    }
                }

                finally
                {
                    if (fileStream != null)
                        fileStream.Dispose();
                }  

                path = @"C:\MobAppSer-10-4-17\DownloadedDoc\testStream." + casestring;
                //byte[] buffer = new byte[16 * 1024];
                //using (MemoryStream ms = new MemoryStream())
                //{

                //    fileInfo.Stream.CopyTo(ms);
                //    buffer = ms.ToArray();

                //}
                           
               byte[] arr = new byte[256];
               fileInfo.Stream.ReadByte();


               byte[] buffer = new byte[16 * 1024];
               using (MemoryStream ms = new MemoryStream())
               {

                   fileInfo.Stream.CopyTo(ms);
                   buffer = ms.ToArray();

               }
               string doc = Convert.ToBase64String(buffer);
               item.DocByteArr = doc;


               res.Add(item);

           }

           System.IO.FileInfo file = new System.IO.FileInfo(path);
           try
           {
               if (file.Exists)
               {
                   
                   System.Web.HttpContext.Current.Response.Clear();
                   System.Web.HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment; filename=" + file.Name);
                   System.Web.HttpContext.Current.Response.AddHeader("Content-Length", file.Length.ToString());
                   //System.Web.HttpContext.Current.Response.ContentType = "application/octet-stream";
                   System.Web.HttpContext.Current.Response.ContentType = MimeTypes.MimeTypeMap.GetMimeType(casestring);
                   

                   System.Web.HttpContext.Current.Response.WriteFile(file.FullName, 0, file.Length);
                   
                   System.Web.HttpContext.Current.Response.End();
                   System.Web.HttpContext.Current.Response.Close();
                   System.IO.FileInfo fi = new System.IO.FileInfo(path);
                  fi.Delete();
               }
               else
               {
                   throw new Exception("File not found");
               }
           }
           catch (Exception ex)
           {
               System.Web.HttpContext.Current.Response.ContentType = "text/plain";
               System.Web.HttpContext.Current.Response.Write(ex.Message);
               System.Web.HttpContext.Current.Response.End();
               System.Web.HttpContext.Current.Response.Close();
           }
           finally
           {
               
           }
          
           return res;
       }
       private static void CopyStream(Stream source, MemoryStream destination)
       {

           byte[] buffer = new byte[32768];

           int bytesRead;

           do
           {

               bytesRead = source.Read(buffer, 0, buffer.Length);
               destination.Write(buffer, 0, bytesRead);
           } while (bytesRead != 0);

       }
       private Stream DownloadFile(string FilePath,FileInfo info )
       {
           WebOperationContext.Current.OutgoingResponse.ContentType =  MimeTypeMap.GetMimeType(info.Extension) != null ? MimeTypeMap.GetMimeType(info.Extension) : "application/octet-stream";
           FileStream f = new FileStream(FilePath, FileMode.Open);
           int length = (int)f.Length;

           WebOperationContext.Current.OutgoingResponse.ContentLength = length;
           WebOperationContext.Current.OutgoingResponse.Headers.Add("Content-disposition", "attachment; filename="+info.Name);
           byte[] buffer = new byte[info.Length];
           int sum = 0;
           int count;
           while ((count = f.Read(buffer, sum, length - sum)) > 0)
           {
               sum += count;
           }
          
          f.Close();

          
           return new MemoryStream(buffer); 
           
       }


       #region "Testing"


       public DataTable TestForReadingCustomBAL()
       {
           MobAppSer.ParameterHelperCommon paramHelp = new MobAppSer.ParameterHelperCommon();
           paramHelp.URL = SiteUrl;
           paramHelp.UserID = UserName;
           paramHelp.Password = Password;
           paramHelp.ListName = "UserExtendedProperties";
           bool isValidate = MobAppSer.SPClientHelper.ValidateLogin(paramHelp);

           ClientContext clientContext = MobAppSer.SPClientHelper.ConnectToSite(paramHelp);

           Web w = clientContext.Web;
         
           clientContext.Load(w);

           string hashValue = null;
           var list = w.Lists.GetByTitle("Quiz1");
           clientContext.Load(list);
           clientContext.Load(list.Fields);
           clientContext.ExecuteQuery();

           List<String> test = new List<String>();


           foreach (Field Fi in list.Fields)
           {
               if (Fi.Hidden != true && Fi.TypeAsString == "Ques")
               {
                   var ddtype = Fi.SchemaXml;
                   XDocument doc = XDocument.Parse(ddtype);
                   foreach (XElement hashElement in doc.Descendants("Value"))
                   {
                       hashValue = (string)hashElement;

                   }
                   test.Add(hashValue);
                 
               }
           }

     
           SP.CamlQuery query = new SP.CamlQuery();
           var qry = SP.CamlQuery.CreateAllFoldersQuery();
           var category = list.GetItems(query);
           clientContext.Load(category);
           clientContext.ExecuteQuery();
           DataTable dt = new DataTable();

           dt = ConvertListCollInDatatable(category);

           return dt;

        

       }


       public DataTable TestSearchInDocBAL(string Query)
       {
           MobAppSer.ParameterHelperCommon paramHelp = new MobAppSer.ParameterHelperCommon();
           paramHelp.URL = SiteUrl;
           paramHelp.UserID = UserName;
           paramHelp.Password = Password;
           paramHelp.ListName = "UserExtendedProperties";
           bool isValidate = MobAppSer.SPClientHelper.ValidateLogin(paramHelp);

           ClientContext clientContext = MobAppSer.SPClientHelper.ConnectToSite(paramHelp);

           KeywordQuery keywordQuery = new KeywordQuery(clientContext);
           keywordQuery.QueryText = "bioethic";
           SearchExecutor searchExecutor = new SearchExecutor(clientContext);
           ClientResult<ResultTableCollection> results = searchExecutor.ExecuteQuery(keywordQuery);
           clientContext.ExecuteQuery();


        //   SearchServiceApplication searchApp = SearchService.Service.SearchApplications.GetValue<SearchServiceApplication>(searchAppId);
        
           Web w = clientContext.Web;
           //var lists = clientContext.LoadQuery(w.Lists);

           clientContext.Load(w);
           //List list = w.Lists.GetByTitle(paramHelp.ListName);
           // clientContext.Load(list);

           var list = w.Lists.GetByTitle("Contacts 1000");
           clientContext.Load(list);

           List<string> strConditionsOrderBy = new List<string>();
           //   strConditionsOrderBy.Add(CAMLHelper.GetCAMLFieldRefCondition("ContentType".ToString(), CAMLHelper.DataType.Text, "Discussion".ToString(), CAMLHelper.OpeatorType.Equal, false));

           strConditionsOrderBy.Add(CAMLHelper.GetCAMLFieldRefCondition("Active".ToString(), CAMLHelper.DataType.Text, "1".ToString(), CAMLHelper.OpeatorType.Equal, false));

           string FinalCondition = CAMLHelper.MergeCAMLConditions(strConditionsOrderBy, CAMLHelper.MergeType.And, true);
           paramHelp.CAMLQuery = "<View Scope='RecursiveAll'>" + FinalCondition + "</View>";

           Microsoft.SharePoint.Client.ListItemCollectionPosition test = new ListItemCollectionPosition();
          // test.PagingInfo = "Paged=TRUE&" + PageInfo;

           SP.CamlQuery query = new SP.CamlQuery();
           query.ViewXml = paramHelp.CAMLQuery;
           query.ListItemCollectionPosition = test;
           ListItemCollection discussionItems = list.GetItems(query);

           clientContext.Load(discussionItems);



           clientContext.ExecuteQuery();


           itemPosition = discussionItems.ListItemCollectionPosition;
  
           DataTable dt = new DataTable();
           string str = itemPosition.PagingInfo.Substring(itemPosition.PagingInfo.IndexOf('&') + 1);

           clientContext.ExecuteQuery();
           dt = ConvertListCollInDatatable(discussionItems);
           dt.Columns.Add("PageInfo");
           foreach (DataRow dr in dt.Rows)
           {
               dr["PageInfo"] = str;
           }
           return dt;
       }



       public DataTable TestBAL(string RowLimit,string PageInfo)
       {
           MobAppSer.ParameterHelperCommon paramHelp = new MobAppSer.ParameterHelperCommon();
           paramHelp.URL = SiteUrl;
           paramHelp.UserID = UserName;
           paramHelp.Password = Password;
           paramHelp.ListName = "UserExtendedProperties";
           bool isValidate = MobAppSer.SPClientHelper.ValidateLogin(paramHelp);

           ClientContext clientContext = MobAppSer.SPClientHelper.ConnectToSite(paramHelp);

           Web w = clientContext.Web;
           //var lists = clientContext.LoadQuery(w.Lists);

           clientContext.Load(w);
           //List list = w.Lists.GetByTitle(paramHelp.ListName);
           // clientContext.Load(list);

           var list = w.Lists.GetByTitle("Contacts 1000");
           clientContext.Load(list);

           List<string> strConditionsOrderBy = new List<string>();
           //   strConditionsOrderBy.Add(CAMLHelper.GetCAMLFieldRefCondition("ContentType".ToString(), CAMLHelper.DataType.Text, "Discussion".ToString(), CAMLHelper.OpeatorType.Equal, false));

           strConditionsOrderBy.Add(CAMLHelper.GetCAMLFieldRefCondition("Active".ToString(), CAMLHelper.DataType.Text, "1".ToString(), CAMLHelper.OpeatorType.Equal, false));

           string FinalCondition = CAMLHelper.MergeCAMLConditions(strConditionsOrderBy, CAMLHelper.MergeType.And, true);
           paramHelp.CAMLQuery = "<View Scope='RecursiveAll'>" + FinalCondition + "<RowLimit>"+RowLimit+"</RowLimit></View>";

           Microsoft.SharePoint.Client.ListItemCollectionPosition test = new ListItemCollectionPosition();
           test.PagingInfo = "Paged=TRUE&" + PageInfo;

           SP.CamlQuery query = new SP.CamlQuery();
           query.ViewXml = paramHelp.CAMLQuery;
           query.ListItemCollectionPosition = test;
           ListItemCollection discussionItems = list.GetItems(query);

           clientContext.Load(discussionItems);



           clientContext.ExecuteQuery();


           itemPosition = discussionItems.ListItemCollectionPosition;
  
           DataTable dt = new DataTable();
           string str = itemPosition.PagingInfo.Substring(itemPosition.PagingInfo.IndexOf('&') + 1);

           clientContext.ExecuteQuery();
           dt = ConvertListCollInDatatable(discussionItems);
           dt.Columns.Add("PageInfo");
           foreach (DataRow dr in dt.Rows)
           {
               dr["PageInfo"] = str;
           }
           return dt;
       }


       public List<GetAllDocRes> GetDocumentBAL()
       {
           
           MobAppSer.ParameterHelperCommon paramHelp = new MobAppSer.ParameterHelperCommon();
           paramHelp.URL = SiteUrl;
           paramHelp.UserID = UserName;
           paramHelp.Password = Password;
           paramHelp.ListName = "UserExtendedProperties";
           bool isValidate = MobAppSer.SPClientHelper.ValidateLogin(paramHelp);

           ClientContext clientContext = MobAppSer.SPClientHelper.ConnectToSite(paramHelp);

           Web w = clientContext.Web;
          
           clientContext.Load(w);
           
           string LibraryName = "Test Doc";
           var list = clientContext.Web.Lists.GetByTitle(LibraryName);

      

        clientContext.Load(list, l => l.RootFolder.ServerRelativeUrl);
        clientContext.ExecuteQuery();

        
        var camlQuery = @"<View Scope='All'><Query></Query></View>";
        SP.CamlQuery query = new SP.CamlQuery();
        query.ViewXml = camlQuery;
        var items = list.GetItems(query);
        clientContext.Load(items, l => l.IncludeWithDefaultProperties(i => i.Folder, i => i.File, i => i.DisplayName));
        clientContext.ExecuteQuery();

       // Url for first item
        var url = SiteUrl + "/" + LibraryName + "/" + items[0]["Title"];
        List<GetAllDocRes> res = new List<GetAllDocRes>();
        foreach (ListItem li in items)
        {
            GetAllDocRes item = new GetAllDocRes();
            var fileRef = li.File.ServerRelativeUrl;
            item.ID = li.Id.ToString();
            item.Title = li.File.Title;
           // string uriPath = @"http:\\v2013dev3:41124\Test%20Doc\abc.txt";
            
            var fileInfo = Microsoft.SharePoint.Client.File.OpenBinaryDirect(clientContext, fileRef);
        //    var fileName = Path.Combine("C:\\Testing", (string)li.File.Name);
          //  byte[] data = System.IO.File.ReadAllBytes(uriPath);

            byte[] arr=new byte[256];
            fileInfo.Stream.ReadByte();

            ////using (var fileStream = System.IO.File.Create(fileName))
            ////{
            ////  //  byte[] bytArr = fileInfo.Stream;
            //// //   fileInfo.Stream.CopyTo(fileStream);
            ////}

            byte[] buffer = new byte[16 * 1024];
            using (MemoryStream ms = new MemoryStream())
            {
                
                fileInfo.Stream.CopyTo(ms);
                buffer= ms.ToArray();
               
            }
            string doc = Convert.ToBase64String(buffer);
            item.DocByteArr = doc;


            res.Add(item);

        }
        //string s2 = "";
        //foreach (byte b in buffer)
        //{
        //    s2 += b.ToString();
        //}

       
       // System.IO.File.WriteAllBytes("C:\\Testing\\Foo.txt", buffer); // Requires System.IO
        //return buffer;
       // return doc;

        DocX letter;

        Uri filename = new Uri("http://v2013dev3:41124/Test%20Doc/abc.txt".ToString());
        string server = filename.AbsoluteUri.Replace(filename.AbsolutePath, "");
        string serverrelative = filename.AbsolutePath;

       // Microsoft.SharePoint.Client.ClientContext clientContext2 = new Microsoft.SharePoint.Client.ClientContext(server);
        Microsoft.SharePoint.Client.FileInformation f = Microsoft.SharePoint.Client.File.OpenBinaryDirect(clientContext, serverrelative);

        clientContext.ExecuteQuery();

        using (var fileStream = new System.IO.FileStream(@"C:\MobAppSer-10-4-17\DownloadedDoc\testStream.txt", System.IO.FileMode.Create))
        {
       
            f.Stream.CopyTo(fileStream);
            
        }

        string path = @"C:\MobAppSer-10-4-17\DownloadedDoc\testStream.txt";// fileNameTemplate;//outputFileName;
        string path2 = @"C:\MobAppSer-10-4-17\DownloadedDoc\testStream2.txt";// fileNameTemplate;//outputFileName;

        System.IO.FileInfo file = new System.IO.FileInfo(path);
        if (file.Exists)
        {
            System.Web.HttpContext.Current.Response.Clear();
            System.Web.HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment; filename=" + file.Name);
            System.Web.HttpContext.Current.Response.AddHeader("Content-Length", file.Length.ToString());
            System.Web.HttpContext.Current.Response.ContentType = "application/octet-stream";
            System.Web.HttpContext.Current.Response.WriteFile(path);

            System.Web.HttpContext.Current.Response.End();
            System.Web.HttpContext.Current.Response.Close();
            System.IO.FileInfo fi = new System.IO.FileInfo(path);
            fi.Delete();
        }
       




        return res;
       }

       public DataTable SeacrhingBAL(string SearchQuery)
       {
           MobAppSer.ParameterHelperCommon paramHelp = new MobAppSer.ParameterHelperCommon();
           paramHelp.URL = SiteUrl;
           paramHelp.UserID = UserName;
           paramHelp.Password = Password;
           paramHelp.ListName = "UserExtendedProperties";
           bool isValidate = MobAppSer.SPClientHelper.ValidateLogin(paramHelp);

           ClientContext clientContext = MobAppSer.SPClientHelper.ConnectToSite(paramHelp);

           Web w = clientContext.Web;
           clientContext.Load(w);


           KeywordQuery keywordQuery = new KeywordQuery(clientContext);
           keywordQuery.QueryText = SearchQuery;
           SearchExecutor searchExecutor = new SearchExecutor(clientContext);
           ClientResult<ResultTableCollection> results = searchExecutor.ExecuteQuery(keywordQuery);
           clientContext.ExecuteQuery();

           string TEST="";
           foreach (var result in results.Value[0].ResultRows)
           {
             TEST= result["Title"] + " Size:" + result["ID"];
           }


           DataTable dt = new DataTable();
           return dt;
       }


      
       #endregion 





    }

}
