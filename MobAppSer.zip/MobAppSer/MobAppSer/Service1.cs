﻿using Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System;
using System.Collections.Generic;
using Microsoft.SharePoint.Client;
using System.Data;
using System.Collections;
using Microsoft.SharePoint.Client.Taxonomy;
using System.IO;
using System.Text;
using SP = Microsoft.SharePoint.Client;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace MobAppService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in both code and config file together.
    public class Service1 : IService1
    {
        public List<Users> GetAllUsers()
        {
            try
            {

                ClientContext clientContext = new ClientContext("http://v2013dev3:41124/");
                SP.List oList = clientContext.Web.Lists.GetByTitle("UserExtendedProperties");

                clientContext.AuthenticationMode = ClientAuthenticationMode.FormsAuthentication;
                clientContext.FormsAuthenticationLoginInfo = new
                                    FormsAuthenticationLoginInfo("farah", "@kutest");

                Web w = clientContext.Web;
                var lists = clientContext.LoadQuery(w.Lists);

                clientContext.Load(w);
                List list = w.Lists.GetByTitle("UserExtendedProperties");
                clientContext.Load(list);

                CamlQuery camlQuery = new CamlQuery();
                camlQuery.ViewXml = "<View><Query><FieldRef Name='Title'/></Query></View>";

                //-----------------------
                ListItemCollection ListColletion = list.GetItems(camlQuery);
                clientContext.Load(list);
                clientContext.Load(ListColletion);

                clientContext.ExecuteQuery();
                List<Users> data = new List<Users>();
                Users us = new Users();
                foreach (ListItem oListItem in ListColletion)
                {
                    us.UserID = oListItem["UserID"].ToString();
                    us.EmailID = oListItem["EmailID"].ToString();
                    us.MobileNumber = oListItem["MobileNumber"].ToString();
                    us.UserType = oListItem["UserType"].ToString();
                    data.Add(us);
                }

                string sJSONResponse = JsonConvert.SerializeObject(data);
                return data;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

       
    }
}
