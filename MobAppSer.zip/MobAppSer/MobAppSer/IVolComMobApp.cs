﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.ServiceModel.Web;
using System.Text;

namespace MobAppSer
{
     [ServiceContract]
     
    public interface IBioEthicMobApp
    {


         [OperationContract]
         [WebGet(UriTemplate = "/Users/LoginUser?EmailID={EmailID}&Password={Password}",
                 RequestFormat = WebMessageFormat.Json,
                 ResponseFormat = WebMessageFormat.Json,
                 BodyStyle = WebMessageBodyStyle.Bare)]
         Authentication Authentication(string EmailID, string Password);

         //[OperationContract]
         //[WebGet(UriTemplate = "/Users/RegisterUser?EmailID={EmailID}&Password={Password}&FullName={FullName}"+
         //    "&MobileNumber={MobileNumber}&Extension={Extension}&UserType={UserType}&AnnonymusName={AnnonymusName}"+
         //    "&AboutMe={AboutMe}&Designation={Designation}",
         //        RequestFormat = WebMessageFormat.Json,
         //        ResponseFormat = WebMessageFormat.Json,
         //        BodyStyle = WebMessageBodyStyle.Bare)]
         //Authentication Registration(string EmailID, string Password, string FullName, string MobileNumber, string Extension,
         //    string UserType, string AnnonymusName, string AboutMe, string Designation);

       

         [OperationContract]
         [WebInvoke(UriTemplate = "/Users/RegisterUser",
                 RequestFormat = WebMessageFormat.Json,
                 ResponseFormat = WebMessageFormat.Json, Method = "POST",
                 BodyStyle = WebMessageBodyStyle.Bare)]
         Authentication Registration(UserToAdd User);


         [OperationContract]
         [WebGet(UriTemplate = "/GetUserByUserName?UserName={UserName}",
                 RequestFormat = WebMessageFormat.Json,
                 ResponseFormat = WebMessageFormat.Json,
                 BodyStyle = WebMessageBodyStyle.Bare)]
         List<UserByUserName> GetUserByUserName(string UserName);


         [OperationContract]
         [WebInvoke(UriTemplate = "/Users/UpdateProfile",
                 RequestFormat = WebMessageFormat.Json,
                 ResponseFormat = WebMessageFormat.Json, Method = "POST",
                 BodyStyle = WebMessageBodyStyle.Bare)]
         UpdateProfileStatus UpdateProfile(UpdateUserInputInfo updInfo);


         [OperationContract]
         [WebInvoke(UriTemplate = "/Users/ChangePassword",
         RequestFormat = WebMessageFormat.Json,
                 ResponseFormat = WebMessageFormat.Json, Method = "POST",
                 BodyStyle = WebMessageBodyStyle.Bare)]
         ChangePasswordStatus ChangePassword(ChangePasswordInputs obj);

         [OperationContract]
         [WebGet(UriTemplate = "/Users/ForgetPassword?EmailID={EmailID}",
         RequestFormat = WebMessageFormat.Json,
                 ResponseFormat = WebMessageFormat.Json,
                 BodyStyle = WebMessageBodyStyle.Bare)]
         ForgetPasswordStatus ForgetPassword(string EmailID);

         [OperationContract]
         [WebGet(UriTemplate = "/Users/GetAllUserType",
         RequestFormat = WebMessageFormat.Json,
                 ResponseFormat = WebMessageFormat.Json,
                 BodyStyle = WebMessageBodyStyle.Bare)]
         ResponseOfGetAllUserType GetAllUserType();

         //[OperationContract]
         //[WebGet(UriTemplate = "/Users/CheckPasswordPolicy?Password={Password}",
         //RequestFormat = WebMessageFormat.Json,
         //        ResponseFormat = WebMessageFormat.Json,
         //        BodyStyle = WebMessageBodyStyle.Bare)]
         //DataTable CheckPasswordPolicy(string Password);


         [OperationContract]
         [WebGet(UriTemplate = "/Users/CheckAnnonymousName?Name={Name}",
         RequestFormat = WebMessageFormat.Json,
                 ResponseFormat = WebMessageFormat.Json,
                 BodyStyle = WebMessageBodyStyle.Bare)]
         CheckAnnonymous CheckAnnonymousName(string Name);


         [OperationContract]
         [WebGet(UriTemplate = "/DiscussionBoard/GetAllDiscussions?CategoryID={CategoryID}&EmailID={EmailID}&PageSize={PageSize}&PageInfo={PageInfo}&StartDate={StartDate}&EndDate={EndDate}",
         RequestFormat = WebMessageFormat.Json,
                 ResponseFormat = WebMessageFormat.Json,
                 BodyStyle = WebMessageBodyStyle.Bare)]
         ResponseOfGetAllDiscussion GetAllDiscussions(string CategoryID,string EmailID,string PageSize, string PageInfo,string StartDate, string EndDate);

         [OperationContract]
         [WebGet(UriTemplate = "/DiscussionBoard/GetDiscussionByID?DiscussionID={DiscussionID}&EmailID={EmailID}",
         RequestFormat = WebMessageFormat.Json,
                 ResponseFormat = WebMessageFormat.Json,
                 BodyStyle = WebMessageBodyStyle.Bare)]
         ResponseOfGetDiscussionByID GetDiscussionByID(string DiscussionID, string EmailID);

         [OperationContract]
         [WebGet(UriTemplate = "/DiscussionBoard/GetRepliesOfDiscussion?DiscussionID={DiscussionID}",
         RequestFormat = WebMessageFormat.Json,
                 ResponseFormat = WebMessageFormat.Json,
                 BodyStyle = WebMessageBodyStyle.Bare)]
         ResponseOfGetAllReplies GetRepliesOfDiscussion(string DiscussionID);


         [OperationContract]
         [WebInvoke(UriTemplate = "/DiscussionBoard/CreateNewDiscussion",
         RequestFormat = WebMessageFormat.Json,
                 ResponseFormat = WebMessageFormat.Json, Method = "POST",
                 BodyStyle = WebMessageBodyStyle.Bare)]
         GeneralStatus CreateNewDiscussion(CreateNewDiscussionDetails obj);
        // GeneralStatus CreateNewDiscussion(string Topic, string Body, string StartedBy, string IdOfCategory, string[] ImageByte);


         [OperationContract]
         [WebInvoke(UriTemplate = "/DiscussionBoard/ReplyOnDiscussion",
         RequestFormat = WebMessageFormat.Json,
                 ResponseFormat = WebMessageFormat.Json, Method = "POST",
                 BodyStyle = WebMessageBodyStyle.Bare)]
         GeneralStatus ReplyOnDiscussion(CreateNewReplyDetails obj);


         [OperationContract]
       //  [WebInvoke(UriTemplate = "/WriteToUs/CreateFeedBack?EmailID={EmailID}&Subject={Subject}&Comments={Comments}&ImageByte={ImageByte}",
         [WebInvoke(UriTemplate = "/WriteToUs/CreateFeedBack",
         RequestFormat = WebMessageFormat.Json,
                 ResponseFormat = WebMessageFormat.Json, Method = "POST",
                 BodyStyle = WebMessageBodyStyle.Bare)]
     //    ResponseOfAddFeedBack CreateFeedBack(string EmailID, string Subject, string Comments, string[] ImageByte);
       ResponseOfAddFeedBack CreateFeedBack(CreateFeedBackDetails obj);


         [OperationContract]
         [WebGet(UriTemplate = "/Favrourite/GetAllFavrourites?EmailID={EmailID}&PageSize={PageSize}&PageInfo={PageInfo}",
         RequestFormat = WebMessageFormat.Json,
                 ResponseFormat = WebMessageFormat.Json,
                 BodyStyle = WebMessageBodyStyle.Bare)]
         ResponseOfGetAllFavouritesByID GetAllFavrourites(string EmailID, string PageSize, string PageInfo);

         [OperationContract]
         [WebInvoke(UriTemplate = "/Favrourite/AddToFavourite",
         RequestFormat = WebMessageFormat.Json,
                 ResponseFormat = WebMessageFormat.Json, Method = "POST",
                 BodyStyle = WebMessageBodyStyle.Bare)]
         ResponseOfAddToFavourites AddToFavourite(InputsOfAddingToFavourites obj);

         [OperationContract]
         [WebInvoke(UriTemplate = "/Favrourite/RemoveFromFavourite",
         RequestFormat = WebMessageFormat.Json,
                 ResponseFormat = WebMessageFormat.Json, Method = "POST",
                 BodyStyle = WebMessageBodyStyle.Bare)]
         ResponseOfRemovingFavourite RemoveFromFavourite(RemoveFromFavObj obj);

         [OperationContract]
         [WebGet(UriTemplate = "/Videos/GetAllVideos?EmailID={EmailID}&PageSize={PageSize}&PageInfo={PageInfo}",
         RequestFormat = WebMessageFormat.Json,
                 ResponseFormat = WebMessageFormat.Json,
                 BodyStyle = WebMessageBodyStyle.Bare)]
         ResponseOfVideoDetails GetAllVideos(string EmailID,string PageSize, string PageInfo);


         [OperationContract]
         [WebGet(UriTemplate = "/Videos/GetVideoDetailByID?VideoID={VideoID}&EmailID={EmailID}",
         RequestFormat = WebMessageFormat.Json,
                 ResponseFormat = WebMessageFormat.Json,
                 BodyStyle = WebMessageBodyStyle.Bare)]
         ResponseOfGetVideoDetailByID GetVideoDetailByID(string VideoID, string EmailID);

         [OperationContract]
         [WebGet(UriTemplate = "/Videos/GetCommentsOfVideoByID?VideoID={VideoID}",
         RequestFormat = WebMessageFormat.Json,
                 ResponseFormat = WebMessageFormat.Json,
                 BodyStyle = WebMessageBodyStyle.Bare)]
         ResponseGetCommentsOfVideoByID GetCommentsOfVideoByID(string VideoID);


         [OperationContract]
         [WebInvoke(UriTemplate = "/Videos/CommentOnVideo",
         RequestFormat = WebMessageFormat.Json,
                 ResponseFormat = WebMessageFormat.Json, Method = "POST",
                 BodyStyle = WebMessageBodyStyle.Bare)]
         GeneralStatus CommentOnVideo(CreateNewCommentOnVidInput obj);


         [OperationContract]
         [WebGet(UriTemplate = "/Category/GetAllCategoriesList",
         RequestFormat = WebMessageFormat.Json,
                 ResponseFormat = WebMessageFormat.Json,
                 BodyStyle = WebMessageBodyStyle.Bare)]
         ResponseOfGetAllCategoriesList GetAllCategoriesList();



         [OperationContract]
         [WebGet(UriTemplate = "/Testing/Test?PageSize={PageSize}&PageInfo={PageInfo}",
         RequestFormat = WebMessageFormat.Json,
                 ResponseFormat = WebMessageFormat.Json,
                 BodyStyle = WebMessageBodyStyle.Bare)]
         Res Test(string PageSize, string PageInfo);

         [OperationContract]
         [WebGet(UriTemplate = "/Testing/SearchInDoc?Query={Query}",
         RequestFormat = WebMessageFormat.Json,
                 ResponseFormat = WebMessageFormat.Json,
                 BodyStyle = WebMessageBodyStyle.Bare)]
         Res SearchInDoc(string Query);



         //[OperationContract]
         //[WebGet(UriTemplate = "/Testing/Seacrhing?SearchQuery={SearchQuery}&RowLimit={RowLimit}&PageInfo={PageInfo}",
         //RequestFormat = WebMessageFormat.Json,
         //        ResponseFormat = WebMessageFormat.Json,
         //        BodyStyle = WebMessageBodyStyle.Bare)]
         //TestSearchResponse Seacrhing(string SearchQuery, string RowLimit, string PageInfo);


         [OperationContract]
         [WebGet(UriTemplate = "/Testing/TestForReadingCustom",
         RequestFormat = WebMessageFormat.Json,
                 ResponseFormat = WebMessageFormat.Json,
                 BodyStyle = WebMessageBodyStyle.Bare)]
         TestPurpose TestForReadingCustom();

         //[OperationContract]
         //[WebGet(UriTemplate = "/Testing/GetDocument",
         //RequestFormat = WebMessageFormat.Json,
         //        ResponseFormat = WebMessageFormat.Json,
         //        BodyStyle = WebMessageBodyStyle.Bare)]
         //Res GetDocument();

         //[OperationContract]
         //[WebGet(UriTemplate = "/LearningMaterial/GetLearningMaterialByID?ID={ID}",
         //RequestFormat = WebMessageFormat.Json,
         //        ResponseFormat = WebMessageFormat.Json,
         //        BodyStyle = WebMessageBodyStyle.Bare)]
         //TestPurpose GetLearningMaterialByID(string ID);

       

         //[OperationContract]
         //[WebGet(UriTemplate = "/LearningMaterial/GetDocumentByID?ID={ID}",
         //RequestFormat = WebMessageFormat.Json,
         //        ResponseFormat = WebMessageFormat.Json,
         //        BodyStyle = WebMessageBodyStyle.Bare)]
         //ResponseOfGetAllDoc GetDocumentByID(string ID);

         /*learning material */
         [OperationContract]
         [WebGet(UriTemplate = "/LearningMaterial/GetAllTopics",
         RequestFormat = WebMessageFormat.Json,
                 ResponseFormat = WebMessageFormat.Json,
                 BodyStyle = WebMessageBodyStyle.Bare)]
         ResponseOfGetAllTopics GetAllTopics();


         [OperationContract]
         [WebGet(UriTemplate = "/LearningMaterial/GetAllDocument?RowLimit={RowLimit}&PageInfo={PageInfo}&EmailID={EmailID}",
         RequestFormat = WebMessageFormat.Json,
                 ResponseFormat = WebMessageFormat.Json,
                 BodyStyle = WebMessageBodyStyle.Bare)]
         ResponseOfGetAllDocument GetAllDocument(string RowLimit, string PageInfo, string EmailID);

         [OperationContract]
         [WebGet(UriTemplate = "/LearningMaterial/GetAllArticle?RowLimit={RowLimit}&PageInfo={PageInfo}&EmailID={EmailID}",
         RequestFormat = WebMessageFormat.Json,
                 ResponseFormat = WebMessageFormat.Json,
                 BodyStyle = WebMessageBodyStyle.Bare)]
         ResponseOfGetAllArticle GetAllArticle(string RowLimit, string PageInfo, string EmailID);


         [OperationContract]
         [WebGet(UriTemplate = "/LearningMaterial/GetQuiz?QuizID={QuizID}",
         RequestFormat = WebMessageFormat.Json,
                 ResponseFormat = WebMessageFormat.Json,
                 BodyStyle = WebMessageBodyStyle.Bare)]
         ResponseOfGetQuiz GetQuiz(string QuizID);

         [OperationContract]
         [WebInvoke(UriTemplate = "/LearningMaterial/QuizResponse",
         RequestFormat = WebMessageFormat.Json,
                 ResponseFormat = WebMessageFormat.Json, Method = "POST",
                 BodyStyle = WebMessageBodyStyle.Bare)]
         ResponseOfQuizResponse QuizResponse(InputObjForQuizResponse obj);

         [OperationContract]
         [WebGet(UriTemplate = "/LearningMaterial/GetDocumentByID?DocID={DocID}",
         RequestFormat = WebMessageFormat.Json,
                 ResponseFormat = WebMessageFormat.Json,
                 BodyStyle = WebMessageBodyStyle.Bare)]
         Stream GetDocumentByID(string DocID);

         [OperationContract]
         [WebGet(UriTemplate = "/LearningMaterial/GetArticleByID?ID={ID}",
         RequestFormat = WebMessageFormat.Json,
                 ResponseFormat = WebMessageFormat.Json,
                 BodyStyle = WebMessageBodyStyle.Bare)]
         ResponseOfGetAllArticle GetArticleByID(string ID);

         [OperationContract]
         [WebGet(UriTemplate = "/LearningMaterial/GetResultOfUser?EmailID={EmailID}",
         RequestFormat = WebMessageFormat.Json,
                 ResponseFormat = WebMessageFormat.Json,
                 BodyStyle = WebMessageBodyStyle.Bare)]
         ResponseOfGetUserResultResponse GetResultOfUser(string EmailID);


         /* learning material end*/


         //[OperationContract]
         //[WebGet(UriTemplate = "/LearningMaterial/GetDocumentByTopic?TopicID={TopicID}",
         //RequestFormat = WebMessageFormat.Json,
         //        ResponseFormat = WebMessageFormat.Json,
         //        BodyStyle = WebMessageBodyStyle.Bare)]
         //ResponseOfGetDocumentByTopicID GetDocumentByTopic(string TopicID);

         [OperationContract]
         [WebGet(UriTemplate = "/Search/SearchFromAll?SearchQuery={SearchQuery}&RowLimit={RowLimit}&PageInfo={PageInfo}",
         RequestFormat = WebMessageFormat.Json,
                 ResponseFormat = WebMessageFormat.Json,
                 BodyStyle = WebMessageBodyStyle.Bare)]
         SearchResponse SearchFromAll(string SearchQuery, string RowLimit, string PageInfo);

    }
    
    [DataContract]
    public class ResponseOfDownloadDoc
    {
        private string _StatusId;

        [DataMember(Order = 1)]
        public string StatusId
        {
            get { return _StatusId; }
            set { _StatusId = value; }
        }

       
    }


    [DataContract]
    public class Res
    {
        private string _StatusId;

        [DataMember(Order = 1)]
        public string StatusId
        {
            get { return _StatusId; }
            set { _StatusId = value; }
        }


    }

    [DataContract]
    public class ResponseOfGetVideoDetailByID
    {
        private string _StatusId;
        [DataMember(Order = 1)]
        public string StatusId
        {
            get { return _StatusId; }
            set { _StatusId = value; }
        }

        private string _Message;
        [DataMember(Order = 2)]
        public string Message
        {
            get { return _Message; }
            set { _Message = value; }
        }



        [DataMember(Order = 4)]
        public List<ResponseOfGetVideoDetailByIDList> ResponseOfGetVideoDetailByIDList { get; set; }


    }



    [DataContract]
    public class ResponseOfGetVideoDetailByIDList
    {

        private string _Url;
        private string _Thumbnail;
        private string _IsFavourite;
        private string _HeadingOfVideo;
        private string _Description;
        private string _CreatedOn;
        private string _Type;

       
        [DataMember(Order = 1)]
        public string Url
        {
            get { return _Url; }
            set { _Url = value; }
        }

       
        [DataMember(Order = 2)]
        public string Thumbnail
        {
            get { return _Thumbnail; }
            set { _Thumbnail = value; }
        }

       
        [DataMember(Order = 3)]
        public string IsFavourite
        {
            get { return _IsFavourite; }
            set { _IsFavourite = value; }
        }

        
        [DataMember(Order = 4)]
        public string HeadingOfVideo
        {
            get { return _HeadingOfVideo; }
            set { _HeadingOfVideo = value; }
        }


        [DataMember(Order = 5)]
        public string Description
        {
            get { return _Description; }
            set { _Description = value; }
        }


        [DataMember(Order = 6)]
        public string CreatedOn
        {
            get { return _CreatedOn; }
            set { _CreatedOn = value; }
        }

        [DataMember(Order = 7)]
        public string Type
        {
            get { return _Type; }
            set { _Type = value; }
        }




    }


      [DataContract]
    public class ResponseGetCommentsOfVideoByID
     {
         private string _StatusId;
         [DataMember(Order = 1)]
         public string StatusId
         {
             get { return _StatusId; }
             set { _StatusId = value; }
         }

         private string _Message;
         [DataMember(Order = 2)]
         public string Message
         {
             get { return _Message; }
             set { _Message = value; }
         }

        

         [DataMember(Order = 4)]
         public List<ResponseGetCommentsOfVideoByIDList> ResponseGetCommentsOfVideoByIDList { get; set; }
        

     }

     [DataContract]
      public class ResponseGetCommentsOfVideoByIDList
     {
         private string _CommentID;
         [DataMember(Order = 1)]
         public string CommentID
         {
             get { return _CommentID; }
             set { _CommentID = value; }
         }

         private string _Comment;
         [DataMember(Order = 2)]
         public string Comment
         {
             get { return _Comment; }
             set { _Comment = value; }
         }
         private string _CommentedBy;
         [DataMember(Order = 2)]
         public string CommentedBy
         {
             get { return _CommentedBy; }
             set { _CommentedBy = value; }
         }

         //private string _EmailID;
         //[DataMember(Order = 3)]
         //public string EmailID
         //{
         //    get { return _EmailID; }
         //    set { _EmailID = value; }
         //}

         //private string _AnnonymousName;
         //[DataMember(Order = 4)]
         //public string AnnonymousName
         //{
         //    get { return _AnnonymousName; }
         //    set { _AnnonymousName = value; }
         //}

         private string _Created;
         [DataMember(Order = 5 )]
         public string Created
         {
             get { return _Created; }
             set { _Created = value; }
         }

         


     }

     [DataContract]
     public class UpdateUserInputInfo
     {

         private string _EmailID;
         private string _FullName;
         private string _MobileNumber;
         private string _Extension;
         private string _UserType;
         private string _AnnonymusName;
         private string _AboutMe;
         private string _Designation;


         [DataMember(Order = 1)]
         public string EmailID
         {
             get { return _EmailID; }
             set { _EmailID = value; }
         }
         [DataMember(Order = 2)]
         public string FullName
         {
             get { return _FullName; }
             set { _FullName = value; }
         }

         [DataMember(Order = 3)]
         public string MobileNumber
         {
             get { return _MobileNumber; }
             set { _MobileNumber = value; }
         }

         [DataMember(Order = 4)]
         public string Extension
         {
             get { return _Extension; }
             set { _Extension = value; }
         }


         [DataMember(Order = 5)]
         public string UserType
         {
             get { return _UserType; }
             set { _UserType = value; }
         }


         [DataMember(Order = 6)]
         public string AnnonymusName
         {
             get { return _AnnonymusName; }
             set { _AnnonymusName = value; }
         }
         [DataMember(Order = 7)]
         public string AboutMe
         {
             get { return _AboutMe; }
             set { _AboutMe = value; }
         }
         [DataMember(Order = 8)]
         public string Designation
         {
             get { return _Designation; }
             set { _Designation = value; }
         }


     }


     [DataContract]
     public class SearchResponse
     {
         private string _StatusId;
         [DataMember(Order = 1)]
         public string StatusId
         {
             get { return _StatusId; }
             set { _StatusId = value; }
         }

         private string _Message;
         [DataMember(Order = 2)]
         public string Message
         {
             get { return _Message; }
             set { _Message = value; }
         }

         private string _PageInfo;
         [DataMember(Order = 3)]
         public string PageInfo
         {
             get { return _PageInfo; }
             set { _PageInfo = value; }
         }

         [DataMember(Order = 4)]
         public List<SearchResponseList> SearchResList { get; set; }
        

     }

     [DataContract]
     public class SearchResponseList
     {
         private string _ItemID;
         [DataMember(Order = 1)]
         public string ItemID
         {
             get { return _ItemID; }
             set { _ItemID = value; }
         }


         private string _Title;
         [DataMember(Order = 2)]
         public string Title
         {
             get { return _Title; }
             set { _Title = value; }
         }


         private string _Description;
         [DataMember(Order = 3)]
         public string Description
         {
             get { return _Description; }
             set { _Description = value; }
         }

         private string _Type;
         [DataMember(Order = 4)]
         public string Type
         {
             get { return _Type; }
             set { _Type = value; }
         }
         private string _Created;
         [DataMember(Order = 5)]
         public string Created
         {
             get { return _Created; }
             set { _Created = value; }
         }

         


     }


     [DataContract]
     public class TestSearchResponse
     {
         private string _ItemID;
         [DataMember(Order = 1)]
         public string ItemID
         {
             get { return _ItemID; }
             set { _ItemID = value; }
         }

         private string _Title;
         [DataMember(Order = 2)]
         public string Title
         {
             get { return _Title; }
             set { _Title = value; }
         }


         private string _Description;
         [DataMember(Order = 3)]
         public string Description
         {
             get { return _Description; }
             set { _Description = value; }
         }

         private string _Type;
         [DataMember(Order = 4)]
         public string Type
         {
             get { return _Type; }
             set { _Type = value; }
         }

         private string _PageInfo;
         [DataMember(Order = 5)]
         public string PageInfo
         {
             get { return _PageInfo; }
             set { _PageInfo = value; }
         }
        

     }


     [DataContract]
     public class RemoveFromFavObj
     {

         private string _FavouriteID;
         private string _ItemID;
         private string _EmailID;
         private string _TypeOfFavourite;


         [DataMember(Order = 1)]
         public string FavouriteID
         {
             get { return _FavouriteID; }
             set { _FavouriteID = value; }
         }
         [DataMember(Order = 2)]
         public string ItemID
         {
             get { return _ItemID; }
             set { _ItemID = value; }
         }
         [DataMember(Order = 3)]
         public string EmailID
         {
             get { return _EmailID; }
             set { _EmailID = value; }
         }
         [DataMember(Order = 4)]
         public string TypeOfFavourite
         {
             get { return _TypeOfFavourite; }
             set { _TypeOfFavourite = value; }
         }

     }

     [DataContract]
     public class ForgetPasswordStatus
     {

         private string _status;
         private string _message;


         [DataMember(Order = 1)]
         public string status
         {
             get { return _status; }
             set { _status = value; }
         }
         [DataMember(Order = 2)]
         public string message
         {
             get { return _message; }
             set { _message = value; }
         }

     }

     [DataContract]
     public class ChangePasswordInputs
     {

         private string _EmailID;
         private string _CurrentPassword;
         private string _NewPassword;
         

         [DataMember(Order = 1)]
         public string EmailID
         {
             get { return _EmailID; }
             set { _EmailID = value; }
         }
         [DataMember(Order = 2)]
         public string CurrentPassword
         {
             get { return _CurrentPassword; }
             set { _CurrentPassword = value; }
         }
        
         [DataMember(Order = 3)]
         public string NewPassword
         {
             get { return _NewPassword; }
             set { _NewPassword = value; }
         }
         
     }

     [DataContract]
     public class Authentication
     {

         private string _status;
         private string _message;
         private string _timestamp;
         private string _isWindowsUser;
         private string _isRegistered;
         
      
         [DataMember(Order = 1)]
         public string status
         {
             get { return _status; }
             set { _status = value; }
         }
         [DataMember(Order = 2)]
         public string message
         {
             get { return _message; }
             set { _message = value; }
         }
         [DataMember(Order = 3)]
         public List<UserByUserName> UserObject { get; set; }

         [DataMember(Order = 4)]
         public string timestamp
         {
             get { return _timestamp; }
             set { _timestamp = value; }
         }
         [DataMember(Order = 5)]
         public string isWindowsUser
         {
             get { return _isWindowsUser; }
             set { _isWindowsUser = value; }
         }
         [DataMember(Order = 6)]
         public string isRegistered
         {
             get { return _isRegistered; }
             set { _isRegistered = value; }
         }

        
     }

     [DataContract]
     public class UserGroups
     {

         private string _GroupName;
         [DataMember(Order = 1)]
         public string GroupName
         {
             get { return _GroupName; }
             set { _GroupName = value; }
         }
        
     }
    
     [DataContract]
     public class UpdateProfileStatus
     {

         private string _status;
         private string _message;
         

         [DataMember(Order = 1)]
         public string status
         {
             get { return _status; }
             set { _status = value; }
         }
         [DataMember(Order = 2)]
         public string message
         {
             get { return _message; }
             set { _message = value; }
         }
        
     }

     [DataContract]
     public class ChangePasswordStatus
     {

         private string _status;
         private string _message;


         [DataMember(Order = 1)]
         public string status
         {
             get { return _status; }
             set { _status = value; }
         }
         [DataMember(Order = 2)]
         public string message
         {
             get { return _message; }
             set { _message = value; }
         }

     }

     [DataContract]
     public class Users
     {

         private string _UserID;
         private string _EmailID;
         private string _MobileNumber;
         private string _UserType;



         [DataMember(Order = 1)]
         public string UserID
         {
             get { return _UserID; }
             set { _UserID = value; }
         }
         [DataMember(Order = 2)]
         public string EmailID
         {
             get { return _EmailID; }
             set { _EmailID = value; }
         }
         [DataMember(Order = 3)]
         public string MobileNumber
         {
             get { return _MobileNumber; }
             set { _MobileNumber = value; }
         }
         [DataMember(Order = 4)]
         public string UserType
         {
             get { return _UserType; }
             set { _UserType = value; }
         }



     }
     [DataContract]
     public class UserToAdd
     {
         
         [DataMember(Order = 1)]
         public string EmailID { get; set; }
         [DataMember(Order = 2)]
         public string Password { get; set; }
         [DataMember(Order = 3)]
         public string FullName { get; set; }
         [DataMember(Order = 4)]
         public string MobileNumber { get; set; }
         [DataMember(Order = 5)]
         public string Extension { get; set; }
         [DataMember(Order = 6)]
         public string UserType { get; set; }
         [DataMember(Order = 7)]
         public string AnnonymusName { get; set; }
          [DataMember(Order = 8)]
         public string AboutMe { get; set; }
          [DataMember(Order = 9)]
         public string Designation { get; set; }
     }

     [DataContract]
     public class UserByUserName
     {

         private string _UserID;
         private string _EmailID;
         private string _MobileNumber;
         private string _UserType;
         private string _UserName;
         private string _FullName;
         private string _Designation;
         private string _ExtensionNumber;
         private string _AboutMe;
         private string _AnnonymusName;
         private string _hasGivenPostQuiz;
         private string _hasGivenPreQuiz;
         private string _postQuizEstimatedDate;
         private string _GroupName;



         [DataMember(Order = 1)]
         public string UserID
         {
             get { return _UserID; }
             set { _UserID = value; }
         }
         [DataMember(Order =4)]
         public string EmailID
         {
             get { return _EmailID; }
             set { _EmailID = value; }
         }
         [DataMember(Order = 5)]
         public string MobileNumber
         {
             get { return _MobileNumber; }
             set { _MobileNumber = value; }
         }
         [DataMember(Order = 8)]
         public string UserType
         {
             get { return _UserType; }
             set { _UserType = value; }
         }
         [DataMember(Order = 3)]
         public string UserName
         {
             get { return _UserName; }
             set { _UserName = value; }
         }
         [DataMember(Order = 2)]
         public string FullName
         {
             get { return _FullName; }
             set { _FullName = value; }
         }
         [DataMember(Order = 7)]
         public string Designation
         {
             get { return _Designation; }
             set { _Designation = value; }
         }
         [DataMember(Order = 6)]
         public string ExtensionNumber
         {
             get { return _ExtensionNumber; }
             set { _ExtensionNumber = value; }
         }
         [DataMember(Order = 8)]
         public string AboutMe
         {
             get { return _AboutMe; }
             set { _AboutMe = value; }
         }

         [DataMember(Order = 9)]
         public string AnnonymusName
         {
             get { return _AnnonymusName; }
             set { _AnnonymusName = value; }
         }

         [DataMember(Order = 10)]
         public string hasGivenPreQuiz
         {
             get { return _hasGivenPreQuiz; }
             set { _hasGivenPreQuiz = value; }
         }

         [DataMember(Order = 11)]
         public string hasGivenPostQuiz
         {
             get { return _hasGivenPostQuiz; }
             set { _hasGivenPostQuiz = value; }
         }

         [DataMember(Order = 12)]
         public string postQuizEstimatedDate
         {
             get { return _postQuizEstimatedDate; }
             set { _postQuizEstimatedDate = value; }
         }

         [DataMember(Order = 13)]
         public string GroupName
         {
             get { return _GroupName; }
             set { _GroupName = value; }
         }  


     }

     [DataContract]
     public class UserAdd
     {

         private string _StatusDesc;
         [DataMember(Order = 1)]
         public string StatusDesc
         {
             get { return _StatusDesc; }
             set { _StatusDesc = value; }
         }
         private string _StatusCode;
         [DataMember(Order = 2)]
         public string StatusCode
         {
             get { return _StatusCode; }
             set { _StatusCode = value; }
         }
       
     }

    [DataContract]
    public class ResponseOfGetAllDiscussion
    {
        private string _statusId;
        private string _message;
        [DataMember(Order = 1)]
        public string statusId
        {
            get { return _statusId; }
            set { _statusId = value; }
        }
        [DataMember(Order = 2)]
        public string message
        {
            get { return _message; }
            set { _message = value; }
        }
        private string _PageInfo;

        [DataMember(Order = 3)]
        public string PageInfo
        {
            get { return _PageInfo; }
            set { _PageInfo = value; }
        }
        [DataMember(Order = 4)]
        public List<DiscussionBoardDetails> DiscussionDetails { get; set; }
    }

      [DataContract]
    public class ResponseOfGetDiscussionByID
    {
        private string _statusId;
        private string _message;
        [DataMember(Order = 1)]
        public string statusId
        {
            get { return _statusId; }
            set { _statusId = value; }
        }
        [DataMember(Order = 2)]
        public string message
        {
            get { return _message; }
            set { _message = value; }
        }
        [DataMember(Order = 3)]
        public DiscussionBoardDetails DiscussionDetails { get; set; }
    }
     [DataContract]
     public class DiscussionBoardDetails
     {
        
         private string _DiscussionID;
         private string _Topic;
         private string _Description;
         private string _Replies;
         private string _Date;
         private string _Category;
         private string _StartedBy;
         private string _IsFavourite;
         private string[] _ImageByte;

         [DataMember(Order = 1)]
         public string DiscussionID
         {
             get { return _DiscussionID; }
             set { _DiscussionID = value; }
         }
         [DataMember(Order = 2)]
         public string Topic
         {
             get { return _Topic; }
             set { _Topic = value; }
         }
         [DataMember(Order = 3)]
         public string Description
         {
             get { return _Description; }
             set { _Description = value; }
         }
         [DataMember(Order = 4)]
         public string Replies
         {
             get { return _Replies; }
             set { _Replies = value; }
         }
         [DataMember(Order = 5)]
         public string Date
         {
             get { return _Date; }
             set { _Date = value; }
         }

         [DataMember(Order = 6)]
         public string Category
         {
             get { return _Category; }
             set { _Category = value; }
         }
         [DataMember(Order = 7)]
         public string StartedBy
         {
             get { return _StartedBy; }
             set { _StartedBy = value; }
         }
         [DataMember(Order = 8)]
         public string IsFavourite
         {
             get { return _IsFavourite; }
             set { _IsFavourite = value; }
         }
         [DataMember(Order = 9)]
         public string[] ImageByte
         {
             get { return _ImageByte; }
             set { _ImageByte = value; }
         }
     }

     [DataContract]
     public class GeneralStatus
     {

         private string _statusId;
         private string _message;
         


         [DataMember(Order = 1)]
         public string statusId
         {
             get { return _statusId; }
             set { _statusId = value; }
         }
         [DataMember(Order = 2)]
         public string message
         {
             get { return _message; }
             set { _message = value; }
         }
         
     }
     [DataContract]
     public class MessagesDetails
     {
        
         private string _ReplyID;
         private string _ReplyMessage;
         private string _CreatedDate;
         private string _Time;
         private string _StartedBy;


         [DataMember(Order = 1)]
         public string ReplyID
         {
             get { return _ReplyID; }
             set { _ReplyID = value; }
         }
         [DataMember(Order = 2)]
         public string ReplyMessage
         {
             get { return _ReplyMessage; }
             set { _ReplyMessage = value; }
         }
         [DataMember(Order = 3)]
         public string CreatedDate
         {
             get { return _CreatedDate; }
             set { _CreatedDate = value; }
         }

         [DataMember(Order = 4)]
         public string Time
         {
             get { return _Time; }
             set { _Time = value; }
         }
         [DataMember(Order = 5)]
         public string StartedBy
         {
             get { return _StartedBy; }
             set { _StartedBy = value; }
         }
        
     }

     [DataContract]
     public class CreateNewDiscussionDetails
     {

         private string _Topic;
         private string _Body;
         private string _StartedBy;
         private string _EmailID;
         private string _IdOfCategory;
         private string[] _ImageByte;

         [DataMember(Order = 1)]
         public string Topic
         {
             get { return _Topic; }
             set { _Topic = value; }
         }
         [DataMember(Order = 2)]
         public string Body
         {
             get { return _Body; }
             set { _Body = value; }
         }
         [DataMember(Order = 3)]
         public string StartedBy
         {
             get { return _StartedBy; }
             set { _StartedBy = value; }
         }
         [DataMember(Order = 4)]
         public string EmailID
         {
             get { return _EmailID; }
             set { _EmailID = value; }
         }
         [DataMember(Order = 5)]
         public string IdOfCategory
         {
             get { return _IdOfCategory; }
             set { _IdOfCategory = value; }
         }
         [DataMember(Order = 6)]
         public string[] ImageByte
         {
             get { return _ImageByte; }
             set { _ImageByte = value; }
         }

     }

     [DataContract]
     public class CreateNewReplyDetails
     {

         private string _DiscussionID;
         private string _Body;
         private string _StartedBy;



         [DataMember(Order = 1)]
         public string DiscussionID
         {
             get { return _DiscussionID; }
             set { _DiscussionID = value; }
         }
         [DataMember(Order = 2)]
         public string Body
         {
             get { return _Body; }
             set { _Body = value; }
         }
         [DataMember(Order = 3)]
         public string StartedBy
         {
             get { return _StartedBy; }
             set { _StartedBy = value; }
         }

     }
     [DataContract]
     public class CreateNewCommentOnVidInput
     {

         private string _VideoID;
         private string _EmailID;
         private string _CommentBody;



         [DataMember(Order = 1)]
         public string VideoID
         {
             get { return _VideoID; }
             set { _VideoID = value; }
         }
         [DataMember(Order = 2)]
         public string EmailID
         {
             get { return _EmailID; }
             set { _EmailID = value; }
         }
         [DataMember(Order = 3)]
         public string CommentBody
         {
             get { return _CommentBody; }
             set { _CommentBody = value; }
         }

     }
     [DataContract]
     public class ResponseOfGetAllReplies
     {
         private string _statusId;
         private string _message;
         [DataMember(Order = 1)]
         public string statusId
         {
             get { return _statusId; }
             set { _statusId = value; }
         }
         [DataMember(Order = 2)]
         public string message
         {
             get { return _message; }
             set { _message = value; }
         }
         [DataMember(Order = 3)]
         public List<MessagesDetails> MessagesDetails { get; set; }
     }

     [DataContract]
     public class ResponseOfAddFeedBack
     {
         private string _statusId;
         private string _message;
         [DataMember(Order = 1)]
         public string statusId
         {
             get { return _statusId; }
             set { _statusId = value; }
         }
         [DataMember(Order = 2)]
         public string message
         {
             get { return _message; }
             set { _message = value; }
         }
         
     }

     [DataContract]
     public class CreateFeedBackDetails
     {
         private string _EmailID;
         private string _Subject;
         private string _Comments;
         private string[] _ImageByte;
         [DataMember(Order = 1)]
         public string EmailID
         {
             get { return _EmailID; }
             set { _EmailID = value; }
         }
         [DataMember(Order = 2)]
         public string Subject
         {
             get { return _Subject; }
             set { _Subject = value; }
         }
         [DataMember(Order = 3)]
         public string Comments
         {
             get { return _Comments; }
             set { _Comments = value; }
         }
         [DataMember(Order = 4)]
         public string[] ImageByte
         {
             get { return _ImageByte; }
             set { _ImageByte = value; }
         }

     }

     [DataContract]
     public class FavouritesDetail
     {
         private string _FavouriteID;
         private string _ItemID;
         private string _TypeOfFavourite;
         private string _Title;
         private string _Description;
         private string _Date;
         private string _Time;

         [DataMember(Order = 0)]
         public string FavouriteID
         {
             get { return _FavouriteID; }
             set { _FavouriteID = value; }
         }
         [DataMember(Order = 1)]
         public string ItemID
         {
             get { return _ItemID; }
             set { _ItemID = value; }
         }
         [DataMember(Order = 2)]
         public string TypeOfFavourite
         {
             get { return _TypeOfFavourite; }
             set { _TypeOfFavourite = value; }
         }

         [DataMember(Order = 3)]
         public string Title
         {
             get { return _Title; }
             set { _Title = value; }
         }
         [DataMember(Order = 4)]
         public string Description
         {
             get { return _Description; }
             set { _Description = value; }
         }
         [DataMember(Order = 5)]
         public string Date
         {
             get { return _Date; }
             set { _Date = value; }
         }

         [DataMember(Order = 6)]
         public string Time
         {
             get { return _Time; }
             set { _Time = value; }
         }
       
     }

    [DataContract]
    public class ResponseOfGetAllFavouritesByID
    {
        private string _StatusID;
        private string _Message;

        [DataMember(Order = 1)]
        public string StatusID
        {
            get { return _StatusID; }
            set { _StatusID = value; }
        }
        [DataMember(Order = 2)]
        public string Message
        {
            get { return _Message; }
            set { _Message = value; }
        }
        private string _PageInfo;

        [DataMember(Order = 3)]
        public string PageInfo
        {
            get { return _PageInfo; }
            set { _PageInfo = value; }
        }
        [DataMember(Order = 4)]
        public List<FavouritesDetail> FavouritesDetail { get; set; }
    }

    [DataContract]
    public class ResponseOfAddToFavourites
    {
        private string _statusId;
        private string _message;
        [DataMember(Order = 1)]
        public string statusId
        {
            get { return _statusId; }
            set { _statusId = value; }
        }
        [DataMember(Order = 2)]
        public string message
        {
            get { return _message; }
            set { _message = value; }
        }

    }


    [DataContract]
    public class InputsOfAddingToFavourites
    {
       
        private string _EmailID;
        private string _ItemID;
         private string _TypeOfFavourite;

        [DataMember(Order = 1)]
         public string EmailID
        {
            get { return _EmailID; }
            set { _EmailID = value; }
        }
        [DataMember(Order = 2)]
        public string ItemID
        {
            get { return _ItemID; }
            set { _ItemID = value; }
        }

        [DataMember(Order = 3)]
        public string TypeOfFavourite
        {
            get { return _TypeOfFavourite; }
            set { _TypeOfFavourite = value; }
        }

    }

    [DataContract]
    public class ResponseOfRemovingFavourite
    {
        private string _statusId;
        private string _message;
        [DataMember(Order = 1)]
        public string statusId
        {
            get { return _statusId; }
            set { _statusId = value; }
        }
        [DataMember(Order = 2)]
        public string message
        {
            get { return _message; }
            set { _message = value; }
        }
    }


    [DataContract]
    public class ResponseOfVideoDetails
    {
        private string _Status;
        [DataMember(Order = 1)]
        public string Status
        {
            get { return _Status; }
            set { _Status = value; }
        }
        private string _Message;
        [DataMember(Order = 2)]
        public string Message
        {
            get { return _Message; }
            set { _Message = value; }
        }
        private string _PageInfo;

        [DataMember(Order = 3)]
        public string PageInfo
        {
            get { return _PageInfo; }
            set { _PageInfo = value; }
        }
        [DataMember(Order = 4)]
        public List<NormalVideoDetails> NormalVideo { get; set; }
        [DataMember(Order = 5)]
        public List<LiveVideoDetails> LiveVideo { get; set; }

    }
    [DataContract]
    public class NormalVideoDetails
    {
       
        private string _Url;
        private string _Thumbnail;
        private string _IsFavourite;
        private string _HeadingOfVideo;
        private string _Description;
        private string _CreatedOn;
        private string _VideoID;
        [DataMember(Order = 0)]
        public string VideoID
        {
            get { return _VideoID; }
            set { _VideoID = value; }
        }

        [DataMember(Order = 1)]
        public string Url
        {
            get { return _Url; }
            set { _Url = value; }
        }
        [DataMember(Order = 2)]
        public string Thumbnail
        {
            get { return _Thumbnail; }
            set { _Thumbnail = value; }
        }
        [DataMember(Order = 3)]
        public string IsFavourite
        {
            get { return _IsFavourite; }
            set { _IsFavourite = value; }
        }
        [DataMember(Order = 4)]
        public string HeadingOfVideo
        {
            get { return _HeadingOfVideo; }
            set { _HeadingOfVideo = value; }
        }
        [DataMember(Order = 5)]
        public string Description
        {
            get { return _Description; }
            set { _Description = value; }
        }
        [DataMember(Order = 6)]
        public string CreatedOn
        {
            get { return _CreatedOn; }
            set { _CreatedOn = value; }
        }
    }
    [DataContract]
    public class LiveVideoDetails
    {
        private string _Url;
        private string _Thumbnail;
        private string _IsFavourite;
        private string _HeadingOfVideo;
        private string _Description;
        private string _CreatedOn;
        private string _VideoID;
        [DataMember(Order = 0)]
        public string VideoID
        {
            get { return _VideoID; }
            set { _VideoID = value; }
        }

        [DataMember(Order = 1)]
        public string Url
        {
            get { return _Url; }
            set { _Url = value; }
        }
        [DataMember(Order = 2)]
        public string Thumbnail
        {
            get { return _Thumbnail; }
            set { _Thumbnail = value; }
        }
        [DataMember(Order = 3)]
        public string IsFavourite
        {
            get { return _IsFavourite; }
            set { _IsFavourite = value; }
        }

        [DataMember(Order = 4)]
        public string HeadingOfVideo
        {
            get { return _HeadingOfVideo; }
            set { _HeadingOfVideo = value; }
        }
        [DataMember(Order = 5)]
        public string Description
        {
            get { return _Description; }
            set { _Description = value; }
        }
        [DataMember(Order = 6)]
        public string CreatedOn
        {
            get { return _CreatedOn; }
            set { _CreatedOn = value; }
        }
    }


    
    [DataContract]
    public class ResponseOfTest
    {
        private string _ID;
        private string _Title;
        private string _FirstName;

        [DataMember(Order = 1)]
        public string ID
        {
            get { return _ID; }
            set { _ID = value; }
        }
        [DataMember(Order = 2)]
        public string Title
        {
            get { return _Title; }
            set { _Title = value; }
        }
        [DataMember(Order = 3)]
        public string FirstName
        {
            get { return _FirstName; }
            set { _FirstName = value; }
        }

    }
    [DataContract]
    public class TestPurpose
    {
        private string _Status;

        [DataMember(Order = 1)]
        public string Status
        {
            get { return _Status; }
            set { _Status = value; }
        }

        
    }
    [DataContract]
    public class ResponseOfGetAllCategoriesList
    {
        private string _Status;
        [DataMember(Order = 1)]
        public string Status
        {
            get { return _Status; }
            set { _Status = value; }
        }
        private string _Message;
        [DataMember(Order = 2)]
        public string Message
        {
            get { return _Message; }
            set { _Message = value; }
        }
        private string _PageInfo;

        
        [DataMember(Order = 3)]
        public List<CategoryList> CategoryList { get; set; }
        

    }
  
    
    [DataContract]
    public class CategoryList
    {
        private string _ID;
        private string _Title;
       

        [DataMember(Order = 1)]
        public string ID
        {
            get { return _ID; }
            set { _ID = value; }
        }
        [DataMember(Order = 2)]
        public string Title
        {
            get { return _Title; }
            set { _Title = value; }
        }
       

    }
    [DataContract]
    public class ResponseOfGetAllTopics
    {
        private string _Status;
        /// <summary>
        /// this is test status
        /// </summary>
        [DataMember(Order = 1)]
        public string Status
        {
            get { return _Status; }
            set { _Status = value; }
        }
        private string _Message;
        [DataMember(Order = 2)]
        public string Message
        {
            get { return _Message; }
            set { _Message = value; }
        }
        private string _PageInfo;


        [DataMember(Order = 3)]
        public List<TopicList> TopicList { get; set; }


    }


  
    [DataContract]
    public class InputObjForQuizResponse
    {
        private string _QuizID;
        [DataMember(Order = 1)]
        public string QuizID
        {
            get { return _QuizID; }
            set { _QuizID = value; }
        }
        private string _AnnonymousName;
        [DataMember(Order = 2)]
        public string AnnonymousName
        {
            get { return _AnnonymousName; }
            set { _AnnonymousName = value; }
        }
        private string _EmailID;
        [DataMember(Order = 3)]
        public string EmailID
        {
            get { return _EmailID; }
            set { _EmailID = value; }
        }
        private string _DocOrArtID;
        [DataMember(Order = 4)]
        public string DocOrArtID
        {
            get { return _DocOrArtID; }
            set { _DocOrArtID = value; }
        }
        private string _TypeDocOrArt;
        [DataMember(Order = 5)]
        public string TypeDocOrArt
        {
            get { return _TypeDocOrArt; }
            set { _TypeDocOrArt = value; }
        }


        [DataMember(Order = 6)]
        public List<InputObjForQuizResponseList> ResponseOfQuizResponseList { get; set; }


    }


    [DataContract]
    public class InputObjForQuizResponseList
    {
        private string _QuestionID;
        private string _QuestionsAns;
        


        [DataMember(Order = 1)]
        public string QuestionID
        {
            get { return _QuestionID; }
            set { _QuestionID = value; }
        }

        [DataMember(Order = 2)]
        public string QuestionsAns
        {
            get { return _QuestionsAns; }
            set { _QuestionsAns = value; }
        }
       

    }

    [DataContract]
    public class ResponseOfQuizResponse
    {
        private string _StatusId;
        [DataMember(Order = 1)]
        public string StatusId
        {
            get { return _StatusId; }
            set { _StatusId = value; }
        }
        private string _Message;
        [DataMember(Order = 2)]
        public string Message
        {
            get { return _Message; }
            set { _Message = value; }
        }


        [DataMember(Order = 3)]
        public List<ResponseOfQuizResponseList> ResponseOfQuizResponseList { get; set; }


    }


    [DataContract]
    public class ResponseOfQuizResponseList
    {
        private string _TotalQuestionCount;
        private string _CorrectAnsCount;
        private string _QuizName;
        private string _Date;


        [DataMember(Order = 1)]
        public string TotalQuestionCount
        {
            get { return _TotalQuestionCount; }
            set { _TotalQuestionCount = value; }
        }

        [DataMember(Order = 2)]
        public string CorrectAnsCount
        {
            get { return _CorrectAnsCount; }
            set { _CorrectAnsCount = value; }
        }

        [DataMember(Order = 3)]
        public string QuizName
        {
            get { return _QuizName; }
            set { _QuizName = value; }
        }
        [DataMember(Order = 4)]
        public string Date
        {
            get { return _Date; }
            set { _Date = value; }
        }


    }

    [DataContract]
    public class ResponseOfGetQuiz
    {
        private string _Status;
        [DataMember(Order = 1)]
        public string Status
        {
            get { return _Status; }
            set { _Status = value; }
        }
        private string _Message;
        [DataMember(Order = 2)]
        public string Message
        {
            get { return _Message; }
            set { _Message = value; }
        }
        private string _QuizName;
        [DataMember(Order = 3)]
        public string QuizName
        {
            get { return _QuizName; }
            set { _QuizName = value; }
        }

        [DataMember(Order = 4)]
        public List<ResponseOfGetQuizList> ResponseOfGetQuizList { get; set; }


    }


    [DataContract]
    public class ResponseOfGetQuizList
    {
        private string _QuestionID;
        private string _Question;
        private string _Type;
        private string _Options;


        [DataMember(Order = 1)]
        public string QuestionID
        {
            get { return _QuestionID; }
            set { _QuestionID = value; }
        }

        [DataMember(Order = 2)]
        public string Question
        {
            get { return _Question; }
            set { _Question = value; }
        }
        [DataMember(Order = 3)]
        public string Type
        {
            get { return _Type; }
            set { _Type = value; }
        }
        [DataMember(Order = 4)]
        public string Options
        {
            get { return _Options; }
            set { _Options = value; }
        }

        [DataMember(Order = 3)]
        public List<OptionsArray> OptionsArray { get; set; }

       
    }
    [DataContract]
    public class OptionsArray
    {
        
        private string _Value;
        



       
        [DataMember(Order = 2)]
        public string Value
        {
            get { return _Value; }
            set { _Value = value; }
        }

      
    }

    [DataContract]
    public class ResponseOfGetAllArticle
    {
        private string _Status;
        [DataMember(Order = 1)]
        public string Status
        {
            get { return _Status; }
            set { _Status = value; }
        }
        private string _Message;
        [DataMember(Order = 2)]
        public string Message
        {
            get { return _Message; }
            set { _Message = value; }
        }
        private string _PageInfo;
        [DataMember(Order = 3)]
        public string PageInfo
        {
            get { return _PageInfo; }
            set { _PageInfo = value; }
        }

        [DataMember(Order = 3)]
        public List<ResponseOfGetAllArticleList> ResponseOfGetAllArticleList { get; set; }


    }


    [DataContract]
    public class ResponseOfGetAllArticleList
    {
        private string _ID;
        private string _TitleOfArticle;
        private string _ArticleBody;
        private string _CategoryId;
        private string _CategoryName;
        private string _PreQuizId;
        private string _PostQuizId;
        private string _PreQuiz;
        private string _PostQuiz;
        private string _IsFavourite;
        private string _FavouriteID;
        private string _TopicId;
        private string _TopicName;


        [DataMember(Order = 1)]
        public string TopicId
        {
            get { return _TopicId; }
            set { _TopicId = value; }
        }
        [DataMember(Order = 1)]
        public string TopicName
        {
            get { return _TopicName; }
            set { _TopicName = value; }
        }


        [DataMember(Order = 1)]
        public string ID
        {
            get { return _ID; }
            set { _ID = value; }
        }
        [DataMember(Order = 2)]
        public string TitleOfArticle
        {
            get { return _TitleOfArticle; }
            set { _TitleOfArticle = value; }
        }

        [DataMember(Order = 3)]
        public string ArticleBody
        {
            get { return _ArticleBody; }
            set { _ArticleBody = value; }
        }

        [DataMember(Order = 4)]
        public string CategoryId
        {
            get { return _CategoryId; }
            set { _CategoryId = value; }
        }
        [DataMember(Order = 5)]
        public string CategoryName
        {
            get { return _CategoryName; }
            set { _CategoryName = value; }
        }
        [DataMember(Order = 6)]
        public string PreQuizId
        {
            get { return _PreQuizId; }
            set { _PreQuizId = value; }
        }
        [DataMember(Order = 7)]
        public string PostQuizId
        {
            get { return _PostQuizId; }
            set { _PostQuizId = value; }
        }

        [DataMember(Order = 8)]
        public string PreQuiz
        {
            get { return _PreQuiz; }
            set { _PreQuiz = value; }
        }

        [DataMember(Order = 9)]
        public string PostQuiz
        {
            get { return _PostQuiz; }
            set { _PostQuiz = value; }
        }
        [DataMember(Order = 10)]
        public string IsFavourite
        {
            get { return _IsFavourite; }
            set { _IsFavourite = value; }
        }
        [DataMember(Order = 11)]
        public string FavouriteID
        {
            get { return _FavouriteID; }
            set { _FavouriteID = value; }
        }


    }



    [DataContract]
    public class ResponseOfGetUserResultResponse
    {
        private string _Status;
        [DataMember(Order = 1)]
        public string Status
        {
            get { return _Status; }
            set { _Status = value; }
        }
        private string _Message;
        [DataMember(Order = 2)]
        public string Message
        {
            get { return _Message; }
            set { _Message = value; }
        }
       

        [DataMember(Order = 3)]
        public List<ResponseOfGetUserResultResponseList> ResponseOfGetUserResultResponseList { get; set; }


    }


    [DataContract]
    public class ResponseOfGetUserResultResponseList
    {
        private string _QuizName;
        private string _Date;
        private string _TotalNumOfQues;
        private string _CorrectAnsCount;
        private string _TotalPercentage;


        [DataMember(Order = 0)]
        public string QuizName
        {
            get { return _QuizName; }
            set { _QuizName = value; }
        }
        [DataMember(Order = 1)]
        public string TotalNumOfQues
        {
            get { return _TotalNumOfQues; }
            set { _TotalNumOfQues = value; }
        }

        [DataMember(Order = 2)]
        public string CorrectAnsCount
        {
            get { return _CorrectAnsCount; }
            set { _CorrectAnsCount = value; }
        }
        [DataMember(Order = 3)]
        public string TotalPercentage
        {
            get { return _TotalPercentage; }
            set { _TotalPercentage = value; }
        }
        [DataMember(Order = 4)]
        public string Date
        {
            get { return _Date; }
            set { _Date = value; }
        }

        

      
    }





    [DataContract]
    public class ResponseOfGetAllDocument
    {
        private string _Status;
        [DataMember(Order = 1)]
        public string Status
        {
            get { return _Status; }
            set { _Status = value; }
        }
        private string _Message;
        [DataMember(Order = 2)]
        public string Message
        {
            get { return _Message; }
            set { _Message = value; }
        }
        private string _PageInfo;
        [DataMember(Order = 3)]
        public string PageInfo
        {
            get { return _PageInfo; }
            set { _PageInfo = value; }
        }

        [DataMember(Order = 3)]
        public List<ResponseOfGetAllDocumentList> ResponseOfGetAllDocumentList { get; set; }


    }


    [DataContract]
    public class ResponseOfGetAllDocumentList
    {
        private string _DocID;
        private string _TitleOfDoc;
        private string _CategoryId;
        private string _Category;
        private string _TopicId;
        private string _Topic;
        private string _PreQuizId;
        private string _PreQuizName;
        private string _PostQuizId;
        private string _PostQuizName;
        private string _IsFavourite;
        private string _FavouriteID;
        


        [DataMember(Order = 1)]
        public string DocID
        {
            get { return _DocID; }
            set { _DocID = value; }
        }
        [DataMember(Order = 2)]
        public string TitleOfDoc
        {
            get { return _TitleOfDoc; }
            set { _TitleOfDoc = value; }
        }
        [DataMember(Order = 3)]
        public string CategoryId
        {
            get { return _CategoryId; }
            set { _CategoryId = value; }
        }
        [DataMember(Order = 4)]
        public string Category
        {
            get { return _Category; }
            set { _Category = value; }
        }
        [DataMember(Order = 5)]
        public string PreQuizId
        {
            get { return _PreQuizId; }
            set { _PreQuizId = value; }
        }
        [DataMember(Order = 6)]
        public string PreQuizName
        {
            get { return _PreQuizName; }
            set { _PreQuizName = value; }
        }
        [DataMember(Order = 7)]
        public string PostQuizId
        {
            get { return _PostQuizId; }
            set { _PostQuizId = value; }
        }
        [DataMember(Order = 8)]
        public string PostQuizName
        {
            get { return _PostQuizName; }
            set { _PostQuizName = value; }
        }
        [DataMember(Order = 10)]
        public string TopicId
        {
            get { return _TopicId; }
            set { _TopicId = value; }
        }
        [DataMember(Order = 11)]
        public string Topic
        {
            get { return _Topic; }
            set { _Topic = value; }
        }
      
        [DataMember(Order = 9)]
        public string IsFavourite
        {
            get { return _IsFavourite; }
            set { _IsFavourite = value; }
        }


        [DataMember(Order = 10)]
        public string FavouriteID
        {
            get { return _FavouriteID; }
            set { _FavouriteID = value; }
        }

    }
    [DataContract]
    public class ResponseOfGetDocumentByTopicID
    {
        private string _Status;
        [DataMember(Order = 1)]
        public string Status
        {
            get { return _Status; }
            set { _Status = value; }
        }
      
        private string _Message;
        [DataMember(Order = 2)]
        public string Message
        {
            get { return _Message; }
            set { _Message = value; }
        }
        private string _PageInfo;

        [DataMember(Order = 3)]
        public string PageInfo
        {
            get { return _PageInfo; }
            set { _PageInfo = value; }
        }

        private string _PreQuiz;
        [DataMember(Order = 4)]
        public string PreQuiz
        {
            get { return _PreQuiz; }
            set { _PreQuiz = value; }
        }

        private string _PostQuiz;
        [DataMember(Order = 5)]
        public string PostQuiz
        {
            get { return _PostQuiz; }
            set { _PostQuiz = value; }
        }

    }
    [DataContract]
    public class TopicList
    {
        private string _ID;
        private string _Title;


        [DataMember(Order = 1)]
        public string ID
        {
            get { return _ID; }
            set { _ID = value; }
        }
        [DataMember(Order = 2)]
        public string Title
        {
            get { return _Title; }
            set { _Title = value; }
        }


    }

    [DataContract]
    public class ResponseOfGetAllUserType
    {
        private string _Status;
        [DataMember(Order = 1)]
        public string Status
        {
            get { return _Status; }
            set { _Status = value; }
        }
        private string _Message;
        [DataMember(Order = 2)]
        public string Message
        {
            get { return _Message; }
            set { _Message = value; }
        }
        private string _PageInfo;


        [DataMember(Order = 3)]
        public List<UserTypeListList> UserTypeListList { get; set; }


    }


    [DataContract]
    public class UserTypeListList
    {
        private string _ID;
        private string _Title;


        [DataMember(Order = 1)]
        public string ID
        {
            get { return _ID; }
            set { _ID = value; }
        }
        [DataMember(Order = 2)]
        public string Title
        {
            get { return _Title; }
            set { _Title = value; }
        }


    }


    [DataContract]
    public class CheckAnnonymous
    {
        private string _IsExist;
        

        [DataMember(Order = 1)]
        public string IsExist
        {
            get { return _IsExist; }
            set { _IsExist = value; }
        }
       

    }


    public class ResponseOfGetAllDoc
    {

        private string _StatusID;

        [DataMember(Order = 0)]
        public string StatusID
        {
            get { return _StatusID; }
            set { _StatusID = value; }
        }
        private string _Message;

        [DataMember(Order = 1)]
        public string Message
        {
            get { return _Message; }
            set { _Message = value; }
        }
        
        private string _PageInfo;

        [DataMember(Order = 2)]
        public string PageInfo
        {
            get { return _PageInfo; }
            set { _PageInfo = value; }
        }

        [DataMember(Order = 3)]
        public List<GetAllDocRes> GetAllDocRes { get; set; }
    }

    [DataContract]
    public class GetAllDocRes
    {
        private string _ID;
        private string _Title;
        private string _DocByteArr;
      

        [DataMember(Order = 1)]
        public string ID
        {
            get { return _ID; }
            set { _ID = value; }
        }
        [DataMember(Order = 2)]
        public string Title
        {
            get { return _Title; }
            set { _Title = value; }
        }

        [DataMember(Order = 3)]
        public string DocByteArr
        {
            get { return _DocByteArr; }
            set { _DocByteArr = value; }
        }
    }
}
