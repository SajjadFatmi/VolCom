﻿
namespace MobAppSer
{
    public class ParameterHelperCommon
    {
        public string URL { get; set; }
        public string UserID { get; set; }
        public string Password { get; set; }
        public string Dmain { get; set; }
        public string CAMLQuery { get; set; }
        public string ListName { get; set; }
        
    }
}
