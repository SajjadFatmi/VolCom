﻿using System;
using System.Collections.Generic;
using Microsoft.SharePoint.Client;
using System.Data;
using System.Collections;
using Microsoft.SharePoint.Client.Taxonomy;
using System.IO;
using System.Text;
using SP = Microsoft.SharePoint.Client;
using System.Runtime.Serialization;
using Newtonsoft.Json;
namespace MobAppSer
{
    public class SPClientHelper
    {
        public static bool ValidateLogin(ParameterHelperCommon helper)
        {
            bool IsValidUser = false;
            try
            {

                ClientContext connectContext = new ClientContext(helper.URL);
                connectContext.AuthenticationMode = ClientAuthenticationMode.FormsAuthentication;
                connectContext.FormsAuthenticationLoginInfo = new
                                    FormsAuthenticationLoginInfo(helper.UserID, helper.Password);

                Web w = connectContext.Web;

                //LOAD LISTS WITH ALL PROPERTIES 
                var lists = connectContext.LoadQuery(w.Lists);

                //execute the query 
                  connectContext.ExecuteQuery();
                IsValidUser = true;

            }
            catch (Exception ex)
            {

                throw ex;
            }
            return IsValidUser;
        }
        [DataContract]
        public class Users
        {

            private string _UserID;
            private string _EmailID;
            private string _MobileNumber;
            private string _UserType;



            [DataMember(Order = 1)]
            public string UserID
            {
                get { return _UserID; }
                set { _UserID = value; }
            }
            [DataMember(Order = 2)]
            public string EmailID
            {
                get { return _EmailID; }
                set { _EmailID = value; }
            }
            [DataMember(Order = 3)]
            public string MobileNumber
            {
                get { return _MobileNumber; }
                set { _MobileNumber = value; }
            }
            [DataMember(Order = 4)]
            public string UserType
            {
                get { return _UserType; }
                set { _UserType = value; }
            }



        }
        public static List<Users> GetListItems(ParameterHelperCommon helper)
        {
            StringBuilder sb = new StringBuilder();

            try
            {

                ClientContext clientContext = new ClientContext(helper.URL);  
                SP.List oList = clientContext.Web.Lists.GetByTitle(helper.ListName);

                clientContext.AuthenticationMode = ClientAuthenticationMode.FormsAuthentication;
                clientContext.FormsAuthenticationLoginInfo = new
                                    FormsAuthenticationLoginInfo(helper.UserID, helper.Password);

                Web w = clientContext.Web;
                var lists = clientContext.LoadQuery(w.Lists);
             
                clientContext.Load(w);
                List list = w.Lists.GetByTitle(helper.ListName);
                clientContext.Load(list);

                CamlQuery camlQuery = new CamlQuery();
                camlQuery.ViewXml = helper.CAMLQuery;

                //-----------------------
                ListItemCollection ListColletion = list.GetItems(camlQuery);
                clientContext.Load(list);
                clientContext.Load(ListColletion);
                
                clientContext.ExecuteQuery();
                List<Users> data = new List<Users>();
                Users us = new Users();
                foreach (ListItem oListItem in ListColletion)
                {
                    us.UserID = oListItem["UserID"].ToString();
                    us.EmailID = oListItem["EmailID"].ToString();
                    us.MobileNumber = oListItem["MobileNumber"].ToString();
                    us.UserType = oListItem["UserType"].ToString();
                    data.Add(us);
                }

                string sJSONResponse = JsonConvert.SerializeObject(data);
                return data;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }




        public static ClientContext ConnectToSite(ParameterHelperCommon helper)
        {
           
            try
            {
                ClientContext clientContext = new ClientContext(helper.URL);
                SP.List oList = clientContext.Web.Lists.GetByTitle(helper.ListName);

                clientContext.AuthenticationMode = ClientAuthenticationMode.FormsAuthentication;
                clientContext.FormsAuthenticationLoginInfo = new
                                    FormsAuthenticationLoginInfo(helper.UserID, helper.Password);


                Web oWebSite = clientContext.Web;
                clientContext.Load(oWebSite);
                Web w = clientContext.Web;
                var lists = clientContext.LoadQuery(w.Lists);

                clientContext.Load(w);
                clientContext.ExecuteQuery();

                return clientContext;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
        public static DataTable GetAllList(ParameterHelperCommon helper)
        {
            DataTable dtAllList = new DataTable();
            dtAllList.Columns.Add("ID");
            dtAllList.Columns.Add("ListName");
           
            try
            {
                //Starting with ClientContext, the constructor requires a URL to the 
                // server running SharePoint. 
                ClientContext context = ConnectToSite(helper);

                // The SharePoint web at the URL.
                Web web = context.Web;

                // Retrieve all lists from the server. 
                context.Load(web.Lists,
                             lists => lists.Include(list => list.Title, // For each list, retrieve Title and Id. 
                                                    list => list.Id,
                                                    list => list.BaseType));

                // Execute query. 
                context.ExecuteQuery();

                // Enumerate the web.Lists. 
                foreach (List list in web.Lists)
                {
                    if (list.BaseType.ToString() == BaseType.GenericList.ToString())
                    {
                        dtAllList.Rows.Add(list.Id, list.Title);
                    }
                }
                return dtAllList;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
        public static ListItemCollection GetRecordsByCAML(ParameterHelperCommon helper,string FullName,string MobileNumber,
                 string Extension, string UserType, string AnnonymusName, string AboutMe, string Designation)
        {
            try
            {

                ClientContext clientContext = ConnectToSite(helper);
                TaxonomyItem dummy = new TaxonomyItem(clientContext, null);

                List partsList = clientContext.Web.Lists.GetByTitle(helper.ListName);


                List<string> strConditions = new List<string>();


                CamlQuery camlQueryPartsList = new CamlQuery();
                //camlQueryPartsList.ViewXml = "<View><Query><Where><Geq><FieldRef Name='ID'/>" +
                //"<Value Type='Number'>11</Value></Geq></Where></Query><RowLimit>100</RowLimit></View>"; 
                camlQueryPartsList.ViewXml = "<View><Query>" + helper.CAMLQuery + "</Query><RowLimit>100</RowLimit></View>";
                ListItemCollection itemCollection = partsList.GetItems(camlQueryPartsList);
                clientContext.Load(partsList);
              
                clientContext.Load(itemCollection);
                clientContext.Load(itemCollection,
                  items => items.Include(
                  item => item.Id,
                  item => item.DisplayName,
                  item => item.HasUniqueRoleAssignments));
                clientContext.ExecuteQuery();
                foreach (ListItem lsitem in itemCollection)
                {
                    //clientContext.Load(lsitem);
                    lsitem["AboutMe"] = AboutMe;
                    lsitem["AnnonymusName"] = AnnonymusName;
                    lsitem["Designation"] = Designation;
                    lsitem["ExtensionNumber"] = Extension;
                    lsitem["FullName"] = FullName;
                    lsitem["MobileNumber"] = MobileNumber;
                    lsitem["UserType"] = UserType;

                    lsitem.Update();


                }
                clientContext.ExecuteQuery();

                return itemCollection;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
        public static bool AddItem(ParameterHelperCommon helper, Hashtable tbl)
        {
            try
            {
                ClientContext clientContext = ConnectToSite(helper);
                List Lst = clientContext.Web.Lists.GetByTitle(helper.ListName);
                ListItemCreationInformation itemCreateInfo = new ListItemCreationInformation();
                ListItem newItem = Lst.AddItem(itemCreateInfo);

                foreach (DictionaryEntry entry in tbl)
                {
                    if (entry.Value is TaxonomyFieldValueCollection)
                    {
                        TaxonomyFieldValueCollection taxFieldValueCol = entry.Value as TaxonomyFieldValueCollection;
                        foreach (TaxonomyFieldValue taxFieldValue in taxFieldValueCol)
                        {
                            var arr = taxFieldValue.Label + "|" + taxFieldValue.TermGuid;
                            var str = String.Join(";", arr);
                            newItem[entry.Key.ToString()] = str;
                        }
                    }
                    else if (entry.Value is TaxonomyFieldValue)
                    {
                        var txValue = entry.Value as TaxonomyFieldValue;
                        var str = txValue.Label + "|" + txValue.TermGuid;

                        newItem[entry.Key.ToString()] = str;
                    }
                    else if (entry.Value is FieldUserValue)
                    {
                        FieldUserValue txValue = entry.Value as FieldUserValue;
                        if (txValue.LookupId != -1)
                        {
                            ClientContext clientContext2 = ConnectToSite(helper);
                            var user = clientContext2.Web.GetUserById(txValue.LookupId);
                            clientContext2.Load(user);
                            clientContext2.ExecuteQuery();

                            user = clientContext.Web.EnsureUser(user.LoginName);
                            newItem[entry.Key.ToString()] = user;
                        }
                        else
                            newItem[entry.Key.ToString()] = null;
                    }
                    else
                        newItem[entry.Key.ToString()] = entry.Value;
                }

                try
                {
                    newItem.Update();
                    clientContext.ExecuteQuery();
                }
                catch (Exception ex)
                {
                    LogFile(ex.Message, ex.StackTrace, ex.Source, "AddItem");
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
        public static FieldCollection GetListFields(ParameterHelperCommon helper)
        {
            try
            {

                ClientContext clientContext = ConnectToSite(helper);
                List Lst = clientContext.Web.Lists.GetByTitle(helper.ListName);
                clientContext.Load(Lst.Fields);
                clientContext.ExecuteQuery();
                return Lst.Fields;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
        public static bool DeleteItemByID(ParameterHelperCommon helper, int itemID)
        {
            try
            {
                ClientContext context = ConnectToSite(helper);
                List announcementsList = context.Web.Lists.GetByTitle(helper.ListName);
                ListItem listItem = announcementsList.GetItemById(itemID);
                listItem.DeleteObject();
                context.ExecuteQuery();
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static DataTable GetAllDateColumn(ParameterHelperCommon helper, string listName)
        {
            if (string.IsNullOrEmpty(listName))
                return null;

            DataTable dtDateCol = new DataTable();
            dtDateCol.Columns.Add("ID");
            dtDateCol.Columns.Add("FieldName");
            try
            {
                //Starting with ClientContext, the constructor requires a URL to the 
                // server running SharePoint. 
                ClientContext context = ConnectToSite(helper);

                // The SharePoint web at the URL.
                Web web = context.Web;

                List oList = context.Web.Lists.GetByTitle(listName);
                FieldCollection fieldColl = oList.Fields;
                context.Load(fieldColl);
                context.ExecuteQuery();

                foreach (Field fieldTemp in fieldColl)
                {
                    if (fieldTemp is FieldDateTime)
                        dtDateCol.Rows.Add(fieldTemp.Id, fieldTemp.Title);
                }
                return dtDateCol;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
        public static void LogFile(string sExceptionName, string stackTrace, string sSource, string sFunctionName)
        {
            StreamWriter log;
            if (!System.IO.File.Exists("logfile.txt"))
            {
                log = new StreamWriter("logfile.txt");
            }
            else
            {
                log = System.IO.File.AppendText("logfile.txt");
            }
            // Write to the file:
            log.WriteLine("Data Time:" + DateTime.Now);
            log.WriteLine("Exception Message:" + sExceptionName);
            log.WriteLine("Stack Trace:" + stackTrace);
            log.WriteLine("Source:" + sSource);
            log.WriteLine("Function Name:" + sFunctionName);
            log.WriteLine("--------------------------------------------------");
            log.WriteLine();
            // Close the stream:
            log.Close();
        }

        public static DataTable GetAllFields(ParameterHelperCommon helper, string listName)
        { 
            
            if (string.IsNullOrEmpty(listName))
                return null;

            DataTable dtDateCol = new DataTable();
            dtDateCol.Columns.Add("FieldID");
            dtDateCol.Columns.Add("FieldTitle");
            dtDateCol.Columns.Add("FieldInternalName");
            dtDateCol.Columns.Add("FieldRequired");
            dtDateCol.Columns.Add("TypeAsString");
            //dtDateCol.Columns.Add("MaxLength");
            //dtDateCol.Columns.Add("MaxLines");
            try
            {
                //Starting with ClientContext, the constructor requires a URL to the 
                // server running SharePoint. 
                ClientContext context = ConnectToSite(helper);

                // The SharePoint web at the URL.
                Web web = context.Web;

                List oList = context.Web.Lists.GetByTitle(listName);
                FieldCollection fieldColl = oList.Fields;
                context.Load(fieldColl);
                context.ExecuteQuery();

                foreach (Field fieldTemp in fieldColl)
                {
                    if (fieldTemp.Hidden == false && fieldTemp.Sealed == false && fieldTemp.ReadOnlyField == false && fieldTemp.Title != "Content Type" && fieldTemp.Title!="Attachments")
                    {
                        #region Not used (for maxlength and max no of lines)
                        // if (fieldTemp.ToString() == "Microsoft.SharePoint.Client.FieldText")
                       // {
                       //     dtDateCol.Rows.Add(fieldTemp.Id, fieldTemp.Title, fieldTemp.InternalName, fieldTemp.Required,
                       //         ((Microsoft.SharePoint.Client.FieldText)(fieldTemp)).MaxLength,"");
                       // }
                       //else if(fieldTemp.ToString()=="Microsoft.SharePoint.Client.FieldMultiLineText")
                       // {
                       //     dtDateCol.Rows.Add(fieldTemp.Id, fieldTemp.Title, fieldTemp.InternalName, fieldTemp.Required,
                       //         "", ((Microsoft.SharePoint.Client.FieldMultiLineText)(fieldTemp)).NumberOfLines);
                       //}
                       // else
                       // {
                        //}
                        #endregion

                        dtDateCol.Rows.Add(fieldTemp.Id, fieldTemp.Title, fieldTemp.InternalName, fieldTemp.Required, fieldTemp.TypeAsString);
                       
                       
                    }
                }
                return dtDateCol;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
        public static string GetSubSiteName(ParameterHelperCommon helper)
        {

            ClientContext clientContext = ConnectToSite(helper);
            return (clientContext.Web.ServerRelativeUrl).TrimStart('/');
        }

    }

}
