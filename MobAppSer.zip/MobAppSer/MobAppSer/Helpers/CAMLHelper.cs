﻿using Microsoft.SharePoint.Utilities;
using System;
using System.Collections.Generic;
using System.Text;

namespace MobAppSer
{
    public class CAMLHelper
    { 
        #region "ENUMS"
        public enum MergeType { Or, And };
        public enum OpeatorType { Equal, LessThan, GreaterThan, LessThanEqualTo, GreaterThanEqualTo, NotEqualTo, Include, NotIncludes, Contains, DateRaneOverlap, In, IsNotNull, IsNull, BeginWith };
        public enum DataType { Text, Integer, Lookup, Date, Boolean, DateTime,File };
        public enum OrderBy { Ascending, Descending };
        #endregion
        /// <summary>
        /// Merge CAML conditions in code
        /// </summary>
        /// <param name="conditions">A list of contitions to merge into alternative or conjunction</param>
        /// <param name="type"><value>MergeType.Or</value> for alternative, MergeType.And for conjunction</param>
        /// <returns></returns>
        #region "Where Clause CAML"
        public static string MergeCAMLConditions(List<string> conditions, MergeType type, bool AddWhereCondition = false)
        {
            string returnValue = string.Empty;
            // No conditions => empty response
            if (conditions.Count == 0) return "";

            // Initialize temporary variables
            string typeStart = (type == MergeType.And ? "<And>" : "<Or>");
            string typeEnd = (type == MergeType.And ? "</And>" : "</Or>");

            // Build hierarchical structure
            while (conditions.Count >= 2)
            {
                List<string> complexConditions = new List<string>();

                for (int i = 0; i < conditions.Count; i += 2)
                {
                    if (conditions.Count == i + 1) // Only one condition left
                        complexConditions.Add(conditions[i]);
                    else // Two condotions - merge
                        complexConditions.Add(typeStart + conditions[i] + conditions[i + 1] + typeEnd);
                }

                conditions = complexConditions;
            }

            returnValue = conditions[0];
            if (AddWhereCondition)
            {
                returnValue = "<Where>" + returnValue + "</Where>";
            }
            return returnValue;
        }

  
        public static string GetCAMLFieldRefCondition(string ColumnName, DataType pDataType, string Value, OpeatorType pOpeatorType, bool IsLookUpByID = false)
        {

            string TemplateCondition = "<{0}><FieldRef Name=\"{1}\" {5} />{6}<Value Type=\"{2}\" {4}>{3}</Value>{7}</{0}>";

            string strDataType = string.Empty,
                   strOperatorType = string.Empty,
                   strIncludeOtherOptions = string.Empty,
                   strIncludeOtherOptionsInFieldRef = string.Empty,
                   strInClauseValuesStart = string.Empty,
                    strInClauseValuesEnd = string.Empty;

            if (pOpeatorType.Equals(OpeatorType.BeginWith)) { strOperatorType = "BeginsWith"; }
            else if (pOpeatorType.Equals(OpeatorType.Contains)) { strOperatorType = "Contains"; }
            else if (pOpeatorType.Equals(OpeatorType.DateRaneOverlap)) { strOperatorType = "DateRangesOverlap"; }
            else if (pOpeatorType.Equals(OpeatorType.Equal)) { strOperatorType = "Eq"; }
            else if (pOpeatorType.Equals(OpeatorType.NotEqualTo)) { strOperatorType = "Neq"; }
            else if (pOpeatorType.Equals(OpeatorType.GreaterThan)) { strOperatorType = "Gt"; }
            else if (pOpeatorType.Equals(OpeatorType.GreaterThanEqualTo)) { strOperatorType = "Geq"; }
            else if (pOpeatorType.Equals(OpeatorType.LessThan)) { strOperatorType = "Lt"; }
            else if (pOpeatorType.Equals(OpeatorType.LessThanEqualTo)) { strOperatorType = "Leq"; }
            else if (pOpeatorType.Equals(OpeatorType.In))
            {
                strOperatorType = "In";
                strInClauseValuesStart = "<Values>"; strInClauseValuesEnd = "</Values>";
                string ValueCondition = "";
                StringBuilder sb = new StringBuilder();
                if (Value.Contains(","))
                {
                    string[] values = Value.Split(",".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
                    if (values != null)
                    {
                        foreach (string strValue in values)
                        {
                            sb.Append("<Value Type=\"{2}\" {4}>" + strValue + "</Value>");
                        }
                    }
                }
                else
                {
                    sb.Append("<Value Type=\"{2}\" {4}>" + Value + "</Value>");
                }

                ValueCondition = sb.ToString();
                TemplateCondition = "<{0}><FieldRef Name=\"{1}\" {5} />{6}" + ValueCondition + "{7}</{0}>";
            }
            else if (pOpeatorType.Equals(OpeatorType.Include)) { strOperatorType = "INCLUDES"; }
            else if (pOpeatorType.Equals(OpeatorType.NotIncludes)) { strOperatorType = "NOT INCLUDES"; }
            else if (pOpeatorType.Equals(OpeatorType.IsNotNull)) { strOperatorType = "IsNotNull"; }
            else if (pOpeatorType.Equals(OpeatorType.IsNull)) { strOperatorType = "IsNull"; }


            if (pDataType.Equals(DataType.Text)) { strDataType = "Text"; }
            else if (pDataType.Equals(DataType.Boolean)) { strDataType = "Boolean"; }
            else if (pDataType.Equals(DataType.File)) { strDataType = "File"; }
            else if (pDataType.Equals(DataType.Date))
            {
                strDataType = "DateTime";
                strIncludeOtherOptions = "IncludeTimeValue='FALSE'";

                Value = SPUtility.CreateISO8601DateTimeFromSystemDateTime(Convert.ToDateTime(Value));
            }
            else if (pDataType.Equals(DataType.DateTime))
            {
                strDataType = "DateTime";
                strIncludeOtherOptions = "IncludeTimeValue='TRUE'";

                Value = SPUtility.CreateISO8601DateTimeFromSystemDateTime(Convert.ToDateTime(Value));
            }
            else if (pDataType.Equals(DataType.Integer)) { strDataType = "Integer"; }
            else if (pDataType.Equals(DataType.Lookup)) { strDataType = "Lookup"; strIncludeOtherOptionsInFieldRef = (IsLookUpByID == true ? " LookupId='TRUE'" : " LookupId='FALSE'"); }




            TemplateCondition = string.Format(TemplateCondition, strOperatorType, ColumnName, strDataType, Value, strIncludeOtherOptions, strIncludeOtherOptionsInFieldRef, strInClauseValuesStart, strInClauseValuesEnd);

            return TemplateCondition;
        }
        #endregion
        #region "Order By Clause CAML"
        public static string GetOrderByFieldRefCondition(string ColumnName,OrderBy orderby)
        {
            string returnFieldRef = "<FieldRef Name='{0}' Ascending='{1}' />";
            returnFieldRef = string.Format(returnFieldRef, ColumnName, (orderby == OrderBy.Ascending ? "True" : "False"));
            return returnFieldRef;
        }
        public static string MergeOrderByCondition(List<string> conditions)
        {
            StringBuilder sbOrderByClause = new StringBuilder();
            sbOrderByClause.Append("<OrderBy>");
            foreach (string strCondition in conditions)
            {
                sbOrderByClause.Append(strCondition);

            }
            sbOrderByClause.Append("</OrderBy>");
            return sbOrderByClause.ToString();
        }
        #endregion
        #region "View Field Clause Creation"
        public static string GetViewFieldRef(params string[] Columns)
        {
            string ViewFieldCondition = "<FieldRef Name='{0}'/>";
            StringBuilder sb = new StringBuilder();
            foreach (String Column in Columns)
            {
                sb.Append(String.Format(ViewFieldCondition,Column));
            }
            return sb.ToString();
        }
        #endregion
    }
}
