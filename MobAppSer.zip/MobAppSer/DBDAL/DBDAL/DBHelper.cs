﻿using System;
using System.Data;
using constants;
using System.Data.Common;
using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Common;
using Microsoft.Practices.EnterpriseLibrary.Data.Oracle;
using Oracle.DataAccess.Client;
using System.Collections.Generic;
using Oracle.DataAccess.Types;
using System.Collections;
//using Microsoft.Practices.EnterpriseLibrary.Data;

namespace DBDAL
{
    public class DBHelper
    {

        #region "Private Variables"
        Database db = null;
        DbCommand odbcommand = null;
        private ConnectionManager _connectionManager = null;
        private CommandBuilder _commandBuilder = null;
        private DataAdapterManager _dbAdapterManager = new DataAdapterManager();
        private static DBHelper _dbHelper = null;
        private IDbConnection _connection = null;
        private string _providerName = string.Empty;
        private AssemblyProvider _assemblyProvider = null;
        #endregion

        #region "Constructor Methods"

        /// <summary>
        /// This Constructor creates instance of the class for defaultConnection 
        /// </summary>
        public DBHelper()
        {
            //db = DatabaseFactory.CreateDatabase("oracleCon");
            _connectionManager = new ConnectionManager();
            _commandBuilder = new CommandBuilder();
            _dbAdapterManager = new DataAdapterManager();
            _connection = _connectionManager.GetConnection();
            _providerName = _connectionManager.ProviderName;
            _assemblyProvider = new AssemblyProvider(_providerName);
        }

        /// <summary>
        /// This constructor should be used for creation of the instance for the specified app settings connection name
        /// </summary>
        /// <param name="connectionName">App Setting's connection name</param>
        public DBHelper(string connectionName)
        {
            //db = DatabaseFactory.CreateDatabase("oracleCon");
            _connectionManager = new ConnectionManager(connectionName);
            _commandBuilder = new CommandBuilder(Configuration.GetProviderName(connectionName));
            _dbAdapterManager = new DataAdapterManager(Configuration.GetProviderName(connectionName));
            _connection = _connectionManager.GetConnection();
            _providerName = _connectionManager.ProviderName;
            _assemblyProvider = new AssemblyProvider(_providerName);
        }

        /// <summary>
        /// Constructor creates instance of the class for the specified connection string and provider name
        /// </summary>
        /// <param name="connectionString">Connection String</param>
        /// <param name="providerName">Provider name</param>
        public DBHelper(string connectionString, string providerName)
        {
            _connectionManager = new ConnectionManager(connectionString, providerName);
            _commandBuilder = new CommandBuilder(providerName);
            _dbAdapterManager = new DataAdapterManager(providerName);
            _connection = _connectionManager.GetConnection();
            _providerName = _connectionManager.ProviderName;
            _assemblyProvider = new AssemblyProvider(_providerName);
        }

        #endregion

        #region "Methods returning instance of singleton class"

        /// <summary>
        /// Creates and reuturns instance of DBHelper class for the default connection        
        /// </summary>
        /// <returns>Instance of DBHelper class</returns>
        //public static DBHelper GetInstance()
        //{
        //    if (_dbHelper == null)
        //        _dbHelper = new DBHelper();

        //    return _dbHelper;
        //}

        /// <summary>
        ///  Creates and reuturns instance of DBHelper class for the connection string key specified into App.config/ web.config file
        /// </summary>
        /// <param name="connectionName">Connection key specified into web.config/ App.config</param>
        /// <returns>Instance of DBHelper class</returns>
        //public static DBHelper GetInstance(string connectionName)
        //{
        //    if (_dbHelper == null)
        //        _dbHelper = new DBHelper(connectionName);

        //    return _dbHelper;
        //}

        /// <summary>
        /// Creates and reuturns instance of DBHelper class for the coonection string and provider name specified as constructor parameter
        /// </summary>
        /// <param name="connectionString">ConnectionString</param>
        /// <param name="providerName">Provider Name</param>
        /// <returns>Instance of DBHelper class</returns>
        //public static DBHelper GetInstance(string connectionString, string providerName)
        //{
        //    if (_dbHelper == null)
        //        _dbHelper = new DBHelper(connectionString, providerName);

        //    return _dbHelper;
        //}
        #endregion

        #region "Transaction Methods"

        /// <summary>
        /// Gets the database transaction
        /// After successful execution of command call CommitTransaction(transaction)
        /// In case of failure call RollbackTransaction(transaction)
        /// </summary>
        public IDbTransaction BeginTransaction()
        {
            return GetConnObject().BeginTransaction();
        }


        /// <summary>
        /// Commits changes to the database
        /// </summary>
        /// <param name="transaction">Database Transcation to be committed</param>
        public void CommitTransaction(IDbTransaction transaction)
        {
            try
            {
                transaction.Commit();
            }
            catch (Exception err)
            {
                ParameterHelperCommon oParameterHelperCommonDestination = new ParameterHelperCommon();
                oParameterHelperCommonDestination.Dmain = "AKU";
                string LoggingSiteUrl = System.Configuration.ConfigurationSettings.AppSettings["LoggingSiteURL"].ToString();
                oParameterHelperCommonDestination.URL = LoggingSiteUrl;
                string LoggingListName = System.Configuration.ConfigurationSettings.AppSettings["LoggingListName"].ToString();
                oParameterHelperCommonDestination.ListName = LoggingListName;



                Hashtable tblitem = new Hashtable();
                tblitem.Add("Title", "DBHelper (CommitTransaction)");
                tblitem.Add("Exception", err.Message);
                if (err.StackTrace != null)
                {
                    tblitem.Add("StackTrace", err.StackTrace);
                }
                if (err.InnerException != null)
                {
                    tblitem.Add("InnerException", err.InnerException);
                }
                bool IsSaved = SPClientHelper.AddItem(oParameterHelperCommonDestination, tblitem);
                throw err;
            }
        }


        /// <summary>
        /// Rollback changes to the database
        /// </summary>
        /// <param name="transaction">Database Transaction to be rolled back</param>
        public void RollbackTransaction(IDbTransaction transaction)
        {
            try
            {
                transaction.Rollback();
            }
            catch (Exception err)
            {
                ParameterHelperCommon oParameterHelperCommonDestination = new ParameterHelperCommon();
                oParameterHelperCommonDestination.Dmain = "AKU";
                string LoggingSiteUrl = System.Configuration.ConfigurationSettings.AppSettings["LoggingSiteURL"].ToString();
                oParameterHelperCommonDestination.URL = LoggingSiteUrl;
                string LoggingListName = System.Configuration.ConfigurationSettings.AppSettings["LoggingListName"].ToString();
                oParameterHelperCommonDestination.ListName = LoggingListName;



                Hashtable tblitem = new Hashtable();
                tblitem.Add("Title", "DBHelper (RollbackTransaction)");
                tblitem.Add("Exception", err.Message);
                if (err.StackTrace != null)
                {
                    tblitem.Add("StackTrace", err.StackTrace);
                }
                if (err.InnerException != null)
                {
                    tblitem.Add("InnerException", err.InnerException);
                }
                bool IsSaved = SPClientHelper.AddItem(oParameterHelperCommonDestination, tblitem);
                throw err;
            }
        }


        /// <summary>
        /// Gets Connection String
        /// </summary>
        public string ConnectionString
        {
            get
            {
                return _connectionManager.ConnectionString;
            }
        }

        public string Database
        {
            get
            {
                //IDbConnection connection = AssemblyProvider.GetInstance(Provider).Factory.CreateConnection();
                IDbConnection connection = _assemblyProvider.Factory.CreateConnection();
                connection.ConnectionString = ConnectionString;
                return connection.Database;
            }
        }


        /// <summary>
        /// Gets Provider Name
        /// </summary>
        public string Provider
        {
            get
            {
                return _providerName;
            }
        }



        #endregion

        #region "Execute Scalar"
        /// <summary>
        /// Executes the Sql Command or Stored Procedure and returns result.
        /// </summary>
        /// <param name="commandText">Sql Command or Stored Procedure name</param>
        /// <param name="commandType">Type of command (i.e. Sql Command/ Stored Procedure name/ Table Direct)</param>
        /// <returns>A single value. (First row's first cell value, if more than one row and column is returned.)</returns>
        public object ExecuteScalar(string commandText, CommandType commandType)
        {
            return ExecuteScalar(commandText, (IDbTransaction)null, commandType);
        }

        /// <summary>
        /// Executes the Sql Command or Stored Procedure and returns result.
        /// </summary>
        /// <param name="commandText">Sql Command or Stored Procedure name</param>
        /// <param name="transaction">Current Database Transaction (Use Helper.Transaction to get transaction)</param>
        /// <param name="commandType">Text or Stored Procedure</param>
        /// <returns>A single value. (First row's first cell value, if more than one row and column is returned.)</returns>
        public object ExecuteScalar(string commandText, IDbTransaction transaction, CommandType commandType)
        {
            return ExecuteScalar(commandText, new DBParameterCollection(), transaction, commandType);
        }

        /// <summary>
        /// Executes the Sql Command or Stored Procedure and returns result.
        /// </summary>
        /// <param name="commandText">Sql Command or Stored Procedure name</param>
        /// <param name="param">Parameter to be associated</param>
        /// <param name="commandType">Type of command (i.e. Sql Command/ Stored Procedure name/ Table Direct)</param>
        /// <returns>A single value. (First row's first cell value, if more than one row and column is returned.)</returns>
        public object ExecuteScalar(string commandText, DBParameter param, CommandType commandType)
        {
            return ExecuteScalar(commandText, param, null, commandType);
        }


        /// <summary>
        /// Executes the Sql Command or Stored Procedure and returns result.
        /// </summary>
        /// <param name="commandText">Sql Command or Stored Procedure name</param>
        /// <param name="param">Database parameter</param>
        /// <param name="transaction">Current Database Transaction (Use Helper.Transaction to get transaction)</param>
        /// <param name="commandType">Text or Stored Procedure</param>
        /// <returns>A single value. (First row's first cell value, if more than one row and column is returned.)</returns>
        public object ExecuteScalar(string commandText, DBParameter param, IDbTransaction transaction, CommandType commandType)
        {
            DBParameterCollection paramCollection = new DBParameterCollection();
            paramCollection.Add(param);
            return ExecuteScalar(commandText, paramCollection, transaction, commandType);
        }

        /// <summary>
        /// Executes the Sql Command or Stored Procedure and returns result.
        /// </summary>
        /// <param name="commandText">Sql Command or Stored Procedure name</param>
        /// <param name="paramCollection">Parameter collection to be associated</param>
        /// <param name="commandType">Type of command (i.e. Sql Command/ Stored Procedure name/ Table Direct)</param>
        /// <returns>A single value. (First row's first cell value, if more than one row and column is returned.)</returns>
        public object ExecuteScalar(string commandText, DBParameterCollection paramCollection, CommandType commandType)
        {
            return ExecuteScalar(commandText, paramCollection, (IDbTransaction)null, commandType);
        }


        /// <summary>
        /// Executes the Sql Command or Stored Procedure and returns result.
        /// </summary>
        /// <param name="commandText">Sql Command or Stored Procedure name</param>
        /// <param name="paramCollection">Database parameter Collection</param>
        /// <param name="transaction">Current Database Transaction (Use Helper.Transaction to get transaction)</param>
        /// <param name="commandType">Text or Stored Procedure</param>
        /// <returns>A single value. (First row's first cell value, if more than one row and column is returned.)</returns>
        public object ExecuteScalar(string commandText, DBParameterCollection paramCollection, IDbTransaction transaction, CommandType commandType)
        {
            object objScalar = null;
            IDbConnection connection = transaction != null ? transaction.Connection : _connectionManager.GetConnection();
            IDbCommand command = _commandBuilder.GetCommand(commandText, connection, paramCollection, commandType);
            command.Transaction = transaction;
            try
            {
                objScalar = command.ExecuteScalar();
            }
            catch (Exception ex)
            {
                ParameterHelperCommon oParameterHelperCommonDestination = new ParameterHelperCommon();
                oParameterHelperCommonDestination.Dmain = "AKU";
                string LoggingSiteUrl = System.Configuration.ConfigurationSettings.AppSettings["LoggingSiteURL"].ToString();
                oParameterHelperCommonDestination.URL = LoggingSiteUrl;
                string LoggingListName = System.Configuration.ConfigurationSettings.AppSettings["LoggingListName"].ToString();
                oParameterHelperCommonDestination.ListName = LoggingListName;



                Hashtable tblitem = new Hashtable();
                tblitem.Add("Title", "DBHelper (ExecuteScalar)");
                tblitem.Add("Exception", ex.Message);
                if (ex.StackTrace != null)
                {
                    tblitem.Add("StackTrace", ex.StackTrace);
                }
                if (ex.InnerException != null)
                {
                    tblitem.Add("InnerException", ex.InnerException);
                }
                bool IsSaved = SPClientHelper.AddItem(oParameterHelperCommonDestination, tblitem);
                throw ex;
            }
            finally
            {
                if (transaction == null)
                {
                    if (connection != null)
                    {
                        connection.Close();
                        connection.Dispose();
                    }
                }

                if (command != null)
                    command.Dispose();
            }
            return objScalar;
        }

        /// <summary>
        /// Executes the Sql Command and returns result.
        /// </summary>
        /// <param name="commandText">Sql Command</param>
        /// <returns>A single value. (First row's first cell value, if more than one row and column is returned.)</returns>
        public object ExecuteScalar(string commandText)
        {
            return ExecuteScalar(commandText, (IDbTransaction)null);
        }

        /// <summary>
        /// Executes the Sql Command and returns result.
        /// </summary>
        /// <param name="commandText">Sql Command </param>
        /// <param name="transaction">Current Database Transaction (Use Helper.Transaction to get transaction)</param>
        /// <returns>A single value. (First row's first cell value, if more than one row and column is returned.)</returns>
        public object ExecuteScalar(string commandText, IDbTransaction transaction)
        {
            return ExecuteScalar(commandText, transaction, CommandType.Text);
        }

        /// <summary>
        /// Executes the Sql Command and returns result.
        /// </summary>
        /// <param name="commandText">Sql Command</param>
        /// <param name="param">Parameter to be associated</param>
        /// <returns>A single value. (First row's first cell value, if more than one row and column is returned.)</returns>
        public object ExecuteScalar(string commandText, DBParameter param)
        {
            return ExecuteScalar(commandText, param, (IDbTransaction)null);
        }


        /// <summary>
        /// Executes the Sql Command and returns result.
        /// </summary>
        /// <param name="commandText">Sql Command</param>
        /// <param name="param">Parameter to be associated</param>
        /// <param name="transaction">Database Transacion</param>
        /// <returns>A single value. (First row's first cell value, if more than one row and column is returned.)</returns>
        public object ExecuteScalar(string commandText, DBParameter param, IDbTransaction transaction)
        {
            return ExecuteScalar(commandText, param, transaction, CommandType.Text);
        }

        /// <summary>
        /// Executes the Sql Command and returns result.
        /// </summary>
        /// <param name="commandText">Sql Command</param>
        /// <param name="paramCollection">Parameter collection to be associated.</param>
        /// <returns>A single value. (First row's first cell value, if more than one row and column is returned.)</returns>
        public object ExecuteScalar(string commandText, DBParameterCollection paramCollection)
        {
            return ExecuteScalar(commandText, paramCollection, null);
        }

        /// <summary>
        ///  Executes the Sql Command and returns result.
        /// </summary>
        /// <param name="commandText">Sql Command</param>
        /// <param name="paramCollection">Database  Parameter Collection</param>
        /// <param name="transaction">Database Transacion (Use DBHelper.Transaction property.)</param>
        /// <returns></returns>
        public object ExecuteScalar(string commandText, DBParameterCollection paramCollection, IDbTransaction transaction)
        {
            return ExecuteScalar(commandText, paramCollection, transaction, CommandType.Text);
        }
        #endregion ExecuteScalar

        #region ExecuteNonQuery

        /// <summary>
        /// Executes Sql Command or Stored procedure and returns number of rows affected.
        /// </summary>
        /// <param name="commandText">Sql Command or Stored Procedure name</param>
        /// <param name="commandType">Type of command (i.e. Sql Command/ Stored Procedure name/ Table Direct)</param>
        /// <returns>Number of rows affected.</returns>
        public int ExecuteNonQuery(string commandText, CommandType commandType)
        {
            return ExecuteNonQuery(commandText, (IDbTransaction)null, commandType);
        }


        /// <summary>
        /// Executes Sql Command or Stored procedure and returns number of rows affected.
        /// </summary>
        /// <param name="commandText">Sql Command or Stored Procedure name</param>
        /// <param name="transaction">Current Database Transaction (Use Helper.Transaction to get transaction)</param>
        /// <param name="commandType">Type of command (i.e. Sql Command/ Stored Procedure name/ Table Direct)</param>
        /// <returns>Number of rows affected.</returns>
        public int ExecuteNonQuery(string commandText, IDbTransaction transaction, CommandType commandType)
        {
            return ExecuteNonQuery(commandText, new DBParameterCollection(), transaction, commandType);
        }

        /// <summary>
        /// Executes Sql Command or Stored procedure and returns number of rows affected.
        /// </summary>
        /// <param name="commandText">Sql Command or Stored Procedure name</param>
        /// <param name="param">Parameter to be associated with the command</param>
        /// <param name="commandType">Type of command (i.e. Sql Command/ Stored Procedure name/ Table Direct)</param>
        /// <returns>Number of rows affected.</returns>
        public int ExecuteNonQuery(string commandText, DBParameter param, CommandType commandType)
        {
            return ExecuteNonQuery(commandText, param, (IDbTransaction)null, commandType);
        }


        /// <summary>
        /// Executes Sql Command or Stored procedure and returns number of rows affected.
        /// </summary>
        /// <param name="commandText">Sql Command </param>
        /// <param name="param">Parameter to be associated with the command</param>
        /// <param name="transaction">Current Database Transaction (Use Helper.Transaction to get transaction)</param>
        /// <param name="commandType">Type of command (i.e. Sql Command/ Stored Procedure name/ Table Direct)</param>
        /// <returns>Number of rows affected.</returns>
        public int ExecuteNonQuery(string commandText, DBParameter param, IDbTransaction transaction, CommandType commandType)
        {
            DBParameterCollection paramCollection = new DBParameterCollection();
            paramCollection.Add(param);
            return ExecuteNonQuery(commandText, paramCollection, transaction, commandType);
        }

        /// <summary>
        /// Executes Sql Command or Stored procedure and returns number of rows effected.
        /// </summary>
        /// <param name="commandText">Sql Command or Stored Procedure name</param>
        /// <param name="paramCollection">Parameter collection to be associated with the command</param>
        /// <param name="commandType">Type of command (i.e. Sql Command/ Stored Procedure name/ Table Direct)</param>
        /// <returns>Number of rows effected.</returns>
        public int ExecuteNonQuery(string commandText, DBParameterCollection paramCollection, CommandType commandType)
        {
            return ExecuteNonQuery(commandText, paramCollection, (IDbTransaction)null, commandType);
        }

        /// <summary>
        /// Executes Sql Command or Stored procedure and returns number of rows affected.
        /// </summary>
        /// <param name="commandText">Sql Command or Stored Procedure Name</param>
        /// <param name="paramCollection">Parameter Collection to be associated with the comman</param>
        /// <param name="transaction">Current Database Transaction (Use Helper.Transaction to get transaction)</param>
        /// <param name="commandType">Type of command (i.e. Sql Command/ Stored Procedure name/ Table Direct)</param>
        /// <returns>Number of rows affected.</returns>
        public int ExecuteNonQuery(string commandText, DBParameterCollection paramCollection, IDbTransaction transaction, CommandType commandType)
        {
            int rowsAffected = 0;
            IDbConnection connection = transaction != null ? transaction.Connection : _connectionManager.GetConnection();
            IDbCommand command = _commandBuilder.GetCommand(commandText, connection, paramCollection, commandType);
            command.Transaction = transaction;

            try
            {
                rowsAffected = command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                ParameterHelperCommon oParameterHelperCommonDestination = new ParameterHelperCommon();
                oParameterHelperCommonDestination.Dmain = "AKU";
                string LoggingSiteUrl = System.Configuration.ConfigurationSettings.AppSettings["LoggingSiteURL"].ToString();
                oParameterHelperCommonDestination.URL = LoggingSiteUrl;
                string LoggingListName = System.Configuration.ConfigurationSettings.AppSettings["LoggingListName"].ToString();
                oParameterHelperCommonDestination.ListName = LoggingListName;



                Hashtable tblitem = new Hashtable();
                tblitem.Add("Title", "DBHelper (ExecuteNonQuery)");
                tblitem.Add("Exception", ex.Message);
                if (ex.StackTrace != null)
                {
                    tblitem.Add("StackTrace", ex.StackTrace);
                }
                if (ex.InnerException != null)
                {
                    tblitem.Add("InnerException", ex.InnerException);
                }
                bool IsSaved = SPClientHelper.AddItem(oParameterHelperCommonDestination, tblitem);
                throw ex;
            }
            finally
            {
                if (transaction == null)
                {
                    if (connection != null)
                    {
                        connection.Close();
                        connection.Dispose();
                    }
                }
                if (command != null)
                    command.Dispose();
            }
            return rowsAffected;
        }

        /// <summary>
        /// Executes Sql Command and returns number of rows effected.
        /// </summary>
        /// <param name="commandText">Sql Command</param>
        /// <returns>Number of rows effected.</returns>
        public int ExecuteNonQuery(string commandText)
        {
            return ExecuteNonQuery(commandText, (IDbTransaction)null);
        }


        /// <summary>
        /// Executes Sql Command and returns number of rows affected.
        /// </summary>
        /// <param name="commandText">Sql Command</param>
        /// <param name="transaction">Current Database Transaction (Use Helper.Transaction to get transaction)</param>
        /// <returns>Number of rows affected.</returns>
        public int ExecuteNonQuery(string commandText, IDbTransaction transaction)
        {
            return ExecuteNonQuery(commandText, transaction, CommandType.Text);
        }

        /// <summary>
        /// Executes Sql Command and returns number of rows effected.
        /// </summary>
        /// <param name="commandText">Sql Command</param>
        /// <param name="param">Parameter to be associated with the command</param>
        /// <returns>Number of rows effected.</returns>
        public int ExecuteNonQuery(string commandText, DBParameter param)
        {
            return ExecuteNonQuery(commandText, param, (IDbTransaction)null);
        }

        /// <summary>
        /// Executes Sql Command or Stored procedure and returns number of rows affected.
        /// </summary>
        /// <param name="commandText">Sql Command</param>
        /// <param name="param">Parameter to be associated with the command</param>
        /// <param name="transaction">Current Database Transaction (Use Helper.Transaction to get transaction)</param>
        /// <returns>Number of rows affected.</returns>
        public int ExecuteNonQuery(string commandText, DBParameter param, IDbTransaction transaction)
        {
            return ExecuteNonQuery(commandText, param, transaction, CommandType.Text);
        }

        /// <summary>
        /// Executes Sql Command and returns number of rows effected.
        /// </summary>
        /// <param name="commandText">Sql Command</param>
        /// <param name="paramCollection">Parameter Collection to be associated with the command</param>
        /// <returns>Number of rows effected.</returns>
        public int ExecuteNonQuery(string commandText, DBParameterCollection paramCollection)
        {
            return ExecuteNonQuery(commandText, paramCollection, (IDbTransaction)null);
        }


        /// <summary>
        /// Executes Sql Command and returns number of rows affected.
        /// </summary>
        /// <param name="commandText">Sql Command</param>
        /// <param name="paramCollection">Parameter Collection to be associated with the command</param>
        /// <param name="transaction">Current Database Transaction (Use Helper.Transaction to get transaction)</param>
        /// <returns>Number of rows affected.</returns>
        public int ExecuteNonQuery(string commandText, DBParameterCollection paramCollection, IDbTransaction transaction)
        {
            return ExecuteNonQuery(commandText, paramCollection, transaction, CommandType.Text);
        }
        #endregion

        #region GetDataSet

        /// <summary>
        /// Executes the Sql Command or Stored Procedure and return resultset in the form of DataSet.
        /// </summary>
        /// <param name="commandText">Sql Command or Stored Procedure name</param>
        /// <param name="param">Parameter to be associated with the command</param>
        /// <param name="commandType">Type of command (i.e. Sql Command/ Stored Procedure name/ Table Direct)</param>
        /// <returns>Result in the form of DataSet</returns>
        public DataSet ExecuteDataSet(string commandText, DBParameter param, CommandType commandType)
        {
            DBParameterCollection paramCollection = new DBParameterCollection();
            paramCollection.Add(param);
            return ExecuteDataSet(commandText, paramCollection, commandType);
        }


        /// <summary>
        /// Executes the Sql Command or Stored Procedure and return resultset in the form of DataSet.
        /// </summary>
        /// <param name="commandText">Sql Command or Stored Procedure name</param>
        /// <param name="paramCollection">Parameter collection to be associated with the command</param>
        /// <param name="commandType">Type of command (i.e. Sql Command/ Stored Procedure name/ Table Direct)</param>
        /// <returns>Result in the form of DataSet</returns>
        public DataSet ExecuteDataSet(string commandText, DBParameterCollection paramCollection, CommandType commandType)
        {
            DataSet dataSet = new DataSet();
            IDbConnection connection = _connectionManager.GetConnection();
            IDataAdapter adapter = _dbAdapterManager.GetDataAdapter(commandText, connection, paramCollection, commandType);

            try
            {
                adapter.Fill(dataSet);
            }
            catch (Exception ex)
            {
                ParameterHelperCommon oParameterHelperCommonDestination = new ParameterHelperCommon();
                oParameterHelperCommonDestination.Dmain = "AKU";
                string LoggingSiteUrl = System.Configuration.ConfigurationSettings.AppSettings["LoggingSiteURL"].ToString();
                oParameterHelperCommonDestination.URL = LoggingSiteUrl;
                string LoggingListName = System.Configuration.ConfigurationSettings.AppSettings["LoggingListName"].ToString();
                oParameterHelperCommonDestination.ListName = LoggingListName;



                Hashtable tblitem = new Hashtable();
                tblitem.Add("Title", "DBHelper(ExecuteDataSet)");
                tblitem.Add("Exception", ex.Message);
                if (ex.StackTrace != null)
                {
                    tblitem.Add("StackTrace", ex.StackTrace);
                }
                if (ex.InnerException != null)
                {
                    tblitem.Add("InnerException", ex.InnerException);
                }
                bool IsSaved = SPClientHelper.AddItem(oParameterHelperCommonDestination, tblitem);
                throw ex;
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                    connection.Dispose();
                }

            }
            return dataSet;
        }

        /// <summary>
        /// Executes the Sql Command or Stored Procedure and return resultset in the form of DataSet.
        /// </summary>
        /// <param name="commandText">Sql Command or Stored Procedure name</param>
        /// <param name="commandType">Type of command (i.e. Sql Command/ Stored Procedure name/ Table Direct)</param>
        /// <returns>Result in the form of DataSet</returns>
        public DataSet ExecuteDataSet(string commandText, CommandType commandType)
        {
            return ExecuteDataSet(commandText, new DBParameterCollection(), commandType);
        }




        /// <summary>
        /// Executes the Sql Command and return resultset in the form of DataSet.
        /// </summary>
        /// <param name="commandText">Sql Command </param>
        /// <returns>Result in the form of DataSet</returns>
        public DataSet ExecuteDataSet(string commandText)
        {
            return ExecuteDataSet(commandText, new DBParameterCollection(), CommandType.Text);
        }


        /// <summary>
        /// Executes the Sql Command and return resultset in the form of DataSet.
        /// </summary>
        /// <param name="commandText">Sql Command </param>
        /// <param name="param">Parameter to be associated with the command</param>
        /// <returns>Result in the form of DataSet</returns>
        public DataSet ExecuteDataSet(string commandText, DBParameter param)
        {
            DBParameterCollection paramCollection = new DBParameterCollection();
            paramCollection.Add(param);
            return ExecuteDataSet(commandText, paramCollection);
        }



        /// <summary>
        /// Executes the Sql Command and return resultset in the form of DataSet.
        /// </summary>
        /// <param name="commandText">Sql Command </param>
        /// <param name="paramCollection">Parameter collection to be associated with the command</param>
        /// <returns>Result in the form of DataSet</returns>
        public DataSet ExecuteDataSet(string commandText, DBParameterCollection paramCollection)
        {
            return ExecuteDataSet(commandText, paramCollection, CommandType.Text);
        }
        #endregion

        #region "ExecuteDataTable"


        //public DataTable ExecuteDataTable(OraMethodParameterHelper methodParameterHelper)
        //{
        //    try
        //    {
        //        DataTable dtSource = null;
        //        odbcommand = getdbCommand(methodParameterHelper);
        //        db = SetParameters(methodParameterHelper, odbcommand);
        //        DataSet ds = db.ExecuteDataSet(odbcommand);
        //        if (ds.Tables.Count > 0)
        //        {
        //            dtSource = ds.Tables[0];

        //        }
        //        return dtSource;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}


        /// <summary>
        /// Executes the Sql Command or Stored Procedure and return resultset in the form of DataTable.
        /// </summary>
        /// <param name="commandText">Sql Command or Stored Procedure name</param>
        /// <param name="tableName">Table name</param>
        /// <param name="paramCollection">Parameter collection to be associated with the Command or Stored Procedure.</param>
        /// <param name="commandType">Type of command (i.e. Sql Command/ Stored Procedure name/ Table Direct)</param>
        /// <returns>Result in the form of DataTable</returns>
        public DataTable ExecuteDataTable(string commandText, string tableName, DBParameterCollection paramCollection, CommandType commandType)
        {
            DataTable dtReturn = new DataTable();
            IDbConnection connection = null;
            try
            {
                connection = _connectionManager.GetConnection();
                dtReturn = _dbAdapterManager.GetDataTable(commandText, paramCollection, connection, tableName, commandType);
            }
            catch (Exception ex)
            {
                ParameterHelperCommon oParameterHelperCommonDestination = new ParameterHelperCommon();
                oParameterHelperCommonDestination.Dmain = "AKU";
                string LoggingSiteUrl = System.Configuration.ConfigurationSettings.AppSettings["LoggingSiteURL"].ToString();
                oParameterHelperCommonDestination.URL = LoggingSiteUrl;
                string LoggingListName = System.Configuration.ConfigurationSettings.AppSettings["LoggingListName"].ToString();
                oParameterHelperCommonDestination.ListName = LoggingListName;



                Hashtable tblitem = new Hashtable();
                tblitem.Add("Title", "DBHelper(ExecuteDataTable)");
                tblitem.Add("Exception", ex.Message);
                if (ex.StackTrace != null)
                {
                    tblitem.Add("StackTrace", ex.StackTrace);
                }
                if (ex.InnerException != null)
                {
                    tblitem.Add("InnerException", ex.InnerException);
                }
                bool IsSaved = SPClientHelper.AddItem(oParameterHelperCommonDestination, tblitem);
                throw ex;
            }
            finally
            {
                if (connection != null)
                {
                    connection.Close();
                    connection.Dispose();
                }

            }
            return dtReturn;
        }

        /// <summary>
        /// Executes the Sql Command or Stored Procedure and return resultset in the form of DataTable.
        /// </summary>
        /// <param name="commandText">Sql Command8 or Stored Procedure name</param>
        /// <param name="paramCollection">Parameter collection to be associated with the Command or Stored Procedure.</param>
        /// <param name="commandType">Type of command (i.e. Sql Command/ Stored Procedure name/ Table Direct)</param>
        /// <returns>Result in the form of DataTable</returns>
        public DataTable ExecuteDataTable(string commandText, DBParameterCollection paramCollection, CommandType commandType)
        {
            return ExecuteDataTable(commandText, string.Empty, paramCollection, commandType);
        }

        /// <summary>
        /// Executes the Sql Command and return resultset in the form of DataTable.
        /// </summary>
        /// <param name="commandText">Sql Command</param>
        /// <param name="tableName">Table name</param>
        /// <param name="paramCollection">Parameter collection to be associated with the Command.</param>
        /// <returns>Result in the form of DataTable</returns>
        public DataTable ExecuteDataTable(string commandText, string tableName, DBParameterCollection paramCollection)
        {
            return ExecuteDataTable(commandText, tableName, paramCollection, CommandType.Text);
        }

        /// <summary>
        /// Executes the Sql Command and return resultset in the form of DataTable.
        /// </summary>
        /// <param name="commandText">Sql Command</param>
        /// <param name="paramCollection">Parameter collection to be associated with the Command.</param>
        /// <returns>Result in the form of DataTable</returns>
        public DataTable ExecuteDataTable(string commandText, DBParameterCollection paramCollection)
        {
            return ExecuteDataTable(commandText, string.Empty, paramCollection, CommandType.Text);
        }


        /// <summary>
        /// Executes the Sql Command or Stored Procedure and return resultset in the form of DataTable.
        /// </summary>
        /// <param name="commandText">Sql Command or Stored Procedure Name</param>
        /// <param name="tableName">Table name</param>
        /// <param name="param">Parameter to be associated with the Command.</param>
        /// <param name="commandType">Type of command (i.e. Sql Command/ Stored Procedure name/ Table Direct)</param>
        /// <returns>Result in the form of DataTable</returns>
        public DataTable ExecuteDataTable(string commandText, string tableName, DBParameter param, CommandType commandType)
        {
            DBParameterCollection paramCollection = new DBParameterCollection();
            paramCollection.Add(param);
            return ExecuteDataTable(commandText, tableName, paramCollection, commandType);
        }

        /// <summary>
        /// Executes the Sql Command or Stored Procedure and return resultset in the form of DataTable.
        /// </summary>
        /// <param name="commandText">Sql Command or Stored Procedure Name</param>        
        /// <param name="param">Parameter to be associated with the Command.</param>
        /// <param name="commandType">Type of command (i.e. Sql Command/ Stored Procedure name/ Table Direct)</param>
        /// <returns>Result in the form of DataTable</returns>
        public DataTable ExecuteDataTable(string commandText, DBParameter param, CommandType commandType)
        {
            return ExecuteDataTable(commandText, string.Empty, param, commandType);
        }

        /// <summary>
        /// Executes the Sql Command and return resultset in the form of DataTable.
        /// </summary>
        /// <param name="commandText">Sql Command</param>        
        /// <param name="tableName">Table name</param>
        /// <param name="param">Parameter to be associated with the Command.</param>
        /// <returns>Result in the form of DataTable</returns>
        public DataTable ExecuteDataTable(string commandText, string tableName, DBParameter param)
        {
            return ExecuteDataTable(commandText, tableName, param, CommandType.Text);
        }

        /// <summary>
        /// Executes the Sql Command and return resultset in the form of DataTable.
        /// </summary>
        /// <param name="commandText">Sql Command</param>        
        /// <param name="param">Parameter to be associated with the Command.</param>
        /// <returns>Result in the form of DataTable</returns>
        public DataTable ExecuteDataTable(string commandText, DBParameter param)
        {
            return ExecuteDataTable(commandText, string.Empty, param, CommandType.Text);
        }

        /// <summary>
        /// Executes the Sql Command or Stored Procedure and return resultset in the form of DataTable.
        /// </summary>
        /// <param name="commandText">Sql Command or Stored Procedure Name</param>        
        /// <param name="tableName">Table name</param>
        /// <param name="commandType">Type of command (i.e. Sql Command/ Stored Procedure name/ Table Direct)</param>
        /// <returns>Result in the form of DataTable</returns>
        public DataTable ExecuteDataTable(string commandText, string tableName, CommandType commandType)
        {
            return ExecuteDataTable(commandText, tableName, new DBParameterCollection(), commandType);
        }

        /// <summary>
        /// Executes the Sql Command or Stored Procedure and return resultset in the form of DataTable.
        /// </summary>
        /// <param name="commandText">Sql Command or Stored Procedure Name</param>        
        /// <param name="commandType">Type of command (i.e. Sql Command/ Stored Procedure name/ Table Direct)</param>
        /// <returns>Result in the form of DataTable</returns>
        public DataTable ExecuteDataTable(string commandText, CommandType commandType)
        {
            return ExecuteDataTable(commandText, string.Empty, commandType);
        }

        /// <summary>
        /// Executes the Sql Command and return resultset in the form of DataTable.
        /// </summary>
        /// <param name="commandText">Sql Command</param>        
        /// <param name="tableName">Table name</param>
        /// <returns>Result in the form of DataTable</returns>
        public DataTable ExecuteDataTable(string commandText, string tableName)
        {
            return ExecuteDataTable(commandText, tableName, CommandType.Text);
        }

        /// <summary>
        /// Executes the Sql Command and return resultset in the form of DataTable.
        /// </summary>
        /// <param name="commandText">Sql Command</param>   
        /// <returns>Result in the form of DataTable</returns>
        public DataTable ExecuteDataTable(string commandText)
        {
            return ExecuteDataTable(commandText, string.Empty, CommandType.Text);
        }
        #endregion

        #region "ExecuteReader"
        /// <summary>
        /// Executes the Sql Command or Stored Procedure and returns the DataReader.
        /// </summary>
        /// <param name="commandText">Sql Command or Stored Procedure Name</param>        
        /// <param name="con">Database Connection object (DBHelper.GetConnObject() may be used)</param>
        /// <param name="commandType">Type of command (i.e. Sql Command/ Stored Procedure name/ Table Direct)</param>
        /// <returns>DataReader</returns>
        public IDataReader ExecuteDataReader(string commandText, IDbConnection connection, CommandType commandType)
        {
            return ExecuteDataReader(commandText, connection, new DBParameterCollection(), commandType);
        }

        /// <summary>
        /// Executes the Sql Command and returns the DataReader.
        /// </summary>
        /// <param name="commandText">Sql Command</param>        
        /// <param name="con">Database Connection object (DBHelper.GetConnObject() may be used)</param>
        /// <returns>DataReader</returns>
        public IDataReader ExecuteDataReader(string commandText, IDbConnection connection)
        {
            return ExecuteDataReader(commandText, connection, CommandType.Text);
        }

        /// <summary>
        /// Executes the Sql Command or Stored Procedure and returns the DataReader.
        /// </summary>
        /// <param name="commandText">Sql Command or Stored Procedure Name</param>        
        /// <param name="con">Database Connection object (DBHelper.GetConnObject() may be used)</param>
        /// <param name="param">Parameter to be associated with the Sql Command or Stored Procedure.</param>
        /// <param name="commandType">Type of command (i.e. Sql Command/ Stored Procedure name/ Table Direct)</param>
        /// <returns>DataReader</returns>
        public IDataReader ExecuteDataReader(string commandText, IDbConnection connection, DBParameter param, CommandType commandType)
        {
            DBParameterCollection paramCollection = new DBParameterCollection();
            paramCollection.Add(param);
            return ExecuteDataReader(commandText, connection, paramCollection, commandType);
        }

        /// <summary>
        /// Executes the Sql Command and returns the DataReader.
        /// </summary>
        /// <param name="commandText">Sql Command</param>        
        /// <param name="con">Database Connection object (DBHelper.GetConnObject() may be used)</param>
        /// <param name="param">Parameter to be associated with the Sql Command.</param>
        /// <returns>DataReader</returns>
        public IDataReader ExecuteDataReader(string commandText, IDbConnection connection, DBParameter param)
        {
            return ExecuteDataReader(commandText, connection, param, CommandType.Text);
        }

        /// <summary>
        /// Executes the Sql Command and returns the DataReader.
        /// </summary>
        /// <param name="commandText">Sql Command</param>        
        /// <param name="con">Database Connection object (DBHelper.GetConnObject() may be used)</param>
        /// <param name="paramCollection">Parameter to be associated with the Sql Command or Stored Procedure.</param>
        /// <returns>DataReader</returns>
        public IDataReader ExecuteDataReader(string commandText, IDbConnection connection, DBParameterCollection paramCollection)
        {
            return ExecuteDataReader(commandText, connection, paramCollection, CommandType.Text);
        }


        /// <summary>
        /// Executes the Sql Command or Stored Procedure and returns the DataReader.
        /// </summary>
        /// <param name="commandText">Sql Command or Stored Procedure Name</param>        
        /// <param name="con">Database Connection object (DBHelper.GetConnObject() may be used)</param>
        /// <param name="paramCollection">Parameter to be associated with the Sql Command or Stored Procedure.</param>
        /// <param name="commandType">Type of command (i.e. Sql Command/ Stored Procedure name/ Table Direct)</param>
        /// <returns>DataReader</returns>
        public IDataReader ExecuteDataReader(string commandText, IDbConnection connection, DBParameterCollection paramCollection, CommandType commandType)
        {
            IDataReader dataReader = null;
            IDbCommand command = _commandBuilder.GetCommand(commandText, connection, paramCollection, commandType);
            dataReader = command.ExecuteReader();
            command.Dispose();
            return dataReader;
        }


        /// <summary>
        /// Executes the Sql Command and returns the IDataReader. Do remember to Commit or Rollback the transaction
        /// </summary>
        /// <param name="commandText">Sql Command</param>
        /// <param name="param">Database Parameter</param>
        /// <param name="transaction">Database Transaction (Use DBHelper.Transaction property for getting the transaction.)</param>
        /// <returns>Data Reader</returns>
        public IDataReader ExecuteDataReader(string commandText, DBParameter param, IDbTransaction transaction)
        {
            return ExecuteDataReader(commandText, param, transaction, CommandType.Text);
        }

        /// <summary>
        /// Executes the Sql Command or Stored Procedure and returns the IDataReader. Do remember to Commit or Rollback the transaction
        /// </summary>
        /// <param name="commandText">Sql Command or Stored Proc Name</param>
        /// <param name="param">Database Parameter</param>
        /// <param name="transaction">Database Transaction (Use DBHelper.Transaction property for getting the transaction.)</param>
        /// <param name="commandType">Text/ Stored Procedure</param>
        /// <returns>IDataReader</returns>
        public IDataReader ExecuteDataReader(string commandText, DBParameter param, IDbTransaction transaction, CommandType commandType)
        {
            DBParameterCollection paramCollection = new DBParameterCollection();
            paramCollection.Add(param);
            return ExecuteDataReader(commandText, paramCollection, transaction, commandType);
        }

        /// <summary>
        /// Executes the Sql Command and returns the IDataReader. Do remember to Commit or Rollback the transaction
        /// </summary>
        /// <param name="commandText">Sql Command </param>
        /// <param name="paramCollection">Database Parameter Collection</param>
        /// <param name="transaction">Database Transaction (Use DBHelper.Transaction property for getting the transaction.)</param>
        /// <returns>IDataReader</returns>
        public IDataReader ExecuteDataReader(string commandText, DBParameterCollection paramCollection, IDbTransaction transaction)
        {
            return ExecuteDataReader(commandText, paramCollection, transaction, CommandType.Text);
        }


        /// <summary>
        /// Executes the Sql Command or Stored Procedure and returns the IDataReader. Do remember to Commit or Rollback the transaction
        /// </summary>
        /// <param name="commandText">Sql Command or Stored Proc name</param>
        /// <param name="paramCollection">Database Parameter Collection</param>
        /// <param name="transaction">Database Transaction (Use DBHelper.Transaction property for getting the transaction.)</param>
        /// <param name="commandType">Text/ Stored Procedure</param>
        /// <returns>IDataReader</returns>
        public IDataReader ExecuteDataReader(string commandText, DBParameterCollection paramCollection, IDbTransaction transaction, CommandType commandType)
        {
            IDataReader dataReader = null;
            IDbConnection connection = transaction.Connection;
            IDbCommand command = _commandBuilder.GetCommand(commandText, connection, paramCollection, commandType);
            command.Transaction = transaction;
            dataReader = command.ExecuteReader();
            command.Dispose();
            return dataReader;
        }

        #endregion

        #region "Methods to Prepare the Commands"

        /// <summary>
        /// Prepares command for the passed SQL Command Or Stored Procedure. 
        /// Use DisposeCommand method after use of the command.
        /// </summary>
        /// <param name="commandText">SQL Command or Stored Procedure name</param>
        /// <param name="commandType">Type of Command i.e. Text or Stored Procedure</param>
        /// <returns>Command ready for execute</returns>
        public IDbCommand GetCommand(string commandText, CommandType commandType)
        {
            IDbConnection connection = _connectionManager.GetConnection();
            IDbCommand command = _commandBuilder.GetCommand(commandText, connection, commandType);
            return command;
        }


        public IDbCommand GetCommand(string commandText, IDbTransaction transaction, CommandType commandType)
        {
            IDbConnection connection = transaction != null ? transaction.Connection : _connectionManager.GetConnection();
            IDbCommand command = _commandBuilder.GetCommand(commandText, connection, commandType);
            return command;
        }
        /// <summary>
        /// Prepares command for the passed SQL Command.
        /// Command is prepared for SQL Command only not for the stored procedures.
        /// Use DisposeCommand method after use of the command.
        /// </summary>
        /// <param name="commandText">SQL Command</param>        
        /// <returns>Command ready for execute</returns>
        public IDbCommand GetCommand(string commandText)
        {
            return GetCommand(commandText, CommandType.Text);
        }

        public IDbCommand GetCommand(string commandText, IDbTransaction transaction)
        {
            return GetCommand(commandText, transaction, CommandType.Text);
        }

        /// <summary>
        /// Prepares command for the passed SQL Command or Stored Procedure.
        /// Command is prepared for SQL Command only not for the stored procedures.
        /// Use DisposeCommand method after use of the command.
        /// </summary>
        /// <param name="commandText">SQL Command or Stored Procedure name</param>
        /// <param name="parameter">Database parameter</param>
        /// <param name="commandType">Type of Command i.e. Text or Stored Procedure</param>
        /// <returns>Command ready for execute</returns>
        public IDbCommand GetCommand(string commandText, DBParameter parameter, CommandType commandType)
        {
            IDbConnection connection = _connectionManager.GetConnection();
            IDbCommand command = _commandBuilder.GetCommand(commandText, connection, parameter, commandType);
            return command;
        }

        /// <summary>
        /// Prepares command for the passed SQL Command.
        /// Command is prepared for SQL Command only not for the stored procedures.
        /// Use DisposeCommand method after use of the command.
        /// </summary>
        /// <param name="commandText">SQL Command</param>
        /// <param name="parameter">Database parameter</param>
        /// <returns>Command ready for execute</returns>
        public IDbCommand GetCommand(string commandText, DBParameter parameter)
        {
            return GetCommand(commandText, parameter, CommandType.Text);
        }


        public IDbCommand GetCommand(string commandText, DBParameter parameter, IDbTransaction transaction)
        {
            DBParameterCollection paramCollection = new DBParameterCollection();
            paramCollection.Add(parameter);
            return GetCommand(commandText, paramCollection, transaction, CommandType.Text);
        }

        /// <summary>
        /// Prepares command for the passed SQL Command or Stored Procedure.
        /// Command is prepared for SQL Command only not for the stored procedures. 
        /// Use DisposeCommand method after use of the command.
        /// </summary>
        /// <param name="commandText">SQL Command or Stored Procedure name</param>
        /// <param name="parameterCollection">Database parameter collection</param>
        /// <param name="commandType">Type of Command i.e. Text or Stored Procedure</param>
        /// <returns>Command ready for execute</returns>
        public IDbCommand GetCommand(string commandText, DBParameterCollection parameterCollection, CommandType commandType)
        {
            IDbConnection connection = _connectionManager.GetConnection();
            IDbCommand command = _commandBuilder.GetCommand(commandText, connection, parameterCollection, commandType);
            return command;
        }

        /// <summary>
        /// Prepares command for the passed SQL Command or Stored Procedure.        
        /// Use DisposeCommand method after use of the command.
        /// </summary>
        /// <param name="commandText"></param>
        /// <param name="parameterCollection"></param>
        /// <param name="transaction"></param>
        /// <param name="commandType"></param>
        /// <returns></returns>
        public IDbCommand GetCommand(string commandText, DBParameterCollection parameterCollection, IDbTransaction transaction, CommandType commandType)
        {
            IDbConnection connection = transaction != null ? transaction.Connection : _connectionManager.GetConnection();
            IDbCommand command = _commandBuilder.GetCommand(commandText, connection, parameterCollection, commandType);
            return command;
        }

        /// <summary>
        /// Prepares command for the passed SQL Command.
        /// Command is prepared for SQL Command only not for the stored procedures.
        /// Use DisposeCommand method after use of the command.
        /// </summary>
        /// <param name="commandText">SQL Command</param>
        /// <param name="parameterCollection">Database parameter collection</param>
        /// <returns>Command ready for execute</returns>
        public IDbCommand GetCommand(string commandText, DBParameterCollection parameterCollection)
        {
            return GetCommand(commandText, parameterCollection, CommandType.Text);
        }

        public IDbCommand GetCommand(string commandText, DBParameterCollection parameterCollection, IDbTransaction transaction)
        {
            return GetCommand(commandText, parameterCollection, transaction, CommandType.Text);
        }

        #endregion

        #region "Methods To Retrieve the Parameter Values"

        /// <summary>
        /// Returns the database parameter value from the specified command
        /// </summary>
        /// <param name="parameterName">Name of the parameter</param>
        /// <param name="command">Command from which value to be retrieved</param>
        /// <returns>Parameter value</returns>
        public object GetParameterValue(string parameterName, IDbCommand command)
        {
            object retValue = null;
            IDataParameter param = (IDataParameter)command.Parameters[parameterName];
            retValue = param.Value;
            return retValue;
        }

        /// <summary>
        /// Returns the database parameter value from the specified command
        /// </summary>
        /// <param name="index">Index of the parameter</param>
        /// <param name="command">Command from which value to be retrieved</param>
        /// <returns>Parameter value</returns>
        public object GetParameterValue(int index, IDbCommand command)
        {
            object retValue = null;
            IDataParameter param = (IDataParameter)command.Parameters[index];
            retValue = param.Value;
            return retValue;
        }

        #endregion

        #region "Methods to Dispose the Command"

        /// <summary>
        /// Closes and Disposes the Connection associated and then disposes the command.
        /// </summary>
        /// <param name="command">Command which needs to be closed</param>
        public void DisposeCommand(IDbCommand command)
        {
            if (command == null)
                return;

            if (command.Connection != null)
            {
                command.Connection.Close();
                command.Connection.Dispose();
            }

            command.Dispose();
        }

        #endregion

        /// <summary>
        /// Creates and opens the database connection for the connection parameters specified into web.config or App.config file.
        /// </summary>
        /// <returns>Database connection object in the opened state. </returns>
        public IDbConnection GetConnObject()
        {
            return _connectionManager.GetConnection();
        }

        public DbCommand getdbCommand(OraMethodParameterHelper methodParameterHelper)
        {
            odbcommand = db.GetStoredProcCommand(methodParameterHelper.CommandText);
            return odbcommand;
        }
        public Database SetParameters(OraMethodParameterHelper methodParameterHelper, DbCommand odbcmd)
        {

            if (methodParameterHelper.Parameters != null)
            {

                foreach (OraParameter param in methodParameterHelper.Parameters)
                {
                    if (param.ParameterType == OraParameter.DataType.sys_refcursor)
                    {
                        db.AddCursorOutParameter(odbcmd, param.Name);


                    }

                    else if (param.ParameterDir == OraParameter.ParameterDirection.OUT)
                    {
                        db.AddOutParameter(odbcmd, param.Name, GetDBType(param), param.Size);
                    }


                    else if (param.ParameterDir == OraParameter.ParameterDirection.IN)
                    {

                        db.AddInParameter(odbcmd, param.Name, GetDBType(param), param.Value);

                    }

                }


            }
            return db;
        }
        private DbType GetDBType(OraParameter oraparam)
        {
            //OracleDbType oradbtype = OracleDbType.Varchar2;
            DbType dbtype = DbType.String;

            if (oraparam.ParameterType == OraParameter.DataType.number)
            {
                dbtype = DbType.VarNumeric;
            }
            else if (oraparam.ParameterType == OraParameter.DataType.varchar2)
            {
                dbtype = DbType.AnsiString;
            }
            else if (oraparam.ParameterType == OraParameter.DataType.Date)
            {
                dbtype = DbType.DateTime;
            }
            else if (oraparam.ParameterType == OraParameter.DataType.floating)
            {
                dbtype = DbType.Decimal;

            }

            else if (oraparam.ParameterType == OraParameter.DataType.clob)
            {
                //  System.Data.OracleClient.OracleType
                dbtype = DbType.Binary;

            } return dbtype;

        }
        private static OracleDbType GetOracleDBType(OraParameter oraparam)
        {
            OracleDbType dbtype = OracleDbType.Varchar2;

            if (oraparam.ParameterType == OraParameter.DataType.number)
            {
                dbtype = OracleDbType.Int32;
            }
            else if (oraparam.ParameterType == OraParameter.DataType.varchar2)
            {
                dbtype = OracleDbType.Varchar2;
            }
            else if (oraparam.ParameterType == OraParameter.DataType.Date)
            {
                dbtype = OracleDbType.Date;
            }
            else if (oraparam.ParameterType == OraParameter.DataType.floating)
            {
                dbtype = OracleDbType.Decimal;


            }
            else if (oraparam.ParameterType == OraParameter.DataType.sys_refcursor)
            {
                dbtype = OracleDbType.RefCursor;
            }
            else if (oraparam.ParameterType == OraParameter.DataType.clob)
            {
                dbtype = OracleDbType.Clob;

            } return dbtype;

        }
        private static ParameterDirection GetOracleParameterDirection(OraParameter oraparam)
        {
            ParameterDirection dbtype = (oraparam.ParameterDir == OraParameter.ParameterDirection.IN ? ParameterDirection.Input : ParameterDirection.Output);
            return dbtype;
        }
        public DataTable GetDataTable(OraMethodParameterHelper methodParameterHelper)
        {
            try
            {
                DataTable dtSource = null;
                odbcommand = getdbCommand(methodParameterHelper);
                db = SetParameters(methodParameterHelper, odbcommand);

                DataSet ds = db.ExecuteDataSet(odbcommand);
                if (ds.Tables.Count > 0)
                {
                    dtSource = ds.Tables[0];

                }
                return dtSource;
            }
            catch (Exception ex)
            {
                ParameterHelperCommon oParameterHelperCommonDestination = new ParameterHelperCommon();
                oParameterHelperCommonDestination.Dmain = "AKU";
                string LoggingSiteUrl = System.Configuration.ConfigurationSettings.AppSettings["LoggingSiteURL"].ToString();
                oParameterHelperCommonDestination.URL = LoggingSiteUrl;
                string LoggingListName = System.Configuration.ConfigurationSettings.AppSettings["LoggingListName"].ToString();
                oParameterHelperCommonDestination.ListName = LoggingListName;



                Hashtable tblitem = new Hashtable();
                tblitem.Add("Title", "DBHelper");
                tblitem.Add("Exception", ex.Message);
                if (ex.StackTrace != null)
                {
                    tblitem.Add("StackTrace", ex.StackTrace);
                }
                if (ex.InnerException != null)
                {
                    tblitem.Add("InnerException", ex.InnerException);
                }
                bool IsSaved = SPClientHelper.AddItem(oParameterHelperCommonDestination, tblitem);
                throw ex;
            }
        }
        public static OracleCommand SetParametersForOracle(OraMethodParameterHelper methodParameterHelper, OracleCommand odbcmd)
        {

            if (methodParameterHelper.Parameters != null)
            {

                foreach (OraParameter param in methodParameterHelper.Parameters)
                {

                    OracleParameter oParam = new OracleParameter();
                    oParam.ParameterName = param.Name;
                    oParam.OracleDbType = GetOracleDBType(param);
                    oParam.Direction = GetOracleParameterDirection(param);
                    if (param.ParameterType != OraParameter.DataType.sys_refcursor)
                    {
                        oParam.Value = param.Value;
                        oParam.Size = param.Size;
                    }

                    odbcmd.Parameters.Add(oParam);
                }
            }
            return odbcmd;
        }
        public Dictionary<string, Object> getOUTParametersEx(OraMethodParameterHelper methodParameterHelper)
        {
            Dictionary<string, Object> objectOutParameters = new Dictionary<string, Object>();
            odbcommand = getdbCommand(methodParameterHelper);
            if (methodParameterHelper.Parameters != null)
            {
                db = SetParameters(methodParameterHelper, odbcommand);

                db.ExecuteNonQuery(odbcommand);

                foreach (OraParameter parameters in methodParameterHelper.Parameters)
                {
                    if (parameters.ParameterDir == OraParameter.ParameterDirection.OUT)
                    //&& parameters.ParameterType != OraParameter.DataType.sys_refcursor)
                    {
                        if (parameters.ParameterType == OraParameter.DataType.clob)
                        {
                            if (!((OracleClob)(odbcommand.Parameters[parameters.Name].Value)).IsNull)
                            //objectOutParameters.Add(parameters.Name, "empty clob");
                            {
                                objectOutParameters.Add(parameters.Name, ((OracleClob)odbcommand.Parameters[parameters.Name].Value).Value.ToString());
                            }
                            else
                            {
                                objectOutParameters.Add(parameters.Name, string.Empty);
                            }
                        }
                        else
                        {

                            objectOutParameters.Add(parameters.Name, odbcommand.Parameters[parameters.Name].Value);
                        }
                    }

                }
                return objectOutParameters;
                // db.GetParameterValue(odbcommand, paramter.Name);

            }
            return null;
        }
        public object getOUTParameters(OraMethodParameterHelper methodParameterHelper, OraParameter paramter)
        {
            odbcommand = getdbCommand(methodParameterHelper);

            if (methodParameterHelper.Parameters != null)
            {
                db = SetParameters(methodParameterHelper, odbcommand);
                db.ExecuteNonQuery(odbcommand);
                return db.GetParameterValue(odbcommand, paramter.Name);

            }
            return null;
        }
        public static Dictionary<string, Object> GetResults(OraMethodParameterHelper methodParameterHelper)
        {
            //Oracle.DataAccess.Client.
            OracleConnection connection = new OracleConnection(System.Configuration.ConfigurationManager.ConnectionStrings["oracleCon"].ConnectionString);
            try
            {
                Dictionary<string, Object> objectOutParameters = new Dictionary<string, Object>();

                connection.Open();

                //   Oracle.DataAccess.Client.
                OracleCommand command = connection.CreateCommand();
                command.CommandType = CommandType.StoredProcedure;
                command.Connection = connection;
                command.CommandText = methodParameterHelper.CommandText;
                command = SetParametersForOracle(methodParameterHelper, command);

                //   Oracle.DataAccess.Client.
                OracleDataAdapter adapter = new OracleDataAdapter(command);

                DataSet ds = new DataSet();
                adapter.Fill(ds);
                objectOutParameters.Add("Tables", ds);

                foreach (OraParameter parameters in methodParameterHelper.Parameters)
                {
                    if (parameters.ParameterDir == OraParameter.ParameterDirection.OUT && parameters.ParameterType != OraParameter.DataType.sys_refcursor)
                    {
                        if (parameters.ParameterType == OraParameter.DataType.clob)
                        {
                            if (!((OracleClob)(command.Parameters[parameters.Name].Value)).IsNull)
                            //objectOutParameters.Add(parameters.Name, "empty clob");
                            {
                                objectOutParameters.Add(parameters.Name, ((OracleClob)command.Parameters[parameters.Name].Value).Value.ToString());
                            }
                            else
                            {
                                objectOutParameters.Add(parameters.Name, string.Empty);
                            }
                        }
                        else
                        {

                            objectOutParameters.Add(parameters.Name, command.Parameters[parameters.Name].Value);
                        }
                    }

                }
                return objectOutParameters;
            }
            catch (Exception ex)
            {
                ParameterHelperCommon oParameterHelperCommonDestination = new ParameterHelperCommon();
                oParameterHelperCommonDestination.Dmain = "AKU";
                string LoggingSiteUrl = System.Configuration.ConfigurationSettings.AppSettings["LoggingSiteURL"].ToString();
                oParameterHelperCommonDestination.URL = LoggingSiteUrl;
                string LoggingListName = System.Configuration.ConfigurationSettings.AppSettings["LoggingListName"].ToString();
                oParameterHelperCommonDestination.ListName = LoggingListName;



                Hashtable tblitem = new Hashtable();
                tblitem.Add("Title", "DBHelper");
                tblitem.Add("Exception", ex.Message);
                if (ex.StackTrace != null)
                {
                    tblitem.Add("StackTrace", ex.StackTrace);
                }
                if (ex.InnerException != null)
                {
                    tblitem.Add("InnerException", ex.InnerException);
                }
                bool IsSaved = SPClientHelper.AddItem(oParameterHelperCommonDestination, tblitem);
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        }
        public static Dictionary<string, Object> ExecuteQuery(OraMethodParameterHelper methodParameterHelper)
        {
            //Oracle.DataAccess.Client.
            OracleConnection connection = new OracleConnection(System.Configuration.ConfigurationManager.ConnectionStrings["oracleCon"].ConnectionString);
            try
            {
                Dictionary<string, Object> objectOutParameters = new Dictionary<string, Object>();

                connection.Open();

                //   Oracle.DataAccess.Client.
                OracleCommand command = connection.CreateCommand();
                command.CommandType = CommandType.StoredProcedure;
                command.Connection = connection;
                command.CommandText = methodParameterHelper.CommandText;
                command = SetParametersForOracle(methodParameterHelper, command);
                command.ExecuteNonQuery();
                //   Oracle.DataAccess.Client.
                //OracleDataAdapter adapter = new OracleDataAdapter(command);

                //DataSet ds = new DataSet();
                //adapter.Fill(ds);
                //objectOutParameters.Add("Tables", ds);

                foreach (OraParameter parameters in methodParameterHelper.Parameters)
                {
                    if (parameters.ParameterDir == OraParameter.ParameterDirection.OUT && parameters.ParameterType != OraParameter.DataType.sys_refcursor)
                    {
                        if (parameters.ParameterType == OraParameter.DataType.clob)
                        {
                            if (!((OracleClob)(command.Parameters[parameters.Name].Value)).IsNull)
                            //objectOutParameters.Add(parameters.Name, "empty clob");
                            {
                                objectOutParameters.Add(parameters.Name, ((OracleClob)command.Parameters[parameters.Name].Value).Value.ToString());
                            }
                            else
                            {
                                objectOutParameters.Add(parameters.Name, string.Empty);
                            }
                        }
                        else
                        {
                            objectOutParameters.Add(parameters.Name, command.Parameters[parameters.Name].Value);
                        }
                    }

                }
                return objectOutParameters;
            }
            catch (Exception ex)
            {
                ParameterHelperCommon oParameterHelperCommonDestination = new ParameterHelperCommon();
                oParameterHelperCommonDestination.Dmain = "AKU";
                string LoggingSiteUrl = System.Configuration.ConfigurationSettings.AppSettings["LoggingSiteURL"].ToString();
                oParameterHelperCommonDestination.URL = LoggingSiteUrl;
                string LoggingListName = System.Configuration.ConfigurationSettings.AppSettings["LoggingListName"].ToString();
                oParameterHelperCommonDestination.ListName = LoggingListName;



                Hashtable tblitem = new Hashtable();
                tblitem.Add("Title", "DBHelper");
                tblitem.Add("Exception", ex.Message);
                if (ex.StackTrace != null)
                {
                    tblitem.Add("StackTrace", ex.StackTrace);
                }
                if (ex.InnerException != null)
                {
                    tblitem.Add("InnerException", ex.InnerException);
                }
                bool IsSaved = SPClientHelper.AddItem(oParameterHelperCommonDestination, tblitem);
                throw ex;
            }
            finally
            {
                connection.Close();
            }
        }

    }

}
