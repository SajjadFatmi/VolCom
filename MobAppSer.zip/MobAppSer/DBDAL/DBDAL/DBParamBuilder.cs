﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Common;

namespace DBDAL
{
    internal class DBParamBuilder
    {

        private string _providerName = string.Empty;
        private AssemblyProvider _assemblyProvider = null;

        internal DBParamBuilder(string providerName)
        {
            _assemblyProvider = new AssemblyProvider(providerName);
            _providerName = providerName;
        }

        internal DbParameter GetParameter(DBParameter parameter)
        {
            DbParameter dbParam = GetParameter();
            dbParam.ParameterName = parameter.Name;
            dbParam.Value = parameter.Value;
            dbParam.Direction = parameter.ParamDirection;
            dbParam.DbType = parameter.Type;
            dbParam.Size = parameter.Size;
            return dbParam;
        }

        internal List<DbParameter> GetParameterCollection(DBParameterCollection parameterCollection)
        {
            List<DbParameter> dbParamCollection = new List<DbParameter>();
            DbParameter dbParam = null;
            foreach (DBParameter param in parameterCollection.Parameters)
            {
                dbParam = GetParameter(param);
                dbParamCollection.Add(dbParam);
            }

            return dbParamCollection;
        }

        #region Private Methods
        private DbParameter GetParameter()
        {
            DbParameter dbParam = _assemblyProvider.Factory.CreateParameter();
            return dbParam;
        }
        #endregion
    }
}
