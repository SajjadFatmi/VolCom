﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBDAL
{
   public class OraParameter
    {
        public enum DataType { varchar2, sys_refcursor, number, Date, floating, clob }
        public enum ParameterDirection { IN, OUT, INOUT }
        public string Name { get; set; }
        public int Size { get; set; }
        public object Value { get; set; }
        public DataType ParameterType { get; set; }
        public ParameterDirection ParameterDir { get; set; }
    }
}
