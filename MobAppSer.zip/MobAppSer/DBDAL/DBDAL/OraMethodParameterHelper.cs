﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBDAL
{
    public class OraMethodParameterHelper
    {
        public string CommandText { get; set; }
        public List<OraParameter> Parameters { get; set; }
    }
}
