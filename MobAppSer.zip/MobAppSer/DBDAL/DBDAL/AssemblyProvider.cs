﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Common;

namespace DBDAL
{
    internal class AssemblyProvider
    {
        private static AssemblyProvider _assemblyProvider = null;

        private string _providerName = string.Empty;
        
        public AssemblyProvider()
        {
            _providerName = Configuration.GetProviderName(Configuration.DefaultConnection);
        }

        public AssemblyProvider(string providerName)
        {
            _providerName = providerName;
        }

        internal DbProviderFactory Factory
        {
            get
            {
                DbProviderFactory factory = DbProviderFactories.GetFactory(_providerName);
                return factory;
            }
        }
        
    }
}
