(function(window, undefined) {
  var dictionary = {
    "f2c8bd07-c66b-48fc-a1d0-488cd2b73a1d": "Code",
    "8c589268-48bd-4499-8efe-7f05bb962749": "Splash Screen",
    "15327385-027c-43d3-9574-81c1575cd233": "Issue Location",
    "aa5107dc-3bc9-4162-959a-f2dc9fe9b024": "Issue Details",
    "62fdcfb7-ff96-46ed-8cb4-48762adf46d0": "Connect Home",
    "63332fb1-af7f-4838-8a8d-aa2e02c4bc8e": "Main",
    "907362bc-0e8f-4398-9d6b-262b2cda5b2a": "Issue Types",
    "e39c40d2-862d-4660-9575-4fd5cf1a7a62": "Registeration",
    "4adf2520-df2e-45c4-be27-9d6c5086436f": "Issue Home",
    "0264db86-b859-4d83-9ee3-cd7945b70aa5": "Event Home",
    "4710c1d5-00b7-4745-8902-c258434789d5": "Profile Home",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "Login",
    "4be6b231-5299-4d8b-8425-40923eeb9b2b": "Team Home",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);