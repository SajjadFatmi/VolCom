function initData() {
  jimData.variables["value"] = "1";
  jimData.isInitialized = true;
}