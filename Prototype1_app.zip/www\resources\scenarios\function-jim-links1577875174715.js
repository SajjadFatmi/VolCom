(function(window, undefined) {

  var jimLinks = {
    "f2c8bd07-c66b-48fc-a1d0-488cd2b73a1d" : {
      "Image_1" : [
        "63332fb1-af7f-4838-8a8d-aa2e02c4bc8e"
      ]
    },
    "8c589268-48bd-4499-8efe-7f05bb962749" : {
      "Paragraph_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "15327385-027c-43d3-9574-81c1575cd233" : {
      "Image_71" : [
        "907362bc-0e8f-4398-9d6b-262b2cda5b2a"
      ],
      "Text_1" : [
        "63332fb1-af7f-4838-8a8d-aa2e02c4bc8e"
      ]
    },
    "aa5107dc-3bc9-4162-959a-f2dc9fe9b024" : {
      "Image_71" : [
        "15327385-027c-43d3-9574-81c1575cd233"
      ]
    },
    "62fdcfb7-ff96-46ed-8cb4-48762adf46d0" : {
      "Two-line-item_26" : [
        "907362bc-0e8f-4398-9d6b-262b2cda5b2a"
      ]
    },
    "63332fb1-af7f-4838-8a8d-aa2e02c4bc8e" : {
      "Text_3" : [
        "4be6b231-5299-4d8b-8425-40923eeb9b2b"
      ]
    },
    "907362bc-0e8f-4398-9d6b-262b2cda5b2a" : {
      "Image_71" : [
        "4adf2520-df2e-45c4-be27-9d6c5086436f"
      ],
      "Rectangle_14" : [
        "15327385-027c-43d3-9574-81c1575cd233"
      ]
    },
    "e39c40d2-862d-4660-9575-4fd5cf1a7a62" : {
      "Text_5" : [
        "f2c8bd07-c66b-48fc-a1d0-488cd2b73a1d"
      ]
    },
    "4adf2520-df2e-45c4-be27-9d6c5086436f" : {
      "Two-line-item_26" : [
        "907362bc-0e8f-4398-9d6b-262b2cda5b2a"
      ]
    },
    "0264db86-b859-4d83-9ee3-cd7945b70aa5" : {
      "Two-line-item_26" : [
        "907362bc-0e8f-4398-9d6b-262b2cda5b2a"
      ]
    },
    "4710c1d5-00b7-4745-8902-c258434789d5" : {
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Text_1" : [
        "63332fb1-af7f-4838-8a8d-aa2e02c4bc8e"
      ],
      "Text_3" : [
        "e39c40d2-862d-4660-9575-4fd5cf1a7a62"
      ]
    },
    "4be6b231-5299-4d8b-8425-40923eeb9b2b" : {
    }    
  }

  window.jimLinks = jimLinks;
})(window);