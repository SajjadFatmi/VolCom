jQuery("#simulation")
  .on("click", ".s-63332fb1-af7f-4838-8a8d-aa2e02c4bc8e .click", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Text_3")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-63332fb1-af7f-4838-8a8d-aa2e02c4bc8e #s-Text_3 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#C4C2C5"
                      }
                    }
                  },{
                    "#s-63332fb1-af7f-4838-8a8d-aa2e02c4bc8e #s-Text_3": {
                      "attributes-ie": {
                        "-pie-background": "#C4C2C5",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimPause",
                  "parameter": {
                    "pause": 100
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-63332fb1-af7f-4838-8a8d-aa2e02c4bc8e #s-Text_3 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#6ACA6B",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-63332fb1-af7f-4838-8a8d-aa2e02c4bc8e #s-Text_3": {
                      "attributes-ie": {
                        "-pie-background": "#6ACA6B",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimMove",
                  "parameter": {
                    "target": [ "#s-Dynamic_Panel_1" ],
                    "top": {
                      "type": "nomove"
                    },
                    "left": {
                      "type": "movetoposition",
                      "value": "-249"
                    },
                    "containment": false,
                    "effect": {
                      "type": "none",
                      "easing": "linear",
                      "duration": 500
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Hotspot_1" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-63332fb1-af7f-4838-8a8d-aa2e02c4bc8e #s-Text_3 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#9AB8B1",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-63332fb1-af7f-4838-8a8d-aa2e02c4bc8e #s-Text_3": {
                      "attributes-ie": {
                        "-pie-background": "#9AB8B1",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/4be6b231-5299-4d8b-8425-40923eeb9b2b",
                    "transition": {
                      "type": "slideleft",
                      "duration": 300
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_5")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-63332fb1-af7f-4838-8a8d-aa2e02c4bc8e #s-Text_5 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#C4C2C5"
                      }
                    }
                  },{
                    "#s-63332fb1-af7f-4838-8a8d-aa2e02c4bc8e #s-Text_5": {
                      "attributes-ie": {
                        "-pie-background": "#C4C2C5",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimPause",
                  "parameter": {
                    "pause": 100
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-63332fb1-af7f-4838-8a8d-aa2e02c4bc8e #s-Text_5 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#6ACA6B",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-63332fb1-af7f-4838-8a8d-aa2e02c4bc8e #s-Text_5": {
                      "attributes-ie": {
                        "-pie-background": "#6ACA6B",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimMove",
                  "parameter": {
                    "target": [ "#s-Dynamic_Panel_1" ],
                    "top": {
                      "type": "nomove"
                    },
                    "left": {
                      "type": "movetoposition",
                      "value": "-249"
                    },
                    "containment": false,
                    "effect": {
                      "type": "none",
                      "easing": "linear",
                      "duration": 500
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Hotspot_1" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-63332fb1-af7f-4838-8a8d-aa2e02c4bc8e #s-Text_5 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#9AB8B1",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-63332fb1-af7f-4838-8a8d-aa2e02c4bc8e #s-Text_5": {
                      "attributes-ie": {
                        "-pie-background": "#9AB8B1",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_6")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-63332fb1-af7f-4838-8a8d-aa2e02c4bc8e #s-Text_6 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#C4C2C5"
                      }
                    }
                  },{
                    "#s-63332fb1-af7f-4838-8a8d-aa2e02c4bc8e #s-Text_6": {
                      "attributes-ie": {
                        "-pie-background": "#C4C2C5",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimPause",
                  "parameter": {
                    "pause": 100
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-63332fb1-af7f-4838-8a8d-aa2e02c4bc8e #s-Text_6 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#6ACA6B",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-63332fb1-af7f-4838-8a8d-aa2e02c4bc8e #s-Text_6": {
                      "attributes-ie": {
                        "-pie-background": "#6ACA6B",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimMove",
                  "parameter": {
                    "target": [ "#s-Dynamic_Panel_1" ],
                    "top": {
                      "type": "nomove"
                    },
                    "left": {
                      "type": "movetoposition",
                      "value": "-249"
                    },
                    "containment": false,
                    "effect": {
                      "type": "none",
                      "easing": "linear",
                      "duration": 500
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Hotspot_1" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-63332fb1-af7f-4838-8a8d-aa2e02c4bc8e #s-Text_6 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#9AB8B1",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-63332fb1-af7f-4838-8a8d-aa2e02c4bc8e #s-Text_6": {
                      "attributes-ie": {
                        "-pie-background": "#9AB8B1",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_7")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-63332fb1-af7f-4838-8a8d-aa2e02c4bc8e #s-Text_7 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#C4C2C5"
                      }
                    }
                  },{
                    "#s-63332fb1-af7f-4838-8a8d-aa2e02c4bc8e #s-Text_7": {
                      "attributes-ie": {
                        "-pie-background": "#C4C2C5",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimPause",
                  "parameter": {
                    "pause": 100
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-63332fb1-af7f-4838-8a8d-aa2e02c4bc8e #s-Text_7 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#6ACA6B",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-63332fb1-af7f-4838-8a8d-aa2e02c4bc8e #s-Text_7": {
                      "attributes-ie": {
                        "-pie-background": "#6ACA6B",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimMove",
                  "parameter": {
                    "target": [ "#s-Dynamic_Panel_1" ],
                    "top": {
                      "type": "nomove"
                    },
                    "left": {
                      "type": "movetoposition",
                      "value": "-249"
                    },
                    "containment": false,
                    "effect": {
                      "type": "none",
                      "easing": "linear",
                      "duration": 500
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Hotspot_1" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-63332fb1-af7f-4838-8a8d-aa2e02c4bc8e #s-Text_7 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#9AB8B1",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-63332fb1-af7f-4838-8a8d-aa2e02c4bc8e #s-Text_7": {
                      "attributes-ie": {
                        "-pie-background": "#9AB8B1",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Text_8")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-63332fb1-af7f-4838-8a8d-aa2e02c4bc8e #s-Text_8 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#C4C2C5"
                      }
                    }
                  },{
                    "#s-63332fb1-af7f-4838-8a8d-aa2e02c4bc8e #s-Text_8": {
                      "attributes-ie": {
                        "-pie-background": "#C4C2C5",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimPause",
                  "parameter": {
                    "pause": 100
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-63332fb1-af7f-4838-8a8d-aa2e02c4bc8e #s-Text_8 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#6ACA6B",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-63332fb1-af7f-4838-8a8d-aa2e02c4bc8e #s-Text_8": {
                      "attributes-ie": {
                        "-pie-background": "#6ACA6B",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimMove",
                  "parameter": {
                    "target": [ "#s-Dynamic_Panel_1" ],
                    "top": {
                      "type": "nomove"
                    },
                    "left": {
                      "type": "movetoposition",
                      "value": "-249"
                    },
                    "containment": false,
                    "effect": {
                      "type": "none",
                      "easing": "linear",
                      "duration": 500
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Hotspot_1" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-63332fb1-af7f-4838-8a8d-aa2e02c4bc8e #s-Text_8 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#9AB8B1",
                        "background-attachment": "scroll"
                      }
                    }
                  },{
                    "#s-63332fb1-af7f-4838-8a8d-aa2e02c4bc8e #s-Text_8": {
                      "attributes-ie": {
                        "-pie-background": "#9AB8B1",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_31")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimMove",
                  "parameter": {
                    "target": [ "#s-Dynamic_Panel_1" ],
                    "top": {
                      "type": "nomove"
                    },
                    "left": {
                      "type": "movetoposition",
                      "value": "0"
                    },
                    "containment": false,
                    "effect": {
                      "type": "none",
                      "easing": "easeInQuad",
                      "duration": 500
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Hotspot_1" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_8")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-63332fb1-af7f-4838-8a8d-aa2e02c4bc8e #s-Image_8 > svg": {
                      "attributes": {
                        "overlay": "#007AFF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-63332fb1-af7f-4838-8a8d-aa2e02c4bc8e #s-Image_9 > svg": {
                      "attributes": {
                        "overlay": "#8A8A8F"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_9")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-63332fb1-af7f-4838-8a8d-aa2e02c4bc8e #s-Image_9 > svg": {
                      "attributes": {
                        "overlay": "#007AFF"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-63332fb1-af7f-4838-8a8d-aa2e02c4bc8e #s-Image_8 > svg": {
                      "attributes": {
                        "overlay": "#8A8A8F"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Hotspot_1")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimMove",
                  "parameter": {
                    "target": [ "#s-Dynamic_Panel_1" ],
                    "top": {
                      "type": "nomove"
                    },
                    "left": {
                      "type": "movetoposition",
                      "value": "-249"
                    },
                    "containment": false,
                    "effect": {
                      "type": "none",
                      "easing": "easeOutQuad",
                      "duration": 500
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Hotspot_1" ]
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("pageload", ".s-63332fb1-af7f-4838-8a8d-aa2e02c4bc8e .pageload", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Text_26")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Text_26" ],
                    "value": {
                      "action": "jimSubstring",
                      "parameter": [ {
                        "action": "jimSystemTime"
                      },"0","5" ]
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  });